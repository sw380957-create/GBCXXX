# 统一协议目录

| 数据集 | 目录 | 状态 |
| --- | --- | --- |
| CIFAR-10 | cifar10/ | 已整理现有真实协议和配置 |
| CIFAR-100 | cifar100/ | 已整理现有真实协议和配置 |
| Tiny-ImageNet | tiny_imagenet/ | 在原始数据所在服务器生成 |
| DomainNet-126 | domainnet126/ | 在服务器按固定 126 类、4 域生成 |
| CORe50 | core50/ | 在服务器生成 |
| ImageNet-100 | imagenet100/ | 在服务器生成，需固定 100 类清单 |
| Split-MNIST | split_mnist/ | 读取已有 MNIST IDX/gzip 后生成；可显式 --download |

每个目录包含 protocol.json 和 config.json；外部图片数据集额外包含 index.json 和 preparation.json。
没有真实数据的目录不放占位协议，也不提前创建，以免影响禁止覆盖的准备流程。
同一数据集的另一版本使用新目录（例如 protocols/domainnet126_seed2027），通过 --output 指定。

旧 CIFAR 协议和配置路径保留以兼容已保存的实验；新入口使用上述统一目录。
迁移后的 CIFAR protocol.json 保留原始内容和协议哈希，没有重新抽样或划分数据。
CIFAR 目录的 config.json 是当前运行起点，不表示所有历史实验使用过相同参数。

在服务器项目根目录执行（数据路径按实际情况替换）：

```bash
python -B prepare_tiny_imagenet.py --data-root /datasets/tiny-imagenet-200
python -B run_dataset.py --protocol-dir protocols/tiny_imagenet --data-root /datasets/tiny-imagenet-200 --device cuda

python -B -m data.prepare_dataset --dataset domainnet126 --data-root /datasets/domainnet --verify-images
python -B run_dataset.py --protocol-dir protocols/domainnet126 --data-root /datasets/domainnet --device cuda
```

索引使用相对图片路径；原始图片不需要复制到本地电脑或 protocols/ 中。
生成一次后重复训练复用同一目录，不需每次重新生成。原数据版本与相对目录结构需保持一致。
旧参数名 --prepared 仍兼容，但新命令统一使用 --protocol-dir。
详细数据结构、划分和其他数据集命令见项目根目录 SERVER_DATASETS_GUIDE.md。
