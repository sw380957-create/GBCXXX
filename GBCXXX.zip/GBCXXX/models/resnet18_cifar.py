"""
resnet18_cifar.py
功能：
构建适用于CIFAR-10的ResNet18网络。
用途：
1. 使用D1数据进行初始训练；
2. 提取稳定特征空间；
3. 输出512维feature向量；
4. 将feature输入粒球生成模块。
网络流程：
Input:
3×32×32
        ↓
ResNet18 backbone
        ↓
Feature:
512维
        ↓
Classifier:
10类别
数学表示：
z=f_theta(x)
y=g_theta(z)
其中：
z作为后续粒球空间。
"""

import torch
import torch.nn as nn
# ==========================================================
# 基础残差模块 BasicBlock
# ==========================================================

class BasicBlock(nn.Module):
    """
    ResNet基础残差块。
    结构：x-Conv3×3-BN-ReLU-Conv3×3-BN +shortcut-ReLU
    数学形式：
    y = F(x)+x
    """
    # 残差块
    expansion=1

    def __init__(

            self,            # self参数，代表类的实例

            in_channels,     # 输入通道数

            out_channels,    # 输出通道数

            stride=1         # 步长，默认为1

    ):
        # 初始化父类
        super(BasicBlock,self).__init__()
        # 第一个卷积层
        self.conv1=nn.Conv2d(
            in_channels,     # 输入通道数
            out_channels,    # 输出通道数
            kernel_size=3,   # 卷积核大小为3×3
            stride=stride,    # 步长
            padding=1,       # 保持输入输出尺寸相同的填充
            bias=False       # 不使用偏置项

        )
        # 第一个批归一化层
        self.bn1=nn.BatchNorm2d(
            out_channels      # 通道数
        )
        # ReLU激活函数
        self.relu=nn.ReLU(
            inplace=True      # 原地操作，节省内存
        )
        # 第二个卷积层
        self.conv2=nn.Conv2d(
            out_channels,    # 输入通道数
            out_channels,    # 输出通道数
            kernel_size=3,   # 卷积核大小为3×3
            stride=1,        # 步长为1
            padding=1,       # 保持输入输出尺寸相同的填充
            bias=False       # 不使用偏置项

        )

        # 第二个批归一化层
        self.bn2=nn.BatchNorm2d(
            out_channels     # 通道数
        )
        # shortcut部分
        # 如果尺寸变化
        # 需要使用1×1卷积匹配维度
        if stride!=1 or in_channels!=out_channels:
            self.shortcut=nn.Sequential(
                nn.Conv2d(
                    in_channels,
                    out_channels,
                    kernel_size=1,
                    stride=stride,
                    bias=False
                ),
                nn.BatchNorm2d(
                    out_channels
                )
            )
        else:
            self.shortcut=nn.Sequential()


    def forward(self,x):
     #前向传播函数,计算残差分支与捷径相加后的输出。
    # 保存输入x作为identity，用于后面的残差连接
        identity=x
    # 第一卷积层处理
        out=self.conv1(x)

    # 第一批量归一化层处理
        out=self.bn1(out)

    # ReLU激活函数处理
        out=self.relu(out)

    # 第二卷积层处理
        out=self.conv2(out)

    # 第二批量归一化层处理
        out=self.bn2(out)

        # 残差连接：将原始输入(identity)通过shortcut连接加到主路径的输出上
        out += self.shortcut(identity)

    # 再次应用ReLU激活函数
        out=self.relu(out)

    # 返回最终输出
        return out


# ==========================================================
# ResNet18
# ==========================================================
class ResNet18_CIFAR(nn.Module):
    """
    CIFAR-10版本ResNet18。
    输入：
        3×32×32
    输出：
        logits:
            10类别预测
        feature:
            512维特征
    """

    def __init__(self,num_classes=10):
        super(ResNet18_CIFAR,self).__init__()

        # 当前通道数
        self.in_channels=64
        # ----------------------------------
        # 第一层卷积 CIFAR修改: 3×3 kernel； stride=1
        # 保留32×32信息
        # ----------------------------------

        self.conv1=nn.Conv2d(
            3,
            64,
            kernel_size=3,
            stride=1,
            padding=1,
            bias=False
        )
        self.bn1=nn.BatchNorm2d(
            64
        )
        self.relu=nn.ReLU(
            inplace=True
        )
        # ----------------------------------
        # 四个ResNet阶段
        # ----------------------------------
        self.layer1=self.make_layer(
            64,
            2,
            stride=1
        )

        self.layer2=self.make_layer(
            128,
            2,
            stride=2
        )

        self.layer3=self.make_layer(
            256,
            2,
            stride=2
        )

        self.layer4=self.make_layer(
            512,
            2,
            stride=2
        )

        # 全局平均池化
        self.avgpool=nn.AdaptiveAvgPool2d(
            (1,1)
        )

        # 分类层
        self.fc=nn.Linear(
            512,
            num_classes
        )


    def make_layer(
            self,           # 类的实例对象，通常用于访问类的属性和方法
            out_channels,   # 输出通道数，决定该层输出的特征图深度
            blocks,         # 该层包含的BasicBlock数量
            stride          # 步长，用于控制特征图的尺寸变化，通常为1或2
    ):
        """
        创建ResNet阶段。堆叠残差块，按需改变通道数和空间尺寸。
        例如：
        layer1:
        64通道
        2个BasicBlock
        """

#初始化空列表，用于存放该层的所有BasicBlock模块
        layers=[]

        # 第一个block可能改变尺寸
        # 当stride不为1或输入输出通道数不同时，第一个block会改变特征图的尺寸和通道数
        layers.append(
            BasicBlock(
                self.in_channels,   # 输入通道数，来自上一层的输出通道数
                out_channels,       # 输出通道数，当前层设定的通道数
                stride              # 步长，用于控制特征图的尺寸变化
            )

        )

        self.in_channels=out_channels  # 更新输入通道数为当前层的输出通道数，供下一层使用

        # 后续block
        for i in range(1,blocks):
        # 从第二个block开始，所有block的输入输出通道数相同，步长为1，不改变特征图尺寸
   # 从1开始，因为第一个block已经创建
            layers.append(
                BasicBlock(
                    out_channels,
   # 输入通道数，与前一个block的输出通道数相同
                    out_channels
    # 输出通道数，保持不变
                )
            )
        return nn.Sequential(*layers)
  # 使用nn.Sequential将所有block顺序组合成一个层

    def forward(self,x):
        """
        前向传播。
        返回：logits:分类结果
        feature:512维特征
        """
        x=self.conv1(x)
        x=self.bn1(x)
        x=self.relu(x)
        x=self.layer1(x)
        x=self.layer2(x)
        x=self.layer3(x)
        x=self.layer4(x)

        # 特征压缩
        x=self.avgpool(x)

        # 展平
        feature=torch.flatten(
            x,
            1
        )

        # 分类
        logits=self.fc(feature)

        return logits,feature


if __name__=="__main__":
    # 测试网络尺寸
    model=ResNet18_CIFAR()

    x=torch.randn(
        4,
        3,
        32,
        32
    )
    output,feature=model(x)
    print(
        "输出类别:",
        output.shape
    )
    print(
        "特征维度:",
        feature.shape
    )