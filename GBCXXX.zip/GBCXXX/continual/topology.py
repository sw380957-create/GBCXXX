"""保存粒球之间的拓扑关系：拓扑保存稳定 ball_id 三元组，而不是易随球列表变化的数组下标。"""
import numpy as np


def _ball_id(ball):
    """Return the persisted ID from either a live ball or a record."""
    if isinstance(ball, dict):
        return str(ball["ball_id"])
    return str(getattr(ball, "ball_id", getattr(ball, "id")))


def _ball_center(ball):
    """Return a live/recorded ball center as a one-dimensional array."""
    center = ball["center"] if isinstance(ball, dict) else ball.center
    return np.asarray(center, dtype=np.float64)


def validate_topology(triples, ball_ids, *, context="topology"):
    """Validate that topology references only the currently effective balls.

    This is deliberately a hard error.  A missing ID means the structure and
    topology lifecycle have diverged and silently dropping a triple would hide
    that corruption from the training run.
    """
    array = np.asarray(triples, dtype="U64")
    if array.size == 0:
        array = np.empty((0, 3), dtype="U64")
    elif array.size % 3 or array.ndim != 2 or array.shape[1] != 3:
        raise ValueError(
            f"{context}: topology must have shape (N, 3), got {array.shape}"
        )
    current_ids = {str(ball_id) for ball_id in ball_ids}
    missing = sorted({str(key) for key in array.reshape(-1)} - current_ids)
    if missing:
        raise ValueError(
            f"{context}: topology references missing ball_ids; "
            f"missing_ids={missing}; current_ball_id_count={len(current_ids)}; "
            f"topology_count={len(array)}"
        )
    return array


def build_current_ball_topology(balls):
    """Build topology strictly from the current effective ball collection.

    The function is also used with persisted records during checkpoint
    recovery.  It never carries triples from a previous structure revision.
    """
    # 只有两个球时 nearest == farthest，不存在严格的近远关系；不制造无意义约束。
    if len(balls) < 3:
        return np.empty((0, 3), dtype="U64")
    ball_ids = [_ball_id(ball) for ball in balls]
    if len(set(ball_ids)) != len(ball_ids):
        raise ValueError("当前粒球集合包含重复 ball_id，无法生成 topology")
    centers = np.stack([_ball_center(ball) for ball in balls])
    distances = np.linalg.norm(centers[:, None] - centers[None], axis=2)
    triples = []
    for i, ball in enumerate(balls):
        others = np.asarray([j for j in range(len(balls)) if j != i])
        near = int(others[np.argmin(distances[i, others])])
        far = int(others[np.argmax(distances[i, others])])
        # 所有距离相同也无法表达 D_ij < D_il，因此跳过退化行。
        if distances[i, near] < distances[i, far]:
            triples.append((ball_ids[i], ball_ids[near], ball_ids[far]))
    result = np.asarray(triples, dtype="U64").reshape(-1, 3)
    return validate_topology(result, ball_ids, context="build_current_ball_topology")


def build_topology(balls):
    """Backward-compatible name for rebuilding current topology."""
    return build_current_ball_topology(balls)


def build_topology_from_records(records):
    """Rebuild topology from current checkpoint records, discarding old triples."""
    return build_current_ball_topology(records)


def save_topology(path, triples):
    np.savez_compressed(path, triples=np.asarray(triples, dtype="U64").reshape(-1, 3))


def load_topology(path):
    with np.load(path, allow_pickle=False) as data:
        return data["triples"].copy()
