"""持续模型/SGD 状态的窗口训练。此层只接收当前图像和允许的历史结构。

每个 mini-batch 一次 backward + optimizer.step；local epoch 只重新打乱
当前窗口，绝不重建模型/优化器。历史结构存在与否决定历史约束是否启用。
"""
import random
from types import SimpleNamespace
import numpy as np
import torch
from torch.utils.data import DataLoader
from .data import ImageDataset
from .trainer import _gradient_check, save_recovery_checkpoint
from .task_free_config import TaskFreeConfig


class TaskFreeTrainer:
    #初始化持续使用的模型、SGD 和运行计数。
    def __init__(self, model, config, device, history=None):
        self.config=config.validate()
        self.device=device
        self.model=model.to(device)
        for p in self.model.parameters():
            p.requires_grad_(True)
        opt=config.optimizer
        self.optimizer=torch.optim.SGD(self.model.parameters(), lr=opt['learning_rate'],
            momentum=opt['momentum'],weight_decay=opt['weight_decay'])
        self.history=history
        self.optimizer_steps=0
        self.sample_accesses=0
        self.replay_sample_accesses=0
        # 抽取代表点使用独立 RNG；保存其状态，恢复后延续同一回放序列。
        self.replay_rng=np.random.default_rng(config.seed+1)
        self.replay_memory_ids=np.empty(0,dtype=np.int64)
        self.replay_memory_revision=None
        self.replay_order=np.empty(0,dtype=np.int64)
        self.replay_cursor=0
        self.replay_completed_cycles=0
        # 类别均衡模式为每个类别维护独立的无放回遍历状态。配额余数
        # 使用 rotation 轮换，避免 batch_size 不能整除类别数时固定偏向小标签。
        self.replay_class_orders={}
        self.replay_class_cursors={}
        self.replay_class_completed_cycles={}
        self.replay_class_rotation=0
        self._last_replay_rows=np.empty(0,dtype=np.int64)
        self._combined_replay_memory=None
        self._combined_replay_revision=None
        self.stream_position=0
        self.window_index=0
        self.seen_classes=set()

    def _effective_replay_memory(self):
        """Return CE images while keeping the historical-loss anchors separate.

        Concatenation occurs once per maintenance revision, not once per SGD
        step.  The first rows are always the granular-ball anchors; the extra
        rows carry current same-label ball IDs for GB ball-subset activation.
        """
        memory=getattr(self.history,'memory',None)
        if memory is None or not self.config.ce_replay_fill_budget:
            return memory
        revision=getattr(self.history,'revision',None)
        if self._combined_replay_revision != revision or self._combined_replay_memory is None:
            extra=self.history.ce_replay_extra
            if not len(extra.labels):
                combined=memory
            else:
                combined=SimpleNamespace(
                    images=np.concatenate([memory.images,extra.images]),
                    labels=np.concatenate([memory.labels,extra.labels]),
                    sample_ids=np.concatenate([memory.sample_ids,extra.sample_ids]),
                    ball_ids=np.concatenate([memory.ball_ids,extra.ball_ids]))
            self._combined_replay_memory=combined
            self._combined_replay_revision=revision
        return self._combined_replay_memory

    def _sync_replay_memory(self, memory=None, revision=None):
        """维护更换代表点后重建顺序；仅训练窗口变化时不重置遍历。"""
        if not self.config.representative_replay_batch_size:
            return
        if memory is None:
            memory=self._effective_replay_memory()
            revision=getattr(self.history,'revision',None)
        ids=memory.sample_ids if memory is not None else np.empty(0,dtype=np.int64)
        if revision!=self.replay_memory_revision or not np.array_equal(ids,self.replay_memory_ids):
            self.replay_memory_ids=np.asarray(ids,dtype=np.int64).copy()
            self.replay_memory_revision=revision
            if self.config.representative_replay_sampling=='global_cycle':
                self.replay_order=self.replay_rng.permutation(len(ids))
                self.replay_cursor=0
                self.replay_completed_cycles=0
                self.replay_class_orders={}
                self.replay_class_cursors={}
                self.replay_class_completed_cycles={}
                self.replay_class_rotation=0
            else:
                labels=np.asarray(memory.labels,dtype=np.int64)
                classes=sorted(map(int,np.unique(labels)))
                self.replay_class_orders={
                    c:self.replay_rng.permutation(np.flatnonzero(labels==c)).astype(np.int64)
                    for c in classes}
                self.replay_class_cursors={c:0 for c in classes}
                self.replay_class_completed_cycles={c:0 for c in classes}
                self.replay_class_rotation=0
                self.replay_order=np.empty(0,dtype=np.int64)
                self.replay_cursor=0
                self.replay_completed_cycles=0

    def _balanced_class_rows(self, label, count):
        """从单类循环取不重复行；跨越轮尾时先取新排列中的未取行。"""
        order=self.replay_class_orders[label]
        # 单个训练小批次内不重复同一代表图像。类别代表不足其配额时，
        # 该批保持不足，而不是反复复制同一张图。
        count=min(int(count),len(order))
        selected=[]
        while len(selected)<count:
            cursor=self.replay_class_cursors[label]
            if cursor==len(order):
                order=self.replay_rng.permutation(order)
                if selected:
                    used=np.asarray(selected,dtype=np.int64)
                    duplicate=np.isin(order,used)
                    order=np.concatenate([order[~duplicate],order[duplicate]])
                self.replay_class_orders[label]=order
                self.replay_class_cursors[label]=0
                cursor=0
            take=min(count-len(selected),len(order)-cursor)
            selected.extend(map(int,order[cursor:cursor+take]))
            cursor+=take
            self.replay_class_cursors[label]=cursor
            if cursor==len(order):
                self.replay_class_completed_cycles[label]+=1
        return np.asarray(selected,dtype=np.int64)

    def _balanced_replay_rows(self, memory):
        """按类别均分回放预算，余数跨小批次轮换，再执行类内循环。"""
        classes=sorted(self.replay_class_orders)
        if not classes:
            return np.empty(0,dtype=np.int64)
        target=min(self.config.representative_replay_batch_size,len(memory.labels))
        base,remainder=divmod(target,len(classes))
        quotas={c:base for c in classes}
        for offset in range(remainder):
            quotas[classes[(self.replay_class_rotation+offset)%len(classes)]]+=1
        if remainder:
            self.replay_class_rotation=(self.replay_class_rotation+remainder)%len(classes)
        parts=[self._balanced_class_rows(c,quotas[c]) for c in classes if quotas[c]]
        rows=np.concatenate(parts) if parts else np.empty(0,dtype=np.int64)
        # 类别配额只约束组成，不让输入顺序形成按类别排列的梯度偏差。
        return self.replay_rng.permutation(rows) if len(rows)>1 else rows

    def _replay_batch(self, memory=None, revision=None):
        """按配置遍历代表原图，并返回本次用于 CE 回放的图像与标签。"""
        self._last_replay_rows=np.empty(0,dtype=np.int64)
        budget=self.config.representative_replay_batch_size
        if not budget:
            return None
        self._sync_replay_memory(memory, revision)
        if memory is None:
            memory=self._effective_replay_memory()
        if memory is None or not len(memory.labels):
            return None
        if self.config.representative_replay_sampling=='class_balanced_cycle':
            rows=self._balanced_replay_rows(memory)
        else:
            if self.replay_cursor==len(self.replay_order):
                self.replay_order=self.replay_rng.permutation(len(memory.labels))
                self.replay_cursor=0
            end=min(self.replay_cursor+budget,len(self.replay_order))
            rows=self.replay_order[self.replay_cursor:end]
            self.replay_cursor=end
            if end==len(self.replay_order):
                self.replay_completed_cycles+=1
        dataset=ImageDataset(memory.images[rows],memory.labels[rows],augment=True,
                             horizontal_flip=self.config.horizontal_flip)
        batch=[dataset[i] for i in range(len(rows))]
        self._last_replay_rows=np.asarray(rows,dtype=np.int64).copy()
        return torch.stack([x for x,_ in batch]),torch.tensor([int(y) for _,y in batch])

    def train_window(self, images, labels, warmup_replay=None):
        #多次遍历当前窗口，每个 mini-batch 计算 CE 和已启用的历史约束，再反向更新。
        if not len(labels) or len(labels)>self.config.window_size:
            raise ValueError('window must contain 1..window_size samples')
        replay_memory=None
        replay_revision=None
        stored_memory=self._effective_replay_memory()
        replay_source=(('granular_ball_plus_ce_extra' if self.config.ce_replay_fill_budget
                        else 'granular_ball') if stored_memory is not None and
                       len(stored_memory.labels) else 'none')
        warmup_pool_size=0
        if warmup_replay is not None:
            # runner 仅传入已经完成训练的旧窗口 pending 数据，当前窗口不在其中。
            # 从这些图像中确定性地选一个不超过预算的临时池；选出的
            # 临时副本只在本窗口使用，不持久化。首次建球后自动切换。
            old_images,old_labels,old_ids=warmup_replay
            warmup_pool_size=len(old_ids)
            if (len(old_images)!=warmup_pool_size or len(old_labels)!=warmup_pool_size or
                    (self.history is not None and self.history.records)):
                raise ValueError('invalid warmup replay input')
            if warmup_pool_size and self.config.warmup_replay_capacity:
                capacity=min(warmup_pool_size,self.config.warmup_replay_capacity)
                if capacity==warmup_pool_size:
                    rows=np.arange(warmup_pool_size)
                else:
                    # 每个窗口固定同一候选池，恢复 checkpoint 后可重建。
                    rng=np.random.default_rng(np.random.SeedSequence(
                        [self.config.seed,self.window_index]))
                    rows=np.sort(rng.choice(warmup_pool_size,capacity,replace=False))
                replay_memory=SimpleNamespace(images=old_images[rows],
                    labels=old_labels[rows],sample_ids=old_ids[rows])
                replay_revision='warmup'
                replay_source='warmup_previous_windows'
        loader=DataLoader(ImageDataset(images,labels,augment=True,horizontal_flip=self.config.horizontal_flip),
                          batch_size=self.config.batch_size,shuffle=True,num_workers=0)
        start=self.optimizer_steps
        sums={}
        historical_accesses=0
        replay_accesses=0
        replay_class_accesses={}
        for _ in range(self.config.local_epochs):
            for x,y in loader:
                current_count=len(y)
                replay=self._replay_batch(replay_memory,replay_revision)
                replay_count=0
                active_ball_ids=None
                if replay is not None:
                    replay_x,replay_y=replay
                    replay_count=len(replay_y)
                    if (replay_memory is None and self.config.gb_replay_ball_subset and
                            self.history is not None and self.history.records and
                            hasattr(self.history,'memory')):
                        active_ball_ids=np.unique(
                            stored_memory.ball_ids[self._last_replay_rows])
                    labels_in_replay,counts=np.unique(replay_y.numpy(),return_counts=True)
                    for label,count in zip(labels_in_replay,counts):
                        key=int(label)
                        replay_class_accesses[key]=replay_class_accesses.get(key,0)+int(count)
                    x=torch.cat([x,replay_x])
                    y=torch.cat([y,replay_y])
                self.model.train()
                self.optimizer.zero_grad(set_to_none=True)
                logits,features=self.model(x.to(self.device))
                ce=torch.nn.functional.cross_entropy(logits,y.to(self.device))
                loss=ce
                values={'ce':float(ce.detach())}
                if self.config.representative_replay_batch_size:
                    # ce 是合并小批次按图片平均的训练目标；两组 CE 单独
                    # 记录便于诊断，不额外引入 loss 权重。
                    values['ce_current']=float(torch.nn.functional.cross_entropy(
                        logits[:current_count],y[:current_count].to(self.device)).detach())
                    values['ce_replay']=(float(torch.nn.functional.cross_entropy(
                        logits[current_count:],y[current_count:].to(self.device)).detach())
                        if replay_count else 0.)
                if self.history is not None and self.history.records:
                    # 保持历史 loss 的当前样本见证集合只使用真正新到达的
                    # 特征；回放图像已经通过 history.memory 单独参与该 loss。
                    current_features=features[:current_count] if replay_count else features
                    if getattr(self.history,'supports_replay_ball_subset',False):
                        hist,parts=self.history.loss(
                            self.model,current_features,active_ball_ids=active_ball_ids)
                    else:
                        hist,parts=self.history.loss(self.model,current_features)
                    loss=loss+hist
                    values.update(parts)
                    # 三个历史损失都关闭时，history.loss 会直接返回零值，
                    # 没有读取代表点图像；访问量统计必须反映真实计算。
                    if any((self.config.lambda_gb,self.config.lambda_struct,
                            self.config.lambda_overlap)):
                        historical_accesses+=int(getattr(
                            self.history,'last_loss_memory_accesses',
                            len(self.history.memory.labels)
                            if hasattr(self.history,'memory') else 0))
                if not torch.isfinite(loss):
                    raise FloatingPointError('nonfinite task-free loss')
                loss.backward()
                values['gradient_norm']=_gradient_check(self.model)
                self.optimizer.step()
                self.optimizer_steps+=1
                self.sample_accesses+=current_count
                self.replay_sample_accesses+=replay_count
                replay_accesses+=replay_count
                values['total']=float(loss.detach())
                for k,v in values.items():
                    sums[k]=sums.get(k,0.)+v
        self.window_index+=1
        self.stream_position+=len(labels)
        self.seen_classes.update(map(int,labels))
        steps=self.optimizer_steps-start
        result={'window_index':self.window_index,'window_sample_count':len(labels),
                'mini_batches_per_epoch':len(loader),'local_epochs':self.config.local_epochs,
                'optimizer_steps':steps,'cumulative_optimizer_steps':self.optimizer_steps,
                'sample_accesses':len(labels)*self.config.local_epochs,
                'cumulative_sample_accesses':self.sample_accesses,
                'replay_sample_accesses':replay_accesses,
                'replay_class_sample_accesses':replay_class_accesses,
                'cumulative_replay_sample_accesses':self.replay_sample_accesses,
                'historical_feature_sample_accesses':historical_accesses,
                'stream_position':self.stream_position,'losses':{k:v/steps for k,v in sums.items()}}
        if self.config.representative_replay_batch_size:
            # 该信息对应训练使用的旧 memory；随后 full_update 可能更换它。
            info={'memory_revision':self.replay_memory_revision,
                  'memory_size':len(self.replay_memory_ids),
                  'source':replay_source,'warmup_pool_size':warmup_pool_size}
            if self.config.representative_replay_sampling=='class_balanced_cycle':
                memory=replay_memory if replay_memory is not None else self._effective_replay_memory()
                labels=np.asarray(memory.labels,dtype=np.int64)
                info.update(
                    policy='class_balanced_cycle_v1',
                    memory_size_by_class={c:int(np.sum(labels==c))
                                          for c in sorted(self.replay_class_orders)},
                    completed_cycles_by_class=self.replay_class_completed_cycles.copy(),
                    cursor_by_class=self.replay_class_cursors.copy(),
                    quota_rotation=self.replay_class_rotation)
            else:
                info.update(policy='shuffled_cycle_v1',
                            completed_cycles=self.replay_completed_cycles,
                            cursor=self.replay_cursor,
                            remaining_in_cycle=len(self.replay_order)-self.replay_cursor)
            result['representative_replay']=info
        return result

    def save(self,path,protocol_hash,extra=None):
        #保存网络、optimizer、历史结构、随机状态、数据流位置及 pending 缓存。
        # runner 在维护之后保存：先同步新 memory，使保存的顺序与球记录
        # 属于同一维护版本，避免恢复时套用上轮代表点行号。
        self._sync_replay_memory()
        if self.config.representative_replay_sampling=='class_balanced_cycle':
            replay_cycle={
                'version':'class_balanced_cycle_v1',
                'memory_ids':self.replay_memory_ids.copy(),
                'memory_revision':self.replay_memory_revision,
                'class_orders':{c:order.copy() for c,order in self.replay_class_orders.items()},
                'class_cursors':self.replay_class_cursors.copy(),
                'class_completed_cycles':self.replay_class_completed_cycles.copy(),
                'class_rotation':self.replay_class_rotation}
        else:
            replay_cycle={
                'version':'shuffled_cycle_v1',
                'memory_ids':self.replay_memory_ids.copy(),
                'memory_revision':self.replay_memory_revision,
                'order':self.replay_order.copy(),'cursor':self.replay_cursor,
                'completed_cycles':self.replay_completed_cycles}
        save_recovery_checkpoint(path,{
            'model_state_dict':self.model.state_dict(),
            'optimizer_state_dict':self.optimizer.state_dict(), 'scheduler_state_dict':None,
            'stream_position':self.stream_position,'window_index':self.window_index,
            'optimizer_steps':self.optimizer_steps,'sample_accesses':self.sample_accesses,
            'replay_sample_accesses':self.replay_sample_accesses,
            'replay_rng':self.replay_rng.bit_generator.state,
            'replay_cycle':replay_cycle,
            'seen_classes':sorted(self.seen_classes),'protocol_hash':protocol_hash,
            'task_free_config':self.config.to_dict(),
            'granular_ball_state':self.history.state_dict() if self.history else None,
            'rng':{'python':random.getstate(),'numpy':np.random.get_state(),
                   'torch':torch.get_rng_state(),
                   'cuda':torch.cuda.get_rng_state_all() if self.device.type=='cuda' else []},
            'extra':extra or {}})

    def load(self,path,protocol_hash):
        #校验配置和协议后恢复完整运行状态。
        state=torch.load(path,map_location=self.device,weights_only=False)
        saved_config=dict(state['task_free_config'])
        # 兼容删除 purity_farthest 实验分支前保存的正式 classwise checkpoint；
        # 真正使用过已删除方案的 checkpoint 不能静默改成 classwise 继续训练。
        retired_generation_mode=saved_config.pop('new_ball_generation_mode','classwise')
        if retired_generation_mode!='classwise':
            raise ValueError('checkpoint uses removed purity_farthest generation mode')
        # 旧 checkpoint 缺少新增开关时补入旧行为默认值；不能在恢复中
        # 偷换类内规则、降维或回放设置。
        legacy_defaults=TaskFreeConfig()
        for key in ('intra_split_mode','quality_min_child_samples',
                    'quality_min_child_fraction','quality_min_bw_ratio',
                    'redundant_merge_mode','remove_singleton_balls',
                    'feature_projection_dim',
                    'representative_replay_batch_size','representative_replay_sampling',
                    'warmup_replay_capacity',
                    'ce_replay_fill_budget',
                    'representative_selection_mode','representative_min_per_ball',
                    'representative_max_per_ball','representative_coverage_error',
                     'representative_memory_budget','gb_replay_ball_subset',
                    'ball_feature_metric','horizontal_flip'):
            saved_config.setdefault(key,getattr(legacy_defaults,key))
        if state['protocol_hash']!=protocol_hash or saved_config!=self.config.to_dict():
            raise ValueError('checkpoint protocol/config mismatch')
        expected_replay_version=('class_balanced_cycle_v1'
                                 if self.config.representative_replay_sampling=='class_balanced_cycle'
                                 else 'shuffled_cycle_v1')
        if self.config.representative_replay_batch_size and (
                'replay_cycle' not in state or
                state['replay_cycle'].get('version')!=expected_replay_version):
            readable=('class-balanced-cycle' if expected_replay_version=='class_balanced_cycle_v1'
                      else 'shuffled-cycle')
            raise ValueError(f'checkpoint does not contain {readable} replay state; start a new run')
        self.model.load_state_dict(state['model_state_dict'])
        self.optimizer.load_state_dict(state['optimizer_state_dict'])
        for key in ('stream_position','window_index','optimizer_steps','sample_accesses'):
            setattr(self,key,state[key])
        self.replay_sample_accesses=state.get('replay_sample_accesses',0)
        if 'replay_rng' in state:
            self.replay_rng.bit_generator.state=state['replay_rng']
        elif self.config.representative_replay_batch_size:
            raise ValueError('checkpoint is missing representative replay RNG state')
        self.seen_classes=set(state['seen_classes'])
        if state['granular_ball_state'] is not None:
            if self.history is None:
                raise ValueError('historical adapter required for checkpoint')
            self.history.load_state_dict(state['granular_ball_state'])
        if self.config.representative_replay_batch_size:
            cycle=state['replay_cycle']
            self.replay_memory_ids=np.asarray(cycle['memory_ids'],dtype=np.int64).copy()
            self.replay_memory_revision=cycle['memory_revision']
            memory=self._effective_replay_memory()
            ids=memory.sample_ids if memory is not None else np.empty(0,dtype=np.int64)
            n=len(ids)
            shared_ok=(np.array_equal(ids,self.replay_memory_ids) and
                       self.replay_memory_revision==getattr(self.history,'revision',None))
            if self.config.representative_replay_sampling=='class_balanced_cycle':
                labels=np.asarray(memory.labels,dtype=np.int64)
                classes=sorted(map(int,np.unique(labels)))
                try:
                    self.replay_class_orders={int(c):np.asarray(order,dtype=np.int64).copy()
                                              for c,order in cycle['class_orders'].items()}
                    self.replay_class_cursors={int(c):int(v)
                                               for c,v in cycle['class_cursors'].items()}
                    self.replay_class_completed_cycles={int(c):int(v)
                            for c,v in cycle['class_completed_cycles'].items()}
                    self.replay_class_rotation=int(cycle['class_rotation'])
                except (KeyError,TypeError,ValueError,AttributeError) as error:
                    raise ValueError('invalid class-balanced replay checkpoint state') from error
                class_ok=(sorted(self.replay_class_orders)==classes and
                          sorted(self.replay_class_cursors)==classes and
                          sorted(self.replay_class_completed_cycles)==classes and
                          (not classes or 0<=self.replay_class_rotation<len(classes)))
                for c in classes:
                    expected_rows=np.flatnonzero(labels==c)
                    order=self.replay_class_orders[c]
                    class_ok=class_ok and order.shape==expected_rows.shape
                    class_ok=class_ok and np.array_equal(np.sort(order),expected_rows)
                    class_ok=class_ok and 0<=self.replay_class_cursors[c]<=len(order)
                    class_ok=class_ok and self.replay_class_completed_cycles[c]>=0
                if not shared_ok or not class_ok:
                    raise ValueError('checkpoint replay traversal does not match current representatives')
                self.replay_order=np.empty(0,dtype=np.int64)
                self.replay_cursor=0
                self.replay_completed_cycles=0
            else:
                self.replay_order=np.asarray(cycle['order'],dtype=np.int64).copy()
                self.replay_cursor=cycle['cursor']
                self.replay_completed_cycles=cycle['completed_cycles']
                if (not shared_ok or self.replay_order.shape!=(n,) or
                        not np.array_equal(np.sort(self.replay_order),np.arange(n)) or
                        type(self.replay_cursor) is not int or not 0<=self.replay_cursor<=n or
                        type(self.replay_completed_cycles) is not int or self.replay_completed_cycles<0):
                    raise ValueError('checkpoint replay traversal does not match current representatives')
                self.replay_class_orders={}
                self.replay_class_cursors={}
                self.replay_class_completed_cycles={}
                self.replay_class_rotation=0
        random.setstate(state['rng']['python']); np.random.set_state(state['rng']['numpy'])
        torch.set_rng_state(state['rng']['torch'].cpu())
        if self.device.type=='cuda' and state['rng']['cuda']:
            torch.cuda.set_rng_state_all([x.cpu() for x in state['rng']['cuda']])
        return state
