"""持续学习分类：可选旧 mean-core 决策或新 max-coverage 单标签直判。

复用实验分类器，不在这里重写候选选择或聚合算法。
读取保存的 radius / mean_radius，不重新估计几何。
训练损失、结构优化及 memory 的半径定义由各自模块负责。
"""
import numpy as np
from granular_ball.classifier_experimental import ExperimentalGranularBallClassifier
from analysis.evaluate_cifar10_stage import confusion_matrix_numpy

#`adaptive_boundary_mean` 自适应边界均值
CLASSIFIER_SPEC = {
    "name": "adaptive_boundary_mean",
    "decision_mode": "adaptive_boundary",
    "aggregate": "mean",## 聚合方式：均值
    "radius_field": "mean_radius",# 使用【粒球平均半径】
    "response_denominator": "max(mean_radius, epsilon)",# 响应度分母，防止除0：取平均半径和epsilon的较大值
    "coverage_definition": "inside_any_mean_radius_core",# 样本覆盖判定：落在任意mean_radius核心区内就算被覆盖
    "score_definition": "candidate_response_mean; single_class_core_or_underflow_fallback_score_1",
# 打分规则：候选响应取均值；如果只有单类核心/数值下溢兜底，score=1
    "implementation": "granular_ball/classifier_experimental.py",# 底层实现文件
}
# max_unique_then_adaptive_mean 优先唯一标签再自适应均值
MAX_UNIQUE_CLASSIFIER_SPEC = {
    "name": "max_unique_then_adaptive_mean",
    "decision_mode": "max_unique_then_adaptive_mean",
    "aggregate": "mean",
    "radius_field": "max_radius_for_unique_label; mean_radius_for_ambiguous_response",
# 半径策略：唯一标签场景用max_radius；歧义（多粒球重叠、多类别候选）时切回mean_radius
    "response_denominator": "max(mean_radius, epsilon)",
    "coverage_definition": "inside_any_max_radius",# 覆盖判定：落在任意max_radius区域内
    "score_definition": "single_max_coverage_label_score_1; otherwise_adaptive_candidate_response_mean",
# 打分：只有一个最大覆盖类别时score=1；歧义样本走自适应候选响应均值
    "implementation": "granular_ball/classifier_experimental.py",
}


def classifier_spec(classifier_mode):#配置选择函数
    if classifier_mode == "adaptive_boundary_mean":
        return CLASSIFIER_SPEC
    if classifier_mode == "max_unique_then_adaptive_mean":
        return MAX_UNIQUE_CLASSIFIER_SPEC
    raise ValueError(f"未知分类模式: {classifier_mode}")


class ContinualClassifier(ExperimentalGranularBallClassifier):#持续学习分类器类
    def __init__(self, records, epsilon, classifier_mode="adaptive_boundary_mean"):
        '''保留旧实验的默认分类规则；Task-Free 正式入口显式传入当前配置。
        records：**已保存的粒球集合**（持续学习的记忆库，不断新增粒球）
        epsilon：极小值，用来防止分母为 0
        从 spec 读取`decision_mode`传给父类，同时固定`adaptive_aggregate="mean"`
        '''
        mode = classifier_spec(classifier_mode)["decision_mode"]
        super().__init__(records, decision_mode=mode,
                         adaptive_aggregate="mean", epsilon=epsilon)

# 评估主函数
def evaluate_features(features, labels, records, seen_classes, epsilon, batch_size=128,
                      classifier_mode="adaptive_boundary_mean"):
    '''输入：特征、标签、粒球记忆库`records`、已经见过的类别`seen_classes`、
    epsilon、batch_size、分类模式
    输出：包含准确率、每类精度、覆盖度、混淆矩阵等的评估字典'''
    spec = classifier_spec(classifier_mode)
    classes = np.asarray(seen_classes, dtype=np.int64)
    mask = np.isin(labels, classes)#`mask`：过滤测试集，**只保留属于已见过类别的样本**，未来类样本直接剔除
    X, y = features[mask], labels[mask]
    # 空集合输出显式 None，不伪造为 0% accuracy，也不让 mean(empty) 产生 NaN。
    if not len(y) or    not records:
        return {"accuracy": None, "num_test_samples": len(y), "per_class_accuracy": {},
                "coverage_rate": None, "confusion_matrix": [], "status": "empty",
                "classifier": {**spec, "epsilon": float(epsilon)}}
    classifier = ContinualClassifier(records, epsilon, classifier_mode=classifier_mode)
    if not np.array_equal(classifier.classes, classes):
        raise ValueError("粒球类别必须恰好等于累计已见类别，不能缺类或包含未来类别")
    predictions, scores, covered = classifier.predict_with_details(X, batch_size=batch_size)
    #调用预测，predictions：预测类别；scores：预测得分；`covered`：布尔数组，标记**该样本是否被任意粒球覆盖**
    accuracy = float(np.mean(predictions == y))#整体准确率：预测等于真实标签的样本占比
    return {
        "accuracy": accuracy, "accuracy_percent": accuracy * 100,#整体准确率：预测等于真实标签的样本占比
        "num_test_samples": int(len(y)),
        "per_class_accuracy": {str(c): float(np.mean(predictions[y == c] == c))
                               if np.any(y == c) else None for c in classes},
        #逐类准确率：如果该类别在本次测试集有样本 → 计算这个类的识别正确率；如果本次测试集没有这个类样本 → 填None
        "coverage_rate": float(np.mean(covered)),#**覆盖率**：测试样本落在任意粒球区域内的比例，是粒球模型特有指标。
        "mean_winning_class_response": float(np.mean(scores)),
        "confusion_matrix": confusion_matrix_numpy(y, predictions, classes).tolist(),#混淆矩阵，
        "seen_classes": classes.tolist(), "status": "ok",
        "classifier": {**spec, "epsilon": float(epsilon)},
    }
