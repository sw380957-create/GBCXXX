"""读取固定 learner view 的 Task-Free 入口；不生成数据协议，不读取分布标注。

临时缓存策略：已到达而尚未进入结构的新样本保留到下一次 full update，
之后释放，仅留下原代表点选择 API 选出的 memory。checkpoint 必须保存
该 pending cache，否则恢复会丢失样本/质量。此缓存计入 working memory。
"""
import argparse
import json
import math
from pathlib import Path
import time
import uuid
import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision.datasets import CIFAR10, CIFAR100
from data.task_free_stream import (load_protocol_manifest, learner_view_from_manifest,
                                  verify_task_free_protocol, _sha256_int64)
from data.cifar10_strict_stream import set_random_seed
from models.resnet18_cifar import ResNet18_CIFAR
from .task_free_config import TaskFreeConfig
from .task_free_trainer import TaskFreeTrainer
from .task_free_gb import GranularBallHistory, feature_tensor
from .data import ImageDataset
from .evaluation import evaluate_features

ROOT=Path(__file__).resolve().parents[1]


def resolve_device(requested):
    """smoke 与正式运行共用；显式要求 CUDA 时不可静默回退 CPU。"""
    if requested not in ('auto','cpu','cuda'):
        raise ValueError('device must be auto, cpu or cuda')
    available=torch.cuda.is_available()
    if requested=='cuda' and not available:
        raise RuntimeError('Requested CUDA but this Python/PyTorch environment has no available CUDA device; '
                           'use --device auto/--device cpu or a CUDA-enabled environment.')
    return torch.device(('cuda' if available else 'cpu') if requested=='auto' else requested)


def prepare_output(path,root=None):
    #创建独立输出目录，禁止覆盖已有目录
    root=(root or ROOT/'out/task_free').resolve()
    path=Path(path).resolve()
    if not path.is_relative_to(root) or path==root:
        raise ValueError('Task-Free outputs must be a new subdirectory of out/task_free')
    path.mkdir(parents=True,exist_ok=False)
    return path


def smoke_limit(smoke,max_windows):
    '''检查窗口上限，限制
    smoke
    最多三个窗口'''
    limit=2 if smoke and max_windows is None else max_windows
    if limit is not None and (limit<1 or (smoke and limit>3)):
        raise ValueError('smoke is limited to 1..3 windows; max-windows must be positive')
    return limit


def test_evaluation_interval(config, args):
    """校验可选的测试间隔；测试必须落在已经完成粒球维护的窗口。

    None 保持原行为：每次完整维护后测试。显式指定 N 时，仅在窗口编号
    为 N 的倍数（以及数据流结束）测试，不改变维护或网络训练的频率。
    """
    interval=getattr(args,'eval_every_windows',None)
    if interval is None:
        return None
    if interval<1:
        raise ValueError('--eval-every-windows must be positive')
    maintenance=config.gb_full_update_interval_windows
    if interval%maintenance or config.warmup_windows%maintenance:
        raise ValueError('--eval-every-windows must align with fresh granular-ball maintenance; '
                         'choose a multiple of gb_full_update_interval_windows and align warmup_windows')
    return interval


def test_evaluation_due(window_index, interval, complete_stream):
    """完整数据流的最后一次维护始终测试；其余窗口遵循显式测试间隔。"""
    return complete_stream or interval is None or window_index%interval==0


def write_json(path,value):
    '''
    保存 JSON 文件，禁止覆盖和非有限数值
    '''
    with Path(path).open('x',encoding='utf-8') as f:
        json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)


def validation_hook(trainer,images,labels,history_fresh):
    """只前向：不选择模型、不更新参数。保留 RNG，使评估不改变后续 shuffle。

辅助 FC 评估 global validation 全部类；粒球只在刚维护且类齐全时评估
已见类别子集，显式记录范围；旧几何不冒充当前网络下的新粒球。
"""
    model=trainer.model; was_training=model.training
    devices=[trainer.device.index or 0] if trainer.device.type=='cuda' else []
    with torch.random.fork_rng(devices=devices),torch.no_grad():
        model.eval(); correct=0
        for x,y in DataLoader(ImageDataset(images,labels),batch_size=trainer.config.feature_batch_size):
            correct+=int((model(x.to(trainer.device))[0].argmax(1).cpu()==y).sum())
        result={'auxiliary_fc_accuracy':correct/len(labels),'validation_sample_count':len(labels),
                'selection_used':False,'gb_status':'not_fresh_or_not_initialized'}
        h=trainer.history
        if history_fresh and h.records:
            z=feature_tensor(model,images,labels,trainer.device,trainer.config.feature_batch_size)
            result['granular_ball']=evaluate_features(h.project_numpy(z.cpu().numpy()),labels,h.records,
                                                     sorted(trainer.seen_classes),trainer.config.epsilon,
                                                     classifier_mode=trainer.config.classifier_mode)
            result['gb_status']='ok_seen_classes_only'
    model.train(was_training)
    return result


def nearest_center_evaluation(features, labels, records, seen_classes, batch_size=512):
    """Evaluate the nearest-ball-center ablation in the saved ball feature space.

    This is deliberately a classifier-only alternative: it ignores ball
    radii, coverage, and response aggregation. The model and current ball
    structure are shared with the regular classifier evaluation.
    """
    if not records:
        raise ValueError('nearest-center evaluation requires granular balls')
    centers=np.stack([np.asarray(record['center'],dtype=np.float64)
                      for record in records])
    ball_labels=np.asarray([int(record['label']) for record in records],dtype=np.int64)
    expected=np.asarray(sorted(seen_classes),dtype=np.int64)
    if not np.array_equal(np.unique(ball_labels),expected):
        raise ValueError('nearest-center classifier requires balls for every seen class')
    center_norms=np.einsum('bd,bd->b',centers,centers)
    predictions=[]
    for start in range(0,len(features),batch_size):
        batch=np.asarray(features[start:start+batch_size],dtype=np.float64)
        squared=(np.einsum('nd,nd->n',batch,batch)[:,None]
                 +center_norms[None,:]-2.0*(batch@centers.T))
        # Floating-point cancellation can yield tiny negative squared distances.
        np.maximum(squared,0.0,out=squared)
        predictions.append(ball_labels[np.argmin(squared,axis=1)])
    prediction=np.concatenate(predictions) if predictions else np.empty(0,dtype=np.int64)
    accuracy=float(np.mean(prediction==labels)) if len(labels) else None
    return {
        'accuracy':accuracy,
        'accuracy_percent':None if accuracy is None else accuracy*100.0,
        'num_test_samples':int(len(labels)),
        'per_class_accuracy':{
            str(int(c)):float(np.mean(prediction[labels==c]==c))
            if np.any(labels==c) else None for c in expected},
        'distance':'euclidean_in_saved_ball_feature_space',
        'decision':'label_of_nearest_ball_center',
        'tie_break':'first_ball_in_checkpoint_order',
    }


def test_hook(trainer,images,labels,include_nearest_center=False):
    """调用测试集
    用刚维护完成的粒球测试已见类别；只读前向，不改变训练随机状态。

    测试集仅用于报告，绝不参与 loss、粒球生成、代表点选择或模型选择。
    过滤未见类别后再提取特征，避免在较早窗口浪费测试计算。
    """
    seen=np.asarray(sorted(trainer.seen_classes),dtype=np.int64)
    selected=np.isin(labels,seen)
    if not selected.any() or not trainer.history.records:
        raise ValueError('test evaluation requires maintained balls and seen-class samples')
    model=trainer.model
    was_training=model.training
    devices=[trainer.device.index or 0] if trainer.device.type=='cuda' else []
    try:
        with torch.random.fork_rng(devices=devices),torch.no_grad():
            z=feature_tensor(model,images[selected],labels[selected],trainer.device,
                             trainer.config.feature_batch_size)
            projected=trainer.history.project_numpy(z.cpu().numpy())
            result=evaluate_features(projected,labels[selected],trainer.history.records,
                                     seen,trainer.config.epsilon,
                                     classifier_mode=trainer.config.classifier_mode)
            output={'evaluation_split':'test','selection_used':False,'granular_ball':result}
            if include_nearest_center:
                output['nearest_ball_center']=nearest_center_evaluation(
                    projected,labels[selected],trainer.history.records,seen,
                    batch_size=trainer.config.feature_batch_size)
    finally:
        model.train(was_training)
    return output


def class_forgetting(evaluations, classifier_key='granular_ball'):
    """按已见类别计算当前遗忘率，首个观测没有历史基线时返回 None。

    对每个至少在先前维护点出现过的类别，计算历史及当前最佳准确率减去
    当前准确率；再对这些类别取平均。数值为 0..1 的比例，不是百分点。
    """
    current=(evaluations[-1][classifier_key]['per_class_accuracy']
             if evaluations else {})
    drops={}
    for label,value in current.items():
        prior=[row[classifier_key]['per_class_accuracy'].get(label)
               for row in evaluations[:-1]]
        prior=[float(x) for x in prior if x is not None and math.isfinite(float(x))]
        if value is not None and math.isfinite(float(value)) and prior:
            drops[label]=max([float(value),*prior])-float(value)
    return {'value':sum(drops.values())/len(drops) if drops else None,
            'per_class':drops,'classes':sorted(drops),
            'status':'OK' if drops else 'INSUFFICIENT_HISTORY',
            'scope':'class-level test; fresh maintenance observations only',
            'definition':'mean_c(max_observed accuracy[c] - current accuracy[c]); prior-observed classes only'}


def run(args):
    #读取固定数据流，组织窗口训练、粒球维护、验证和保存。
    config=TaskFreeConfig.load(args.config)
    for key in ('window_size','batch_size','local_epochs','warmup_windows',
                'gb_full_update_interval_windows','device'):
        if getattr(args,key,None) is not None:
            setattr(config,key,getattr(args,key))
    for override in args.set:
        key,separator,raw=override.partition('=')
        if not separator:
            raise ValueError('--set requires key=JSON_value')
        parts=key.split('.'); value=json.loads(raw)
        if len(parts)==1 and key in config.to_dict():
            setattr(config,key,value)
        elif len(parts)==2 and parts[0] in ('optimizer','scheduler') and parts[1] in getattr(config,parts[0]):
            getattr(config,parts[0])[parts[1]]=value
        else:
            raise ValueError(f'unknown override {key}')
    limit=smoke_limit(args.smoke,args.max_windows)
    if args.smoke:
        config.cpu_threads=1
    config.validate()
    eval_every_windows=test_evaluation_interval(config,args)
    if eval_every_windows is not None and not getattr(args,'evaluate_test',False):
        raise ValueError('--eval-every-windows requires --evaluate-test')
    if args.compare_nearest_center and not getattr(args,'evaluate_test',False):
        raise ValueError('--compare-nearest-center requires --evaluate-test')
    device=resolve_device(config.device)
    print(f'[device] requested={config.device}, cuda_available={torch.cuda.is_available()}, '
          f'network_and_features={device}, granular_ball_maintenance=cpu',flush=True)
    if device.type=='cuda':
        print(f'[device] GPU={torch.cuda.get_device_name(device)}',flush=True)
    # manifest hash 在协议模块校验；这里唯一的消费接口是白名单 learner view。
    view=learner_view_from_manifest(load_protocol_manifest(args.protocol))
    if view['dataset']=='Split-MNIST' and config.horizontal_flip:
        raise ValueError('Split-MNIST requires horizontal_flip=false; use its generated config.json')
    if view['seed']!=config.seed:
        raise ValueError('protocol/config seed mismatch')

    #数据集
    evaluate_test=bool(getattr(args,'evaluate_test',False))
    index_path=getattr(args,'dataset_index',None)
    if index_path:
        from data.external_datasets import load_index, IndexedSource
        index=load_index(index_path)
        if index['dataset']!=view['dataset'] or index['index_sha256']!=view.get('dataset_index_sha256'):
            raise ValueError('Dataset index does not match fixed protocol')
        source=IndexedSource(index,args.data_root,'train')
        test_source=IndexedSource(index,args.data_root,'test') if evaluate_test else None
    else:
        cls={'CIFAR-10':CIFAR10,'CIFAR-100':CIFAR100}.get(view['dataset'])
        if cls is None:
            raise ValueError('External image dataset requires --dataset-index from data.prepare_dataset')
        source=cls(root=args.data_root,train=True,download=False)
        test_source=cls(root=args.data_root,train=False,download=False) if evaluate_test else None
    raw_y=np.asarray(source.targets,dtype=np.int64)
    if _sha256_int64(raw_y)!=view['labels_sha256'] or np.unique(raw_y).tolist()!=view['class_values']:
        raise ValueError('dataset labels do not match protocol')
    verify_task_free_protocol(raw_y,view['train_stream_ids'],view['validation_ids'])
    # FC 标签转连续索引；原 class_values 保存到输出，可逆映射，不向 learner 暴露分布信息。
    labels=np.searchsorted(view['class_values'],raw_y)
    if evaluate_test:
        test_raw_y=np.asarray(test_source.targets,dtype=np.int64)
        if not np.isin(test_raw_y,view['class_values']).all():
            raise ValueError('test labels do not match protocol class values')
        test_labels=np.searchsorted(view['class_values'],test_raw_y)
    stream=np.asarray(view['train_stream_ids'],dtype=np.int64)
    val_ids=np.asarray(view['validation_ids'],dtype=np.int64)
    set_random_seed(config.seed); torch.set_num_threads(config.cpu_threads)
    history=GranularBallHistory(config,device)
    trainer=TaskFreeTrainer(ResNet18_CIFAR(num_classes=len(view['class_values'])),config,device,history)
    print(f'[device] model_parameters={next(trainer.model.parameters()).device}',flush=True)
    pending_ids=np.empty(0,dtype=np.int64)
    pending_x=source.data[:0].copy(); pending_y=labels[:0].copy()
    last_update_window=0
    test_history=[]
    test_history_complete=True
    nearest_center_history=[]
    nearest_center_history_complete=True
    if args.resume:
        state=trainer.load(args.resume,view['protocol_sha256']); extra=state['extra']
        if extra['smoke']!=args.smoke:
            raise ValueError('cannot mix smoke and formal checkpoints')
        pending_ids=extra['pending_ids']; pending_x=extra['pending_images']; pending_y=extra['pending_labels']
        last_update_window=extra['last_update_window']
        if evaluate_test:
            test_history=extra.get('test_history',[])
            test_history_complete=extra.get('test_history_complete',trainer.stream_position==0)
            if args.compare_nearest_center:
                if 'nearest_center_history' not in extra:
                    raise ValueError(
                        'nearest-center trajectory ablation needs a checkpoint created '
                        'with --compare-nearest-center from the beginning; historical '
                        'model/ball states cannot be reconstructed from latest.pth')
                nearest_center_history=extra['nearest_center_history']
                nearest_center_history_complete=extra.get(
                    'nearest_center_history_complete',False)
        if trainer.stream_position!=min(trainer.window_index*config.window_size,len(stream)):
            raise ValueError('checkpoint position/window mismatch')
        allowed=stream[:trainer.stream_position]
        if not np.isin(np.concatenate([pending_ids,history.memory.sample_ids,
                                      history.ce_replay_extra.sample_ids]),allowed).all():
            raise ValueError('checkpoint contains inaccessible samples')
    name=('smoke' if args.smoke else 'formal')+'_'+uuid.uuid4().hex[:10]
    output=prepare_output(args.output or ROOT/'out/task_free/runs'/name)
    write_json(output/'settings.json',{'config':config.to_dict(),'smoke':args.smoke,'protocol_hash':view['protocol_sha256'],
        'resolved_device':str(device),'granular_ball_maintenance_device':'cpu',
        'protocol_path':str(Path(args.protocol).resolve()),'class_values':view['class_values'],
        'dataset_index_sha256':view.get('dataset_index_sha256'),
        'data_root':str(Path(args.data_root).resolve()),'image_size':source.data.shape[1],
        'pending_policy':'retain_until_full_update; user-confirmed working-memory policy',
        'light_update':'TODO: no safe existing light/full API',
        'historical_target':'cached after full maintenance until next maintenance',
        'representative_replay_policy':(
            ('class_balanced_cycle_v1; equal class quotas; class-local no-replacement cycles; '
             'reset on maintenance' if config.representative_replay_sampling=='class_balanced_cycle'
             else 'shuffled_cycle_v1; partial tail; reset on maintenance')
            if config.representative_replay_batch_size else 'disabled'),
        'ce_replay_extra_policy':(
            'shared raw-image budget; class/ball round-robin; CE only; '
            'granular-ball anchors and historical loss unchanged'
            if config.ce_replay_fill_budget else 'disabled'),
        'warmup_replay_policy':(
            f'previous completed windows only; at most {config.warmup_replay_capacity} '
            'temporary images; CE replay ends at first ball maintenance'
            if config.warmup_replay_capacity else 'disabled'),
        'final_classifier':f'{config.classifier_mode}; auxiliary FC only for CE',
        'test_evaluation':{'enabled':evaluate_test,
                           'timing':('after each full maintenance and after complete stream'
                                     if eval_every_windows is None else
                                     f'every {eval_every_windows} windows after full maintenance and at stream end'),
                           'eval_every_windows':eval_every_windows,'selection_used':False},
        'classifier_ablation':{
            'nearest_ball_center_enabled':bool(args.compare_nearest_center),
            'decision':'label of Euclidean-nearest ball center; ignores radius and response',
            'same_model_and_ball_structure':True,
        },
        'resume_source':str(args.resume) if args.resume else None})
    target=min(limit or math.ceil(len(stream)/config.window_size),math.ceil(len(stream)/config.window_size))
    if trainer.window_index>=target:
        raise ValueError('max-windows is absolute, must exceed restored window_index')
    logs=[]
    while trainer.stream_position<len(stream) and trainer.window_index<target:
        started=time.perf_counter()
        ids=stream[trainer.stream_position:trainer.stream_position+config.window_size]
        x=source.data[ids].copy(); y=labels[ids].copy()
        # 首次建球前没有代表点。可选的 warmup 回放仅引用之前已完成的
        # 窗口；当前 x/y 尚未追加到 pending，因此不会回放当前窗口图像。
        warmup_replay=(pending_x,pending_y,pending_ids) if (
            config.warmup_replay_capacity and not history.records and len(pending_ids)) else None
        log=trainer.train_window(x,y,warmup_replay=warmup_replay)
        pending_ids=np.concatenate([pending_ids,ids]); pending_x=np.concatenate([pending_x,x]); pending_y=np.concatenate([pending_y,y])
        peak_pending=len(pending_ids)
        fresh=False
        ready=trainer.window_index>=config.warmup_windows
        due=(not history.records or trainer.window_index-last_update_window>=config.gb_full_update_interval_windows
             or trainer.stream_position==len(stream))
        if ready and due:
            maintenance_started=time.perf_counter()
            log['structure']=history.full_update(trainer.model,pending_x,pending_y,pending_ids)
            log['granular_ball_maintenance_seconds']=time.perf_counter()-maintenance_started
            if evaluate_test and test_evaluation_due(
                    trainer.window_index,eval_every_windows,trainer.stream_position==len(stream)):
                log['test']=test_hook(
                    trainer,test_source.data,test_labels,
                    include_nearest_center=args.compare_nearest_center)
                test_history.append(log['test'])
                log['test']['forgetting']=class_forgetting(test_history)
                if not test_history_complete:
                    log['test']['forgetting'].update(value=None,status='INCOMPLETE_HISTORY')
                log['test_accuracy']=log['test']['granular_ball']['accuracy']
                log['test_forgetting']=log['test']['forgetting']['value']
                if args.compare_nearest_center:
                    nearest_row={
                        'window_index':int(trainer.window_index),
                        'nearest_ball_center':log['test']['nearest_ball_center'],
                    }
                    nearest_center_history.append(nearest_row)
                    nearest_row['nearest_ball_center']['forgetting']=class_forgetting(
                        nearest_center_history,'nearest_ball_center')
                    log['nearest_center_accuracy']=(
                        nearest_row['nearest_ball_center']['accuracy'])
                    log['nearest_center_forgetting']=(
                        nearest_row['nearest_ball_center']['forgetting']['value'])
                print(f"[test] window={trainer.window_index} "
                      f"accuracy={log['test_accuracy']:.4f} "
                      f"forgetting={log['test_forgetting']}",flush=True)
                if args.compare_nearest_center:
                    print(f"[classifier-ablation] window={trainer.window_index} "
                          f"nearest_center_accuracy={log['nearest_center_accuracy']:.4f} "
                          f"forgetting={log['nearest_center_forgetting']}",flush=True)
            # 不能用 array[:0]：零长度 view 仍持有整个旧 buffer 的 base，实际没有释放。
            pending_ids=np.empty(0,dtype=np.int64)
            pending_x=np.empty((0,*x.shape[1:]),dtype=x.dtype)
            pending_y=np.empty(0,dtype=y.dtype)
            last_update_window=trainer.window_index; fresh=True
        log.update(smoke=args.smoke,training_device=str(device),working_samples_before_maintenance=peak_pending,
                   pending_samples=len(pending_ids),pending_payload_bytes=pending_x.nbytes+pending_y.nbytes+pending_ids.nbytes,
                   memory_size=len(history.memory.labels)+len(history.ce_replay_extra.labels),
                   gb_anchor_memory_size=len(history.memory.labels),
                   ce_extra_memory_size=len(history.ce_replay_extra.labels),
                   number_of_balls=len(history.records),
                   effective_mass=sum(r['effective_count'] for r in history.records),
                   discarded_effective_mass_total=history.discarded_effective_mass_total,
                   maintenance_revision=history.revision)
        accounted_mass=(log['effective_mass']+log['discarded_effective_mass_total']
                        +len(pending_ids))
        log['accounted_effective_mass']=accounted_mass
        if not np.isclose(accounted_mass,trainer.stream_position):
            raise AssertionError(
                'retained, discarded and pending mass must equal arrived samples')
        if config.validation_interval_samples and trainer.stream_position%config.validation_interval_samples==0:
            log['validation']=validation_hook(trainer,source.data[val_ids],labels[val_ids],fresh)
        log['runtime_seconds']=time.perf_counter()-started
        write_json(output/f'window_{trainer.window_index:06d}.json',log)
        trainer.save(output/'latest.pth',view['protocol_sha256'],extra={
            'pending_ids':pending_ids,'pending_images':pending_x,'pending_labels':pending_y,
            'last_update_window':last_update_window,'smoke':args.smoke,
            'test_history':test_history if evaluate_test else [],
            'test_history_complete':test_history_complete if evaluate_test else False,
            'nearest_center_history':nearest_center_history if (
                evaluate_test and args.compare_nearest_center) else [],
            'nearest_center_history_complete':nearest_center_history_complete if (
                evaluate_test and args.compare_nearest_center) else False})
        logs.append(log)
        print(json.dumps(log,ensure_ascii=False),flush=True)
    summary={'smoke':args.smoke,'stream_position':trainer.stream_position,
        'stream_length':len(stream),'complete_stream':trainer.stream_position==len(stream),
        'window_index':trainer.window_index,'optimizer_steps':trainer.optimizer_steps,
        'sample_accesses':trainer.sample_accesses,
        'replay_sample_accesses':trainer.replay_sample_accesses,
        'checkpoint':str(output/'latest.pth'),
        'protocol_hash':view['protocol_sha256'],'windows_this_invocation':len(logs)}
    if evaluate_test:
        summary['test_evaluation_count']=len(test_history)
        summary['test_history_complete']=test_history_complete
        if trainer.stream_position==len(stream):
            # 最后一个窗口维护后已评估一次；这里明确再测最终保存状态，
            # 让最终 ACC/遗忘率拥有独立的汇总记录。
            final_test=test_hook(
                trainer,test_source.data,test_labels,
                include_nearest_center=args.compare_nearest_center)
            final_test['forgetting']=class_forgetting([*test_history[:-1],final_test])
            if not test_history_complete:
                final_test['forgetting'].update(value=None,status='INCOMPLETE_HISTORY')
            summary['final_test']=final_test
            summary['final_test_accuracy']=final_test['granular_ball']['accuracy']
            summary['final_test_forgetting']=final_test['forgetting']['value']
            if args.compare_nearest_center:
                final_nearest_history=[
                    *nearest_center_history[:-1],
                    {'window_index':int(trainer.window_index),
                     'nearest_ball_center':final_test['nearest_ball_center']},
                ]
                final_test['nearest_ball_center']['forgetting']=class_forgetting(
                    final_nearest_history,'nearest_ball_center')
            write_json(output/'final_test.json',final_test)
            print(json.dumps({'final_test_accuracy':summary['final_test_accuracy'],
                              'final_test_forgetting':summary['final_test_forgetting']},
                             ensure_ascii=False),flush=True)
        if args.compare_nearest_center:
            effective_nearest_history=nearest_center_history
            if trainer.stream_position==len(stream):
                # 使用独立的最终测试结果替换同窗口周期测试项，避免将最终窗口重复计入平均准确率。
                effective_nearest_history=[
                    *nearest_center_history[:-1],
                    {'window_index':int(trainer.window_index),
                     'nearest_ball_center':final_test['nearest_ball_center']},
                ]
                nearest_forgetting=class_forgetting(
                    effective_nearest_history,'nearest_ball_center')
                final_test['nearest_ball_center']['forgetting']=nearest_forgetting
            else:
                nearest_forgetting=(
                    effective_nearest_history[-1]['nearest_ball_center'].get('forgetting')
                    if effective_nearest_history else None)
            nearest_accuracies=[
                float(row['nearest_ball_center']['accuracy'])
                for row in effective_nearest_history
                if row['nearest_ball_center'].get('accuracy') is not None]
            summary['nearest_center_ablation']={
                'decision':'label of Euclidean-nearest ball center; radius and response ignored',
                'evaluation_split':'test',
                'average_accuracy_definition':(
                    'arithmetic mean of test accuracies at scheduled evaluation windows; '
                    'each accuracy is over classes seen by that window'),
                'evaluation_count':len(effective_nearest_history),
                'evaluation_windows':[row['window_index'] for row in effective_nearest_history],
                'average_accuracy':(sum(nearest_accuracies)/len(nearest_accuracies)
                                    if nearest_accuracies else None),
                'final_accuracy':(nearest_accuracies[-1] if nearest_accuracies else None),
                'final_forgetting':(nearest_forgetting.get('value')
                                    if nearest_forgetting else None),
                'forgetting_detail':nearest_forgetting,
                'history_complete':nearest_center_history_complete,
            }
            summary['nearest_center_history']=effective_nearest_history
    write_json(output/'summary.json',summary)
    print(f'Saved Task-Free run: {output}',flush=True)
    return output


def main():
    #解析命令行参数并启动运行。
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--config',required=True)
    p.add_argument('--protocol',required=True)
    p.add_argument('--data-root',default=str(ROOT/'data'))
    p.add_argument('--dataset-index',help='Portable external image index from data.prepare_dataset')
    p.add_argument('--output',type=Path)
    p.add_argument('--resume',type=Path)
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--max-windows',type=int)
    for key in ('window-size','batch-size','local-epochs','warmup-windows','gb-full-update-interval-windows'):
        p.add_argument('--'+key,type=int)
    p.add_argument('--device',choices=['auto','cpu','cuda'])
    p.add_argument('--evaluate-test',action='store_true',
                   help='Report test accuracy and class forgetting after maintenance and at stream end')
    p.add_argument('--eval-every-windows',type=int,
                   help='Test at multiples of N windows after fresh ball maintenance; '
                        'default: after every full maintenance')
    p.add_argument('--compare-nearest-center',action='store_true',
                   help='At each scheduled test evaluation, also report nearest-ball-center '
                        'accuracy and its average-accuracy/forgetting trajectory')
    p.add_argument('--set',action='append',default=[],help='Any config key or optimizer.learning_rate=0.01, using JSON values')
    run(p.parse_args())


if __name__=='__main__':
    main()
