"""Task-Free 适配：复用原粒球几何/代表点，按模式选择历史约束。

旧 API 的整数命名参数仅接收 maintenance revision（与数据分布无关）。
历史响应或 core/radial 参考在维护后冻结，直到下次维护才刷新。
不持久化完整历史特征；FC + 真实标签 CE 仍由 trainer 原样计算。
"""
import numpy as np
import torch
from torch.utils.data import DataLoader
from torch.utils.checkpoint import checkpoint
from .data import ImageDataset
from .memory import Memory, reselect_memory, select_balls_for_budget
from .ball_update import (generate_new_balls, refine_intra, resolve_conflicts,
                          merge_redundant, remove_singleton_outliers,
                          update_structure, IdFactory, safe_conflict_info)
from .topology import build_current_ball_topology, build_topology_from_records, validate_topology
from . import losses
from .ce_replay import select_ce_replay_extra


def feature_tensor(model, images, labels, device, batch_size, grad=False):
    """和现有 extract_features 同样 eval/无增强；仅取消多进程加载开销。"""
    model.eval()
    parts=[]
    with torch.set_grad_enabled(grad):
        for x,_ in DataLoader(ImageDataset(images,labels),batch_size=batch_size,num_workers=0):
            x=x.to(device)
            z=(checkpoint(lambda b:model(b)[1],x,use_reentrant=False) if grad else model(x)[1])
            parts.append(z)
    if not parts:
        raise ValueError('feature extraction requires nonempty support')
    return torch.cat(parts)


class GranularBallHistory:
    supports_replay_ball_subset = True

    #初始化空粒球、代表点、拓扑和历史参考。
    def __init__(self,config,device):
        self.config=config
        self.device=device
        self.records=[]
        self.memory=Memory.empty()
        # 仅供 CE 回放。这里的图片不进入球的有限支撑、几何参考或 L_gb。
        self.ce_replay_extra=Memory.empty()
        self.triples=np.empty((0,3),dtype='U64')
        self.old_response=None
        self.gb_reference={}
        self.revision=0
        # Removed singleton outliers are intentionally no longer represented by
        # a ball.  Keep their mass separately so global arrived-sample accounting
        # remains exact without assigning outlier mass to an unrelated ball.
        self.discarded_effective_mass_total=0.0
        self.last_loss_memory_accesses=0
        # None 表示原始网络特征；有值时所有粒球几何、历史损失和分类都
        # 使用同一套首次维护时拟合的 PCA 坐标，不随窗口重新拟合坐标轴。
        self.projection_mean=None
        self.projection_components=None
        self.projection_explained_variance=None

    def _fit_projection(self, features):
        """仅在首次建球时用已到达训练样本拟合一次 PCA。"""
        dim=self.config.feature_projection_dim
        if not dim or self.projection_components is not None:
            return
        if features.ndim != 2 or dim >= min(features.shape):
            raise ValueError(
                f'feature_projection_dim={dim} must be smaller than both '
                f'the first maintenance sample count and feature dimension {features.shape}'
            )
        # 局部 random_state 不消耗训练全局随机状态；validation/test 不参与拟合。
        from sklearn.decomposition import PCA
        pca=PCA(n_components=dim,svd_solver='randomized',random_state=self.config.seed)
        pca.fit(features)
        self.projection_mean=np.asarray(pca.mean_,dtype=np.float32).copy()
        self.projection_components=np.asarray(pca.components_,dtype=np.float32).copy()
        self.projection_explained_variance=float(pca.explained_variance_ratio_.sum())
        if not np.isfinite(self.projection_explained_variance):
            raise ValueError('PCA cannot fit features with zero total variance')

    def project_numpy(self, features):
        """统一粒球维护、代表点选择和评估所用的特征空间。

        先应用首次维护时固定的 PCA（若启用），再按配置进行 L2 单位化。
        后续建球、半径、冲突、合并仍在变换后的空间采用原欧氏定义；
        不把 1-cosine 冒充成具有完整球包含性质的欧氏距离。
        """
        projected = features
        if self.config.feature_projection_dim:
            if self.projection_components is None:
                raise ValueError('PCA projection is not fitted; first maintenance is required')
            if features.shape[-1] != self.projection_components.shape[1]:
                raise ValueError('network feature dimension does not match saved PCA projection')
            projected = (features-self.projection_mean) @ self.projection_components.T
        if self.config.ball_feature_metric == 'unit_euclidean':
            norms = np.linalg.norm(projected, axis=-1, keepdims=True)
            return projected / np.maximum(norms, self.config.epsilon)
        return projected

    def project_tensor(self, features):
        """与 project_numpy 相同的可微变换，供粒球损失反传使用。"""
        projected = features
        if self.config.feature_projection_dim:
            if self.projection_components is None:
                raise ValueError('PCA projection is not fitted; first maintenance is required')
            if features.shape[-1] != self.projection_components.shape[1]:
                raise ValueError('network feature dimension does not match saved PCA projection')
            mean=torch.as_tensor(self.projection_mean,device=features.device,dtype=features.dtype)
            components=torch.as_tensor(self.projection_components,device=features.device,dtype=features.dtype)
            projected = (features-mean) @ components.T
        if self.config.ball_feature_metric == 'unit_euclidean':
            norms=torch.linalg.vector_norm(projected,dim=-1,keepdim=True)
            return projected / norms.clamp_min(self.config.epsilon)
        return projected

    def full_update(self,model,images,labels,sample_ids):
        #维护粒球、重选代表点、重建拓扑，并冻结下一周期的参考。
        if not len(sample_ids):
            raise ValueError('full update needs newly arrived samples')
        if np.intersect1d(sample_ids,self.memory.sample_ids).size:
            raise ValueError('new samples cannot duplicate representatives')
        pool_x=(np.concatenate([self.memory.images,images]) if len(self.memory.labels)
                else images.copy())
        pool_y=np.concatenate([self.memory.labels,labels])
        pool_ids=np.concatenate([self.memory.sample_ids,sample_ids])
        features=feature_tensor(model,pool_x,pool_y,self.device,self.config.feature_batch_size).cpu().numpy()
        if not self.records:
            self._fit_projection(features)
        features=self.project_numpy(features)
        self.revision+=1
        if not self.records:
            events=[]
            ids=IdFactory(self.revision)
            balls=generate_new_balls(features,pool_y,np.arange(len(features)),
                                     ids,self.config,events)
            # 首次维护没有历史球，全部初始球均属于本次新球。先完成结构优化，
            # 再由下方的 reselect_memory 从最终球中选择下一周期的代表点。
            if self.config.intra_refinement:
                balls=refine_intra(
                    balls,features,ids,events,labels=pool_y,
                    mode=self.config.intra_split_mode,
                    min_child_samples=self.config.quality_min_child_samples,
                    min_child_fraction=self.config.quality_min_child_fraction,
                    min_bw_ratio=self.config.quality_min_bw_ratio,
                    epsilon=self.config.epsilon,
                    compute_conflict_diagnostics=self.config.max_hetero_splits>0)
            balls,accepted=resolve_conflicts(
                balls,features,ids,self.config.max_hetero_splits,events)
            balls=merge_redundant(
                balls,features,ids,events,
                mode=self.config.redundant_merge_mode,
                epsilon=self.config.epsilon)
            discarded_rows=np.empty(0,dtype=np.int64)
            discarded_mass=0.0
            if self.config.remove_singleton_balls:
                balls,discarded_rows,discarded_mass=remove_singleton_outliers(
                    balls,events,epsilon=self.config.epsilon)
            conflict_diagnostics_enabled=self.config.max_hetero_splits>0
            if conflict_diagnostics_enabled:
                C,O,pairs,_=safe_conflict_info(features,balls)
                final_conflict_pairs=len(pairs)
            else:
                C=O=final_conflict_pairs=None
            result={'events':events,'final_C':C,'final_O':O,
                    'final_conflict_pairs':final_conflict_pairs,
                    'conflict_diagnostics_enabled':conflict_diagnostics_enabled,
                    'accepted_conflict_splits':accepted}
            result['discarded_singleton_count']=len(discarded_rows)
            result['discarded_effective_mass']=discarded_mass
            result['new_ball_generation_mode']='classwise'
        else:
            balls,result=update_structure(features,pool_y,self.records,self.memory,self.config,self.revision)
        # A positive raw-image budget is a ceiling. fixed5/fixed_k preserve
        # their per-ball geometric picks when they fit; overflow uses the
        # existing explicit structure-pruning policy.
        fixed_k_capped=(self.config.representative_selection_mode in ('fixed5', 'fixed_k') and
                       self.config.representative_memory_budget>0)
        if self.config.representative_selection_mode=='budgeted_fast' or fixed_k_capped:
            balls,removed,budget_discarded=select_balls_for_budget(
                balls,self.config.representative_memory_budget,
                retain_limit=(self.config.representative_memory_budget
                              if fixed_k_capped else None))
            result['discarded_budget_ball_count']=len(removed)
            result['discarded_budget_ball_ids']=[str(ball.ball_id) for ball in removed]
            result['discarded_budget_effective_mass']=budget_discarded
            result['budget_overflow_lost_classes']=sorted(
                set(int(ball.label) for ball in removed)
                - set(int(ball.label) for ball in balls))
            result['discarded_effective_mass']=(
                float(result.get('discarded_effective_mass',0.0))
                + budget_discarded)
            if removed:
                result['events'].append({
                    'type':'memory_budget_ball_prune',
                    'removed_ball_ids':result['discarded_budget_ball_ids'],
                    'discarded_effective_mass':budget_discarded})
        discarded_now=float(result.get('discarded_effective_mass',0.0))
        self.discarded_effective_mass_total += discarded_now
        self.memory=reselect_memory(
            balls,features,pool_x,pool_y,pool_ids,
            selection_mode=self.config.representative_selection_mode,
            min_per_ball=self.config.representative_min_per_ball,
            max_per_ball=self.config.representative_max_per_ball,
            coverage_error=self.config.representative_coverage_error,
            memory_budget=self.config.representative_memory_budget,
            quota_offset=max(0,self.revision-1),
            epsilon=self.config.epsilon,
            random_seed=self.config.seed)
        if ((self.config.representative_selection_mode=='budgeted_fast' or
             fixed_k_capped) and
                len(self.memory.labels)>self.config.representative_memory_budget):
            raise AssertionError('representative memory exceeded its hard budget')
        self.records=[b.record(pool_ids) for b in balls]
        for record in self.records:
            # 原 record() 中 CIFAR10 字样仅为存储标注，适配为数据集无关行号。
            record['index_space']='dataset_train_global'
        # Topology is a view of this maintenance revision only.  Rebuild it
        # after every new/merge/split/refine operation and after memory/records
        # have been finalized; never carry parent IDs forward.
        self.triples=build_current_ball_topology(balls)
        validate_topology(self.triples, [r['ball_id'] for r in self.records],
                          context='Task-Free full_update')
        if self.config.ce_replay_fill_budget:
            # 旧 CE-only 图片不属于本轮粒球维护池。仅为重新关联到当前同类球
            # 提取其新网络特征，随后在共享图像预算内重选 CE 回放图片。
            previous_features=(self.project_numpy(feature_tensor(
                model,self.ce_replay_extra.images,self.ce_replay_extra.labels,
                self.device,self.config.feature_batch_size).cpu().numpy())
                if len(self.ce_replay_extra.labels) else
                np.empty((0,features.shape[1]),dtype=features.dtype))
            self.ce_replay_extra=select_ce_replay_extra(
                balls,pool_x,pool_y,pool_ids,self.memory,self.ce_replay_extra,
                previous_features,self.config.representative_memory_budget,
                self.config.seed,self.revision)
            if len(self.memory.labels)+len(self.ce_replay_extra.labels) > self.config.representative_memory_budget:
                raise AssertionError('shared CE and granular-ball memory exceeded its budget')
            if np.intersect1d(self.memory.sample_ids,self.ce_replay_extra.sample_ids).size:
                raise AssertionError('CE replay duplicates granular-ball anchor images')
        # 必须在最终 balls、memory、records、topology 都确定之后重新提取。
        # 缓存只由 full_update 刷新；loss 和 checkpoint 恢复都不能重建目标。
        if self.config.lambda_gb == 0:
            # L_gb-off ablations do not need geometric targets or another
            # historical-image forward pass. Keep the memory only for CE replay.
            self.gb_reference={}
            self.old_response=None
        else:
            old=self.project_tensor(feature_tensor(
                model,self.memory.images,self.memory.labels,self.device,self.config.feature_batch_size))
            if self.config.gb_loss_mode=='core_radial':
                self.gb_reference=losses.build_core_radial_reference(
                    old,self.memory.ball_ids,self.memory.roles,self.records,self.config.epsilon)
                self.old_response=None
            else:
                # 旧模式仍使用原始球中心/半径的响应缓存，不改变旧实验公式。
                self.gb_reference={}
                centers=torch.as_tensor(np.stack([r['center'] for r in self.records]),dtype=old.dtype,device=self.device)
                radii=torch.as_tensor([r['radius'] for r in self.records],dtype=old.dtype,device=self.device)
                self.old_response=losses.response_matrix(old,centers,radii,self.config.epsilon).detach()
        result.update(revision=self.revision,number_of_balls=len(self.records),
                      memory_size=len(self.memory.labels)+len(self.ce_replay_extra.labels),
                      gb_anchor_memory_size=len(self.memory.labels),
                      ce_extra_memory_size=len(self.ce_replay_extra.labels),
                      feature_dimension=features.shape[1],
                      projection_explained_variance=self.projection_explained_variance,
                      effective_mass=sum(r['effective_count'] for r in self.records),
                      discarded_effective_mass_total=self.discarded_effective_mass_total,
                      accounted_effective_mass=(sum(r['effective_count'] for r in self.records)
                                                + self.discarded_effective_mass_total))
        representative_counts=np.unique(self.memory.ball_ids,return_counts=True)[1]
        count_values,count_frequencies=np.unique(representative_counts,return_counts=True)
        selection_summary={
            'mode':self.config.representative_selection_mode,
            'memory_budget':self.config.representative_memory_budget,
            'memory_size_by_class':{
                str(int(label)):int(count)
                for label,count in zip(*np.unique(self.memory.labels,return_counts=True))},
            'actual_min':int(representative_counts.min()) if len(representative_counts) else 0,
            'actual_mean':float(representative_counts.mean()) if len(representative_counts) else 0.,
            'actual_max':int(representative_counts.max()) if len(representative_counts) else 0,
            'count_histogram':{str(int(count)):int(frequency)
                               for count,frequency in zip(count_values,count_frequencies)}}
        selection_summary['gb_core_eligible_balls']=int(np.sum(representative_counts>=2))
        selection_summary['gb_radial_eligible_balls']=int(np.sum(representative_counts>=3))
        if self.config.representative_memory_budget:
            selection_summary['budget_utilization']=(
                len(self.memory.labels)/self.config.representative_memory_budget)
        if self.config.representative_selection_mode not in (
                'class_balanced_budget','budgeted_fast','random_members'):
            selection_summary.update(
                min_per_ball=self.config.representative_min_per_ball,
                max_per_ball=self.config.representative_max_per_ball,
                coverage_error_threshold=self.config.representative_coverage_error)
        result['representative_selection']=selection_summary
        return result

    def loss(self,model,current_features,active_ball_ids=None):
        #重新提取当前代表点特征，计算历史损失及日志值。
        c=self.config
        enabled_gb=c.lambda_gb>0
        enabled_struct=c.lambda_struct>0
        enabled_overlap=c.lambda_overlap>0
        self.last_loss_memory_accesses=0

        # 系数为 0 的项不参与目标，因此也不应继续执行昂贵的代表点特征
        # 提取、代理球构造或两两几何计算。CE-only 时直接返回与当前计算图
        # 相连的零值；日志仍保留全部字段，便于不同消融结果使用同一格式。
        if not (enabled_gb or enabled_struct or enabled_overlap):
            zero=losses.zero_loss(current_features)
            names=('gb','gb_resp','gb_mu','gb_r','gb_core','gb_radial','struct','overlap')
            return zero,{name:0. for name in names}

        current_features=self.project_tensor(current_features)
        memory_rows=np.arange(len(self.memory.labels),dtype=np.int64)
        if (c.gb_replay_ball_subset and enabled_gb and
                c.gb_loss_mode=='core_radial' and
                not (enabled_struct or enabled_overlap) and active_ball_ids is not None):
            active=np.asarray([str(value) for value in active_ball_ids],dtype='U64')
            memory_rows=np.flatnonzero(np.isin(self.memory.ball_ids,active))
        if len(memory_rows):
            memory_z=self.project_tensor(feature_tensor(
                model,self.memory.images[memory_rows],self.memory.labels[memory_rows],
                self.device,c.feature_batch_size,grad=True))
        else:
            memory_z=current_features.new_empty((0,current_features.shape[1]))
        self.last_loss_memory_accesses=int(len(memory_rows))
        memory_ball_ids=self.memory.ball_ids[memory_rows]
        memory_roles=self.memory.roles[memory_rows]
        # response/structure 模式、拓扑损失和 overlap 损失需要代理球；
        # 单独启用 core_radial 时只使用代表点相对几何，不重复构造代理球。
        needs_proxy=(enabled_struct or enabled_overlap or
                     (enabled_gb and c.gb_loss_mode in ('response','structure')))
        if needs_proxy:
            centers,radii,labels,ids=losses.proxy_balls(
                memory_z,memory_ball_ids,memory_roles,self.records)
        else:
            centers=memory_z.new_empty((0,memory_z.shape[1]))
            radii=memory_z.new_empty(0)
            labels=torch.empty(0,dtype=torch.long,device=memory_z.device)
            ids=[]
        #memory_z：当前网络提取的代表样本特征；self.memory.ball_ids：每个代表样本所属的粒球 ID；
        #self.memory.roles：代表样本角色，例如核心点、边界点、外围点；self.records：历史粒球记录
        resp=losses.zero_loss(memory_z)
        mu=losses.zero_loss(centers); radius=losses.zero_loss(radii)
        core=losses.zero_loss(memory_z); radial=losses.zero_loss(memory_z)
        if enabled_gb and c.gb_loss_mode in ('response','structure'):
            resp=losses.historical_response_loss(memory_z,self.old_response,centers,radii,epsilon=c.epsilon)
        if enabled_gb and c.gb_loss_mode=='structure':
            mu,radius=losses.center_radius_losses(centers,radii,self.records)
        if enabled_gb and c.gb_loss_mode=='core_radial':
            active_reference={str(ball_id):self.gb_reference[str(ball_id)]
                              for ball_id in np.unique(memory_ball_ids)
                              if str(ball_id) in self.gb_reference}
            core,radial=losses.core_radial_loss(
                memory_z,memory_ball_ids,memory_roles,active_reference,c.epsilon)
            # 两个相对几何项直接相加，不设置额外可调的内部系数。
            gb=core+radial
        else:
            gb=resp+c.alpha*mu+c.beta*radius
        # 这两项继续使用原 proxy_balls 的中心/最大半径，与新 outer 代理中心无关。
        struct=losses.zero_loss(memory_z)
        if enabled_struct:
            validate_topology(self.triples, ids, context='Task-Free topology_loss')
            struct=losses.topology_loss(centers,ids,self.triples)
        overlap=losses.zero_loss(memory_z)
        if enabled_overlap:
            overlap=losses.overlap_loss(
                centers,radii,labels,torch.cat([memory_z,current_features]))
        total=c.lambda_gb*gb+c.lambda_struct*struct+c.lambda_overlap*overlap
        values={'gb':gb,'gb_resp':resp,'gb_mu':mu,'gb_r':radius,
                'gb_core':core,'gb_radial':radial,'struct':struct,'overlap':overlap}
        if not all(torch.isfinite(v).all() for v in values.values()):
            raise FloatingPointError('nonfinite historical losses')
        logged={k:float(v.detach()) for k,v in values.items()}
        logged['gb_memory_samples']=float(len(memory_rows))
        logged['gb_selected_balls']=float(len(np.unique(memory_ball_ids)))
        if c.gb_loss_mode=='core_radial':
            _,counts=np.unique(memory_ball_ids,return_counts=True)
            logged['gb_core_balls']=float(np.sum(counts>=2))
            logged['gb_radial_balls']=float(np.sum(counts>=3))
        return total,logged

    def state_dict(self):
        #打包粒球历史和冻结参考用于保存
        # CPU 副本便于跨设备恢复；clone 防止保存出的 reference 与运行中缓存共享存储。
        reference={key:{'radius_scale':float(value['radius_scale']),
                        'core_distance':value['core_distance'].detach().cpu().clone(),
                        'radial_profile':value['radial_profile'].detach().cpu().clone()}
                   for key,value in self.gb_reference.items()}
        validate_topology(self.triples, [r['ball_id'] for r in self.records],
                          context='Task-Free checkpoint save')
        return {'records':self.records,'memory':vars(self.memory),
                'ce_replay_extra':vars(self.ce_replay_extra),'triples':self.triples,
                'old_response':self.old_response.cpu() if self.old_response is not None else None,
                'gb_reference':reference,
                'projection_mean':self.projection_mean,
                'projection_components':self.projection_components,
                'projection_explained_variance':self.projection_explained_variance,
                'revision':self.revision,
                'discarded_effective_mass_total':self.discarded_effective_mass_total}

    def load_state_dict(self,state):
        #恢复保存的历史状态，不重新估计参考
        self.projection_mean=state.get('projection_mean')
        self.projection_components=state.get('projection_components')
        self.projection_explained_variance=state.get('projection_explained_variance')
        if self.config.feature_projection_dim and state['records']:
            if (self.projection_mean is None or self.projection_components is None or
                    self.projection_components.shape[0] != self.config.feature_projection_dim or
                    self.projection_components.shape[1] != len(self.projection_mean)):
                raise ValueError('checkpoint PCA projection is missing or incompatible')
        elif self.projection_components is not None:
            raise ValueError('checkpoint has PCA projection but configuration disables it')
        self.records=state['records']; self.memory=Memory(**state['memory'])
        self.ce_replay_extra=Memory(**state['ce_replay_extra']) if 'ce_replay_extra' in state else Memory.empty()
        if self.config.ce_replay_fill_budget:
            if (len(self.memory.labels)+len(self.ce_replay_extra.labels) >
                    self.config.representative_memory_budget or
                    np.intersect1d(self.memory.sample_ids,self.ce_replay_extra.sample_ids).size):
                raise ValueError('checkpoint CE replay violates shared memory budget or unique IDs')
        elif len(self.ce_replay_extra.labels):
            raise ValueError('checkpoint contains CE-only replay but its config disables it')
        # Rebuild from current records so a checkpoint produced by an older
        # revision cannot reintroduce merge/split parent IDs.
        self.triples=build_topology_from_records(self.records)
        validate_topology(self.triples, [r['ball_id'] for r in self.records],
                          context='Task-Free checkpoint load')
        self.revision=state['revision']
        self.discarded_effective_mass_total=float(
            state.get('discarded_effective_mass_total',0.0))
        self.last_loss_memory_accesses=0
        self.old_response=state['old_response'].to(self.device) if state['old_response'] is not None else None
        # 兼容旧 response/structure 历史状态没有 gb_reference 的格式。
        # core_radial 的有效球若缺少目标，后续 loss 会明确报错；绝不猜测历史几何。
        self.gb_reference={key:{'radius_scale':float(value['radius_scale']),
                               'core_distance':torch.as_tensor(value['core_distance'],device=self.device).detach().clone(),
                               'radial_profile':torch.as_tensor(value['radial_profile'],device=self.device).detach().clone()}
                           for key,value in state.get('gb_reference',{}).items()}
