# 在本地 PowerShell Terminal 运行正式实验

D1 每 10 个 epoch 保存一次恢复点；每个 epoch 追加 JSONL 日志。
第 100 个 epoch 结束也会保存。checkpoint 是最新一份，保存时先写临时文件再替换。
此文档中的命令面向 PowerShell，不能粘贴到显示 `>>>` 的 Python Console。

## 1. 打开终端并进入工程

在 PyCharm 底部打开 Terminal，使用 PowerShell。输入：

```powershell
Set-Location 'E:\PythonProject1'
```

命令使用项目虚拟环境 Python 的完整相对路径，无需另外激活环境。
PowerShell 切换目录用 Set-Location，不使用 CMD 的 `cd /d`。

## 2. 首次启动

2026-09-09 检查时，formal 输出目录只有旧 protocol.json，没有恢复 checkpoint 或完成阶段。
因此可以直接执行下面命令，不需要删除 protocol.json，也不加任何恢复参数。

```powershell
.\venv\Scripts\python.exe -B -u -m continual.stage_runner --config continual/configs/formal.json --end-stage 10 2>&1 | Tee-Object -FilePath '.\out\continual\gb_formal_v1\formal_terminal.log' -Append
```

终端会显示训练输出，同时保存完整 stdout/stderr 到 formal_terminal.log。
`-u` 避免 Python 输出缓冲。不要同时在另一个窗口启动同一实验。
运行期间保持电脑供电和唤醒，保留训练 Terminal；关闭窗口或 Ctrl+C 会中断训练。

最先应看到 `stage 1: ... train=4500, memory=0, device=cpu`（CUDA 可用时设备不同）。
之后每个 epoch 显示 loss 和 validation_fc_accuracy。正式实验仍是 D1 100 epochs、D2+ 每阶段20 epochs。

## 3. 查看进度

在另一个 PowerShell Terminal 中输入以下只读命令，不会影响训练窗口：

```powershell
Get-Content 'E:\PythonProject1\out\continual\gb_formal_v1\formal_terminal.log' -Tail 20
```

查看最新 D1 恢复文件更新时间：

```powershell
Get-Item 'E:\PythonProject1\out\continual\gb_formal_v1\in_progress\stage_01_d1_latest.pth' | Select-Object FullName,LastWriteTime,Length
```

第 10 个 epoch 保存前还没有这个文件，是正常情况。
每次成功保存，终端会输出 `D1 checkpoint saved: epoch=10, path=...`。

## 4. D1 中断后恢复

确认原训练进程已停止，再在工程根目录执行：

```powershell
.\venv\Scripts\python.exe -B -u -m continual.stage_runner --config continual/configs/formal.json --end-stage 10 --resume-d1 2>&1 | Tee-Object -FilePath '.\out\continual\gb_formal_v1\formal_terminal.log' -Append
```

例如保存到 epoch30、运行到 epoch34 时中断，会从 epoch31 重新运行，仍总共训练100个 epoch。
如果在第一个 checkpoint 产生前中断，只能用首次启动命令重头开始。
JSONL 保留中断前日志，并添加 resume 标记说明恢复点；重跑 epoch 可能在日志中出现两次。
不要在开始训练后更改 formal.json，否则恢复时配置检查会拒绝不一致的设置。

## 5. D1 完成后、D2+ 中断

D1 训练完成后还会建球和评估，整个阶段完成才出现 stage_01/stage_01_meta.json。
若只有 D1 recovery 文件而没有完成的 stage_01，仍使用 --resume-d1。

若 stage_01 已完成，而 D2 中断：

```powershell
.\venv\Scripts\python.exe -B -u -m continual.stage_runner --config continual/configs/formal.json --resume-stage 1 --end-stage 10 2>&1 | Tee-Object -FilePath '.\out\continual\gb_formal_v1\formal_terminal.log' -Append
```

`--resume-stage k` 中的 k 指最后一个已完成阶段。例如 D3 中途退出、D2 已完成，则填2。
D2+ 目前只支持阶段边界恢复，中断阶段会重新训练，不支持该阶段 epoch 中途恢复。
若 stage_10 已完成，则无需再执行恢复。

## 输出

- `in_progress/stage_01_d1_latest.pth`：D1 最新周期恢复状态（含当前/最佳权重、优化器、scheduler、随机状态）。
- `in_progress/stage_01_d1.jsonl`：D1 每个 epoch 的结构化日志及恢复标记。
- `formal_terminal.log`：终端完整输出与异常信息，包括 D2+。
- `stage_01` 到 `stage_10`：完成阶段的正式模型、粒球、memory、topology 和 meta。

最终指标在各 stage 的 meta 中。D1 的 validation_fc_accuracy 是初始 FC 选模指标，
不等于最终粒球测试 accuracy；应查看阶段 meta 的 test 和 continual_metrics 字段。
