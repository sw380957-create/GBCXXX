"""负责训练网络：D1和D2不一样；表示学习训练器：D1 交叉熵预训练；D2+ 双视图 SupCon + 历史结构约束。"""
import numpy as np
import torch
import json
import os
import random
import tempfile
import time
from pathlib import Path
from torch.utils.checkpoint import checkpoint
from torch.utils.data import DataLoader
from .data import ImageDataset
from .losses import continual_loss

# 工程性能：DataLoader 并行加载参数。只影响加载吞吐，不改变数据顺序与随机性
# （shuffle 索引由主进程 RNG 生成，worker 只负责按序取样本）。
_WORKERS = min(4, max(1, os.cpu_count() or 1))


def _stage_loader(dataset, batch_size, shuffle=False, persistent=False):
    """阶段/epoch 级 loader：可多进程并行 + 常驻 worker（有多次迭代时受益）。"""
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle,
                      num_workers=_WORKERS, pin_memory=True,
                      persistent_workers=(persistent and _WORKERS > 0))


def _step_loader(dataset, batch_size):
    """每 step 重建的一次性 loader：只开 pin_memory，避免每次 spawn worker 的巨大开销。"""
    return DataLoader(dataset, batch_size=batch_size, shuffle=False,
                      num_workers=0, pin_memory=True)


def save_recovery_checkpoint(path, state):
    """先完整写入同目录临时文件再替换，避免保存中断时破坏上一个恢复点。"""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    descriptor, temporary = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    os.close(descriptor)
    try:
        torch.save(state, temporary)
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def choose_device(config):
    torch.set_num_threads(config.cpu_threads)
    return torch.device("cuda" if torch.cuda.is_available() else "cpu") if config.device == "auto" else torch.device(config.device)


def extract_features(model, images, labels, device, batch_size):
    model.eval()
    outputs = []
    started = time.perf_counter()
    with torch.no_grad():
        loader = _stage_loader(ImageDataset(images, labels), batch_size=batch_size, shuffle=False)
        for x, _ in loader:
            _, features = model(x.to(device))
            outputs.append(features.cpu().numpy())
    result = np.concatenate(outputs) if outputs else np.empty((0, 512), np.float32)
    print(f"[extract_features] time = {time.perf_counter() - started:.2f} s, "
          f"n={len(labels)}, batch_size={batch_size}, device={device}", flush=True)
    return result


def _gradient_check(model):
    norm = torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=10.0, error_if_nonfinite=True)
    return float(norm)


def train_d1(model, images, labels, val_images, val_labels, device, config,
             recovery_path=None, log_path=None, protocol_hash=None):
    """D1 复用原 ResNet/CE/SGD 训练方式，validation 永不加入建球或 memory。

    最佳 epoch 只按独立 validation 的 FC accuracy 选择。最终对外仍是粒球分类。
    """
    started = time.perf_counter()
    for p in model.parameters():
        p.requires_grad_(True)
    loader = _stage_loader(ImageDataset(images, labels, augment=True),
                           batch_size=config.batch_size, shuffle=True, persistent=True)
    optimizer = torch.optim.SGD(model.parameters(), lr=config.d1_learning_rate, momentum=0.9,
                                weight_decay=config.weight_decay)
    scheduler = torch.optim.lr_scheduler.MultiStepLR(optimizer, milestones=[60, 80], gamma=0.1)
    best_acc, best_state, logs, start_epoch = -1.0, None, [], 0
    if recovery_path is not None and Path(recovery_path).exists():
        state = torch.load(recovery_path, map_location=device, weights_only=False)
        if state.get("config") != config.to_dict():
            raise ValueError("D1 recovery checkpoint 的配置与当前 formal 配置不一致")
        if state.get("protocol_hash") != protocol_hash:
            raise ValueError("D1 recovery checkpoint 的数据协议与当前运行不一致")
        model.load_state_dict(state["model_state_dict"])
        optimizer.load_state_dict(state["optimizer_state_dict"])
        scheduler.load_state_dict(state["scheduler_state_dict"])
        start_epoch = int(state["epoch"])
        best_acc, best_state = float(state["best_val_acc"]), state["best_state"]
        logs = state.get("logs", [])
        torch.set_rng_state(state["torch_rng"].cpu())
        np.random.set_state(state["numpy_rng"])
        random.setstate(state["python_rng"])
        if device.type == "cuda" and state.get("cuda_rng"):
            torch.cuda.set_rng_state_all([value.cpu() for value in state["cuda_rng"]])
        print(f"D1 recovery loaded: epoch={start_epoch}/{config.d1_epochs}, best_val={best_acc:.6f}", flush=True)
        if log_path is not None:
            Path(log_path).parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, "a", encoding="utf-8") as file:
                # 保留中断前日志，并明确标注回退恢复点；不能把重跑 epoch 当成额外 epoch。
                file.write(json.dumps({"event": "resume", "checkpoint_epoch": start_epoch}) + "\n")
    for epoch in range(start_epoch, config.d1_epochs):
        model.train()
        loss_sum, count = 0.0, 0
        for x, y in loader:
            if epoch == start_epoch and count == 0:
                # 设备自检：确认输入/标签/模型参数均在同一设备，杜绝隐式 CPU 训练。
                print(f"[device] D1 input tensor device = {x.device}, label tensor device = {y.device}, "
                      f"model parameters device = {next(model.parameters()).device}", flush=True)
            optimizer.zero_grad(set_to_none=True)
            logits, _ = model(x.to(device))
            loss = torch.nn.functional.cross_entropy(logits, y.to(device))
            if not torch.isfinite(loss):
                raise FloatingPointError("D1 loss 非有限")
            loss.backward()
            _gradient_check(model)
            optimizer.step()
            loss_sum += float(loss.detach()) * len(y)
            count += len(y)
        model.eval()
        correct, val_count = 0, 0
        with torch.no_grad():
            for x, y in _stage_loader(ImageDataset(val_images, val_labels),
                                      batch_size=config.feature_batch_size):
                logits, _ = model(x.to(device))
                correct += int((logits.argmax(1).cpu() == y).sum())
                val_count += len(y)
        accuracy = correct / max(1, val_count)
        if accuracy > best_acc:
            best_acc = accuracy
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
        scheduler.step()
        log = {"epoch": epoch + 1, "loss": loss_sum / max(count, 1), "validation_fc_accuracy": accuracy}
        logs.append(log)
        print(f"D1 epoch {epoch + 1}/{config.d1_epochs}: {log}", flush=True)
        if log_path is not None:
            Path(log_path).parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, "a", encoding="utf-8") as file:
                file.write(json.dumps(log, ensure_ascii=False) + "\n")
        if recovery_path is not None and ((epoch + 1) % config.d1_checkpoint_interval == 0 or epoch + 1 == config.d1_epochs):
            save_recovery_checkpoint(recovery_path, {"stage": 1, "epoch": epoch + 1, "model_state_dict": model.state_dict(),
                        "optimizer_state_dict": optimizer.state_dict(), "scheduler_state_dict": scheduler.state_dict(),
                        "best_val_acc": best_acc, "best_state": best_state, "logs": logs,
                        "config": config.to_dict(), "torch_rng": torch.get_rng_state(),
                        "numpy_rng": np.random.get_state(), "python_rng": random.getstate(),
                        "cuda_rng": torch.cuda.get_rng_state_all() if device.type == "cuda" else [],
                        "protocol_hash": protocol_hash,
                        "status": "d1_in_progress" if epoch + 1 < config.d1_epochs else "d1_complete"})
            print(f"D1 checkpoint saved: epoch={epoch + 1}, path={recovery_path}", flush=True)
    model.load_state_dict(best_state)
    model.eval()
    print(f"[train_d1] time = {time.perf_counter() - started:.2f} s "
          f"(epochs={config.d1_epochs - start_epoch}, batch_size={config.batch_size}, device={device})", flush=True)
    return logs


def train_increment(model, images, labels, memory, records, triples, device, config):
    # images/labels 是 D_t；replay 仅来源于上一阶段保存的原始 memory。
    started = time.perf_counter()
    train_images = np.concatenate([images, memory.images])
    train_labels = np.concatenate([labels, memory.labels])
    if not len(train_labels):
        return []
    # 阶段开始时缓存旧网络响应；之后网络更新，缓存保持常量并参与 L_resp。
    model.eval()
    with torch.no_grad():
        old_parts = []
        for x, _ in _stage_loader(ImageDataset(memory.images, memory.labels),
                                  batch_size=config.feature_batch_size, shuffle=False):
            old_parts.append(model(x.to(device))[1])
        old_features = torch.cat(old_parts) if old_parts else torch.empty((0, 512), device=device)
        old_centers = torch.as_tensor(np.stack([r["center"] for r in records]), dtype=old_features.dtype, device=device) if records else old_features.new_empty((0, old_features.shape[1]))
        old_radii = torch.as_tensor([r["radius"] for r in records], dtype=old_features.dtype, device=device) if records else old_features.new_empty(0)
        from .losses import response_matrix
        old_response = response_matrix(old_features, old_centers, old_radii, config.epsilon).detach()
    for name, p in model.named_parameters():
        p.requires_grad_(not name.startswith("fc."))
    optimizer = torch.optim.SGD([p for p in model.parameters() if p.requires_grad],
                                lr=config.learning_rate, momentum=0.9, weight_decay=config.weight_decay)
    loader = _stage_loader(ImageDataset(train_images, train_labels, two_views=True),
                           batch_size=config.batch_size, shuffle=True, persistent=True)
    memory_y = torch.as_tensor(memory.labels, dtype=torch.long, device=device)
    logs = []
    for epoch in range(config.epochs):
        sums, steps = {}, 0
        for first, second, y in loader:
            if epoch == 0 and steps == 0:
                # 设备自检：确认双视图输入与标签均在目标设备。
                print(f"[device] increment input tensor device = {first.device}, "
                      f"label tensor device = {y.device}, model parameters device = {next(model.parameters()).device}",
                      flush=True)
            optimizer.zero_grad(set_to_none=True)
            model.train()
            _, features = model(torch.cat([first, second]).to(device))
            targets = y.repeat(2).to(device)
            # 历史代理必须来自当前参数，每个 step 重算，绝不缓存旧 feature。
            # eval 只固定 BN 统计/关闭随机层，不关闭 autograd。代理与正式提取使用同一模式。
            model.eval()
            history = []
            for x, _ in _step_loader(ImageDataset(memory.images, memory.labels),
                                     batch_size=config.feature_batch_size):
                # 历史球数量增加时，全体代表图像的反向图可能很大。按块重计算中间激活，
                # 只保留特征与输入，仍然对所有历史代理求准确梯度。BN 在 eval 模式下
                # 重计算，不会在 backward 期间再次更新运行统计。
                z = checkpoint(lambda batch: model(batch)[1], x.to(device), use_reentrant=False)
                history.append(z)
            memory_features = torch.cat(history) if history else features.new_empty((0, features.shape[1]))
            loss, values = continual_loss(features, targets, memory_features, memory_y, memory.ball_ids,
                                          records, triples, config, old_response=old_response)
            loss.backward()
            values["gradient_norm"] = _gradient_check(model)
            optimizer.step()
            steps += 1
            for key, value in values.items():
                sums[key] = sums.get(key, 0.0) + value
        log = {key: value / max(steps, 1) for key, value in sums.items()}
        log.update(epoch=epoch + 1, replay_samples=len(memory.labels), training_samples=len(train_labels))
        logs.append(log)
        print(f"increment epoch {epoch + 1}/{config.epochs}: {log}", flush=True)
    model.eval()
    print(f"[train_increment] time = {time.perf_counter() - started:.2f} s "
          f"(epochs={config.epochs}, train_samples={len(train_labels)}, "
          f"memory={len(memory.labels)}, device={device})", flush=True)
    return logs
