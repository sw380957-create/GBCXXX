"""这里是你的持续学习核心：损失函数即历史粒球约束+拓扑保持+overlap
训练阶段的可微损失。正式粒球保持 NumPy / D1 定义，本模块不改正式 radius。

L_resp 比较全部历史粒球的未归一化响应向量，不是类别交叉熵。
旧响应由 trainer 在增量阶段开始、网络更新之前计算一次，整个阶段固定。
最终预测仍由原工程 GranularBallClassifier 完成。
"""
import numpy as np
import torch
import torch.nn.functional as F


def zero_loss(features):
    #返回保持计算图连接的零损失
    return features.sum() * 0.0


def supervised_contrastive(features, labels, temperature=0.1):
    if len(features) < 2:
        return zero_loss(features)
    h = F.normalize(features, dim=1)
    logits = h @ h.T / temperature
    self_mask = torch.eye(len(h), dtype=torch.bool, device=h.device)
    positives = labels[:, None].eq(labels[None, :]) & ~self_mask
    valid = positives.any(dim=1)
    if not valid.any():
        return zero_loss(features)
    log_denominator = torch.logsumexp(logits.masked_fill(self_mask, -torch.inf), dim=1)
    log_probs = logits - log_denominator[:, None]
    # where 而非乘法屏蔽：避免 0 * inf 导致 NaN。
    sums = torch.where(positives, log_probs, torch.zeros_like(log_probs)).sum(dim=1)
    return -(sums[valid] / positives.sum(dim=1)[valid]).mean()


def proxy_balls(memory_features, memory_ball_ids, memory_roles,records):
    """每个历史球代理中心/半径均由当前网络的代表点求得，全程保留梯度。
    在网络更新过程中，代理粒球的更新
    用每球全部代表点构造可微中心和最大半径，供拓扑及 overlap 使用。
    """
    centers, radii, labels, ids = [], [], [], []
    for record in records:
        rows = np.flatnonzero(memory_ball_ids == record["ball_id"])
        if not len(rows):
            raise ValueError("历史球缺少代表点，不能计算可微代理")
        points = memory_features[torch.as_tensor(rows, device=memory_features.device)]
        roles = memory_roles[rows]
        #center = points.mean(dim=0)
        outer_points = points[
            torch.as_tensor(
                roles != "core",
                device=points.device
            )
        ]
        if len(outer_points) == 0:
            # A singleton/current degenerate ball still belongs to the
            # current structure.  Use its core point as the only valid proxy
            # center instead of silently dropping its ball_id from topology.
            center = points.mean(dim=0)
        else:
            center = outer_points.mean(dim=0)
        centers.append(center)
        # 粒球的代理半径沿用 D1 radius 定义：有限支撑点到代理中心的最大距离。
        radii.append(torch.linalg.vector_norm(points - center, dim=1).max())
        labels.append(int(record["label"]))
        ids.append(record["ball_id"])
    if not centers:
        return (memory_features.new_empty((0, memory_features.shape[1])),
                memory_features.new_empty(0),
                torch.empty(0, dtype=torch.long, device=memory_features.device), ids)
    return torch.stack(centers), torch.stack(radii), torch.tensor(labels, device=memory_features.device), ids


def response_matrix(features, centers, radii, epsilon):
    """返回样本对每个历史球的响应向量 s_ik。"""
    if not len(features) or not len(centers):
        return features.new_empty((len(features), len(centers)))
    distances = torch.linalg.vector_norm(features[:, None] - centers[None], dim=2)
    return torch.exp(-(distances / (radii[None] + epsilon)).square())


def historical_response_loss(features, old_response, centers, radii, *, epsilon):
    """L_resp = (1 / |M|) sum_i sum_k (s_new[i,k] - s_old[i,k])**2。

    epsilon 必须使用关键字传入，避免误落入旧版分类损失的标签参数位置。
    不接受旧版标签调用，也绝不以当前响应构造替代目标：缓存缺失或形状
    错误时明确报错，防止响应损失看似运行、实际一直为零。
    """
    current = response_matrix(features, centers, radii, epsilon)
    if old_response is None:
        if not len(features) or not len(centers):
            return zero_loss(features) + zero_loss(centers)
        raise ValueError("L_resp 缺少阶段开始时缓存的旧响应")
    if not isinstance(old_response, torch.Tensor) or current.shape != old_response.shape:
        raise ValueError("旧响应必须为与当前响应同形状的 [历史样本数, 历史粒球数] 张量")
    if not torch.isfinite(old_response).all():
        raise FloatingPointError("旧响应缓存包含非有限值")
    if not len(features) or not len(centers):
        return zero_loss(features) + zero_loss(centers)
    # 只切断历史目标梯度；当前特征、代理中心和代理半径均保留梯度。
    # 必须先对球求和，再对样本平均。直接 .mean() 会额外除以球数 K。
    return (current - old_response.detach()).square().sum(dim=1).mean()


def center_radius_losses(centers, radii, records):
    """PDF 定义的 L_mu 与 L_r，分别为中心平方范数和半径绝对差。"""
    if not len(records) or not len(centers):
        return zero_loss(centers), zero_loss(centers)
    old_centers = torch.as_tensor(np.stack([r["center"] for r in records]),
                                  dtype=centers.dtype, device=centers.device)
    old_radii = torch.as_tensor([r["radius"] for r in records],
                                dtype=radii.dtype, device=radii.device)
    if len(old_centers) != len(centers):
        raise ValueError("历史球记录与代理球数量不一致")
    return ((centers - old_centers).square().sum(dim=1)).mean(), (radii - old_radii).abs().mean()


def _core_radial_geometry(memory_features, memory_ball_ids, memory_roles):
    """按稳定 ball_id 构造相对几何；只用 outer 均值，不用完整球中心。
    按球分组，用外围均值计算 core 距离和排序径向分布。
    角色决定 core 的位置，不能假设其在数组首行。其他角色一律视为
    outer（包括 memory.py 当前使用的 boundary）。径向距离独立排序，
    因而比较分布而非固定样本身份；返回的当前几何保留 autograd 图。
    """
    ball_ids = np.asarray(memory_ball_ids)
    roles = np.asarray(memory_roles)
    if (memory_features.ndim != 2 or ball_ids.shape != (len(memory_features),)
            or roles.shape != ball_ids.shape):
        raise ValueError("core_radial requires aligned features, ball_ids and roles")
    geometry = {}
    for ball_id in np.unique(ball_ids):
        rows = np.flatnonzero(ball_ids == ball_id)
        # 单点球没有外围相对几何，不参与两个损失的分母。
        if len(rows) < 2:
            continue
        core_rows = rows[roles[rows] == "core"]
        if len(core_rows) != 1:
            raise ValueError(f"core_radial ball {ball_id} requires exactly one core")
        outer_rows = rows[roles[rows] != "core"]
        outer = memory_features[torch.as_tensor(outer_rows, device=memory_features.device)]
        outer_center = outer.mean(dim=0)
        core_distance = torch.linalg.vector_norm(memory_features[int(core_rows[0])] - outer_center)
        radial_profile = torch.linalg.vector_norm(outer - outer_center, dim=1).sort().values
        geometry[str(ball_id)] = (core_distance, radial_profile)
    return geometry


@torch.no_grad()
def build_core_radial_reference(memory_features, memory_ball_ids, memory_roles, records, epsilon):
    """在 Task-Free full_update 的最终 memory 上建立冻结目标。

    每球保存一个 core 距离、变长的排序径向向量及 record['radius']。
    radius 是历史球保存的最大半径，仅用作尺度；不从代表点重新估计，
    也不读取分类器的 mean/adaptive 半径。detach + clone 使缓存既不保留
    计算图，也不与后续特征计算共享可修改的张量存储。
    """
    if not np.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("core_radial epsilon must be finite and positive")
    by_id = {str(record['ball_id']): record for record in records}
    if len(by_id) != len(records):
        raise ValueError("duplicate ball_id in core_radial records")
    reference = {}
    for ball_id, (distance, radial) in _core_radial_geometry(
            memory_features, memory_ball_ids, memory_roles).items():
        if ball_id not in by_id or 'radius' not in by_id[ball_id]:
            raise ValueError(f"core_radial ball {ball_id} lacks historical radius")
        scale = float(by_id[ball_id]['radius'])
        if not np.isfinite(scale) or scale < 0:
            raise ValueError(f"invalid core_radial radius for {ball_id}")
        if not torch.isfinite(distance).all() or not torch.isfinite(radial).all():
            raise FloatingPointError("nonfinite core_radial reference geometry")
        reference[ball_id] = {'radius_scale': scale,
                              'core_distance': distance.detach().clone(),
                              'radial_profile': radial.detach().clone()}
    return reference


def core_radial_loss(memory_features, memory_ball_ids, memory_roles, gb_reference, epsilon):
    """L_core、L_radial：先球内 SmoothL1 均值，再对有效球等权平均。损失函数Lgb的
    比较当前与冻结的相对几何，对有效球等权平均，跳过单点球。
    当前与参考各自使用 outer 均值和升序径向向量，因此整体平移不受罚。
    唯一尺度为冻结的 radius_scale + epsilon。目标即使意外带梯度也会
    detach；只允许当前 memory_features 接收梯度。参考缺失或维护后
    未同步的长度错误必须显式报错，不能临时用当前特征重建零损失目标。
    """
    if not np.isfinite(epsilon) or epsilon <= 0:
        raise ValueError("core_radial epsilon must be finite and positive")
    geometry = _core_radial_geometry(memory_features, memory_ball_ids, memory_roles)
    if not geometry:
        return zero_loss(memory_features), zero_loss(memory_features)
    if gb_reference is None or set(geometry) != set(gb_reference):
        raise ValueError("core_radial reference does not match current memory ball_ids")
    core_terms, radial_terms = [], []
    for ball_id, (distance, radial) in geometry.items():
        reference = gb_reference[ball_id]
        scale = float(reference['radius_scale'])
        if not np.isfinite(scale) or scale < 0:
            raise ValueError(f"invalid core_radial radius for {ball_id}")
        old_distance = torch.as_tensor(reference['core_distance'], device=memory_features.device,
                                       dtype=memory_features.dtype).detach()
        old_radial = torch.as_tensor(reference['radial_profile'], device=memory_features.device,
                                     dtype=memory_features.dtype).detach()
        if old_distance.ndim != 0 or old_radial.shape != radial.shape:
            raise ValueError(f"stale core_radial reference shape for {ball_id}")
        if not torch.isfinite(old_distance).all() or not torch.isfinite(old_radial).all():
            raise FloatingPointError("nonfinite core_radial reference geometry")
        denominator = scale + epsilon
        core_terms.append(F.smooth_l1_loss(distance / denominator, old_distance / denominator))
        # A two-image ball has one outer point.  Its distance to its own
        # one-point mean is identically zero, so no radial constraint exists.
        if len(radial) >= 2:
            radial_terms.append(F.smooth_l1_loss(
                radial / denominator, old_radial / denominator))
    # Both components use the same denominator: the number of participating
    # balls.  Consequently core+radial equals the mean of each ball's valid
    # contribution (core only for two images, both terms for >=3 images).
    radial_total = (torch.stack(radial_terms).sum() if radial_terms
                    else zero_loss(memory_features))
    return torch.stack(core_terms).mean(), radial_total / len(core_terms)


def topology_loss(centers, ball_ids, triples):
    #惩罚历史近邻距离超过历史远邻距离
    if len(triples) == 0 or len(centers) < 3:
        return zero_loss(centers)
    positions = {str(key): i for i, key in enumerate(ball_ids)}
    normalized_triples = np.asarray(triples, dtype="U64").reshape(-1, 3)
    missing_ids = sorted({str(key) for triple in normalized_triples for key in triple}
                         - set(positions))
    if missing_ids:
        raise ValueError(
            "拓扑引用不存在的当前 ball_id: "
            f"missing_ids={missing_ids}; "
            f"current_ball_id_count={len(positions)}; "
            f"topology_count={len(normalized_triples)}"
        )
    try:
        rows = torch.tensor([[positions[str(key)] for key in triple]
                             for triple in normalized_triples],
                            dtype=torch.long, device=centers.device)
    except KeyError as exc:
        raise ValueError("拓扑引用不存在的历史 ball_id") from exc
    near = torch.linalg.vector_norm(centers[rows[:, 0]] - centers[rows[:, 1]], dim=1)
    far = torch.linalg.vector_norm(centers[rows[:, 0]] - centers[rows[:, 2]], dim=1)
    return F.relu(near - far).mean()


def overlap_loss(centers, radii, ball_labels, witness_features):
    #惩罚存在真实见证样本的异类代理球重叠。
    if len(centers) < 2 or len(witness_features) == 0:
        return zero_loss(centers)
    distances = torch.linalg.vector_norm(centers[:, None] - centers[None], dim=2)
    overlaps = radii[:, None] + radii[None] - distances
    # 冲突集合是离散筛选，不对 bool mask 求梯度；实际 overlap 仍可微。
    with torch.no_grad():
        candidates = torch.triu(ball_labels[:, None].ne(ball_labels[None]) & (overlaps > 0), diagonal=1)
        covered = torch.linalg.vector_norm(witness_features[:, None] - centers[None], dim=2) <= radii[None]
        pairs = candidates.nonzero()
        active = [(int(i), int(j)) for i, j in pairs if (covered[:, i] & covered[:, j]).any()]
    if not active:
        return zero_loss(centers)
    return torch.stack([F.relu(overlaps[i, j]) for i, j in active]).mean()


def continual_loss(features, labels, memory_features, memory_labels, memory_ball_ids,
                   records, triples, config, old_response=None):
    rep = supervised_contrastive(features, labels, config.temperature)
    centers, radii, ball_labels, ball_ids = proxy_balls(memory_features, memory_ball_ids, records)
    mode = getattr(config, "gb_loss_mode", "structure")
    if mode not in {"none", "response", "structure"}:
        raise ValueError(f"未知 gb_loss_mode: {mode}")
    # none 只关闭 L_gb，拓扑项和 overlap 项仍按原流程计算。
    # response 无需计算中心/半径保持项，也不会读取未初始化的旧响应。
    hist = zero_loss(memory_features)
    center_loss, radius_loss = zero_loss(centers), zero_loss(radii)
    radial_loss = zero_loss(memory_features)
    if mode == "response":
        hist = historical_response_loss(memory_features, old_response, centers, radii,
                                        epsilon=config.epsilon)
    elif mode == "structure":
        hist = historical_response_loss(memory_features, old_response, centers, radii,
                                        epsilon=config.epsilon)
        center_loss, radius_loss = center_radius_losses(centers, radii, records)
    elif mode == "core_radial":
        raise ValueError(
            "core_radial mode should be dispatched by TaskFree GranularBallHistory "
            "with its frozen gb_reference."
        )
    gb = hist + getattr(config, "lambda_radial",
                        1.0) * radial_loss + config.alpha * center_loss + config.beta * radius_loss
    struct = topology_loss(centers, ball_ids, triples)
    overlap = overlap_loss(centers, radii, ball_labels, torch.cat([memory_features, features], dim=0))
    total = rep + config.lambda_gb * gb + config.lambda_struct * struct + config.lambda_overlap * overlap
    values = {"total": total, "rep": rep, "gb": gb, "gb_resp": hist, "gb_mu": center_loss,
              "gb_r": radius_loss, "struct": struct, "overlap": overlap}
    if not all(torch.isfinite(v).all() for v in values.values()):
        raise FloatingPointError("损失包含非有限值；停止保存，避免污染阶段 checkpoint")
    return total, {key: float(value.detach()) for key, value in values.items()}
