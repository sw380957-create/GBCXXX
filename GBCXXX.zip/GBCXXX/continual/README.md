# 基于粒球结构记忆的持续学习

本模块接在现有 `models/resnet18_cifar.py`、`data/cifar10_strict_stream.py` 和
`granular_ball/final_granulation_final_switch.py` 上。原 D1 源码和既有实验输出保持不变。
从项目根目录 `E:\PythonProject1` 使用模块方式运行。

## 文件职责

| 文件 | 作用 |
|---|---|
| `config.py`、`configs/*.json` | 整条协议固定配置、正式/冒烟参数示例 |
| `data.py` | 复用原十阶段日程，独立 validation，图片/全局索引与双视图增强 |
| `memory.py` | 1 core + 最多 4 个边界 FPS，保存 uint8 原图而非旧 feature |
| `topology.py` | 根据最终中心重建 nearest/farthest 稳定 ID 三元组 |
| `losses.py` | SupCon、当前网络历史代理、历史响应/拓扑/真实冲突损失 |
| `ball_update.py` | weighted update、覆盖关联、原 D1 二分适配、merge、质量和 lineage |
| `trainer.py` | D1 交叉熵训练与 D2+ 表示学习；原 ResNet 返回的 512 维 feature |
| `evaluation.py` | 复用原 GB 分类器，统一 `r+epsilon` 分母并保留原评估指标 |
| `stage_runner.py` | 阶段编排、独立验证、测试、原子保存、完成阶段恢复 |
| `search.py` | 仅 validation 的固定 lambda 网格搜索 |
| `../tests/test_continual.py` | 质量守恒、D1 等价性、冲突、关联、memory、损失梯度等回归检查 |

## 运行

先运行研究机制测试：

```powershell
.\venv\Scripts\python.exe -B -m unittest discover -s tests -p test_continual.py -v
```

独立验证划分的 D1 → D2 冒烟测试（每类 8 个训练样本、每类 8 个评估样本、每阶段 1 epoch）：

```powershell
.\venv\Scripts\python.exe -B -m continual.stage_runner --config continual/configs/smoke.json --end-stage 2
```

从完成的 D2 恢复，继续 D3～D10：

```powershell
.\venv\Scripts\python.exe -B -m continual.stage_runner --config continual/configs/smoke.json --resume-stage 2 --end-stage 10
```

与本地已有 D1 checkpoint 的兼容测试：

```powershell
.\venv\Scripts\python.exe -B -m continual.stage_runner --config continual/configs/legacy_smoke.json --end-stage 2 --legacy-checkpoint checkpoints/resnet18_D1.pth
```

旧 checkpoint 缺少新协议训练来源，故该模式明确标记 `validation_protocol_clean=false`，
只允许缩小数据的兼容性检查，不可用于正式调参。它会使用旧网络重新为当前冒烟 D1 子集建球，
不会把旧 5000 样本粒球文件直接当作新协议初始结构。

正式训练（先编辑配置的 experiment 名称与超参数）：

```powershell
.\venv\Scripts\python.exe -B -m continual.stage_runner --config continual/configs/formal.json --end-stage 10
```

默认 formal 配置 D1 为 100 epochs，D2+ 为每阶段 20 epochs。lambda=1 只是可运行初值。
CPU 自动可运行；安装支持 CUDA 的 PyTorch 且设备可用时 `device=auto` 自动使用 CUDA。
当前附带的本地环境是 CPU 版本 PyTorch，CUDA 路径未在本机验证。

输出目录不覆盖已有阶段。重复冒烟时改 JSON 的 `experiment`，或从已完成阶段恢复。
`--resume-stage k` 是阶段边界恢复，重新构造下一阶段 optimizer；不支持 epoch 中途恢复。
恢复会检查所有配置、数据协议及文件 SHA256，不能在 D2/D3 之间改 lambda。

## 验证协议与参数搜索

原 10 个数据块及类别日程不变。每块每类 1250 个样本中预先划出 125 个 validation；
完整模式实际训练/结构池是每块 4500 个样本。D1 仅用这些训练样本建球和选 memory。
截至阶段 t 的 validation 仅来自 D1..Dt 已到达块。验证图片永不进入训练、建球或 memory。

```powershell
.\venv\Scripts\python.exe -B -m continual.search --config continual/configs/formal.json --grid continual/configs/search_grid.json --end-stage 10
```

每个候选从相同随机种子重新训练 D1，并在所有增量阶段使用同一组参数。
目标为 D2..D_end 的累计已见类 GB validation accuracy 的平均值。
搜索模式完全不读取官方 test set，输出 `search_results.json` 与 `selected_config.json`。
选定配置后用 stage_runner 正式运行并报告 test。8 个默认网格候选会完整训练 8 条协议，
计算量明显大于冒烟测试；本次实现验证不会自动执行完整网格搜索。

## 数学约定与复用边界

1. 网络更新仅可访问 D_t + 上阶段保存的原始 memory。双增强视图保证 SupCon anchor 有正样本；
   无正样本 anchor 会安全跳过。最终 FC 参数在增量阶段冻结，分类始终走粒球。
2. 每一步都重新通过当前网络计算所有历史代表点特征。代理中心为代表点均值，代理半径为平均距离。
   代理前向固定 BN 运行统计但保留梯度，并使用激活重计算限制内存占用；没有对旧 feature 求梯度。
3. 历史响应概率使用 `p_c=S_c/sum(S)`，在 log 域计算交叉熵避免响应下溢；只使用历史样本标签。
   拓扑使用无 margin ReLU；overlap 只对异类几何重叠且有真实共同覆盖见证点的历史代理对求和。
   见证点来自当前历史代理样本和当前训练 batch。没有冲突时损失返回有限的 0。
4. 网络更新完毕冻结模型，再提取完整 D_t + memory 特征。先按历史代表点重建历史中心和有限支撑半径。
   在固定的历史代理集合上批量关联：所有覆盖样本的同类球中取 `distance/(r+eps)` 最小者。
   相同分数用稳定 ID 打破平局。关联完成后统一吸收，避免输入顺序改变覆盖集合。
5. 历史点总权重为旧 effective_count，新样本每点为 1。中心是这些权重的加权均值。
   radius 是有限支撑到该中心的最大距离；mean_radius 是有限支撑的普通平均距离。
   此 radius 是历史球的近似值，不能恢复完整历史分布的极端点。
6. 合并先于最终异类分裂。merge 条件是同类核心区域被另一球包含；合并后质量相加、保留来源权重。
   merge 是新增代码，因为原工程没有可复用的合并实现。
7. 二分几何直接调用原 `split_ball`；新数据初始化直接调用原 `initialize_balls`。
   纯新球统计还直接使用原 `Ball.update`，有历史支撑的球只使用 weighted update。
   分裂时父历史质量按子球内历史代表点数量比例分配，再加子球新样本真实数量，允许非整数质量。
   分裂一个合并球时，比例基于该父球全部历史代表点，因此会将来源权重重新均分，这是明确的近似约定。
8. 加权子球需要重新评分，所以本层适配原 compare-both 的 `(C,O)` 字典序接受循环，
   不能直接调用评分未加权子球的原 compare_both。冲突函数、二分函数、B/W 计算均直接复用 D1。
   不使用 BIC，也没有另一套二分几何。回归测试验证纯新数据结果与原 run_granulation 一致。
9. 类内细化开关默认开启，与当前 D1 一致。最终可能仍有冲突（最小子球、无改善或上限停止等）；
   meta 保存最终重新计算的 C/O 和冲突对数量，不把停止描述成无冲突。
10. 最终分类固定为 `adaptive_boundary_mean`，复用
    `granular_ball/classifier_experimental.py` 的 `adaptive_boundary` + `mean`。
    直接读取 `mean_radius`，先判断核心区，再按边界距离选候选球，同类候选响应取平均。
    分类响应分母为 `max(mean_radius, epsilon)`，与此前独立分类实验完全一致。
    `coverage_rate` 指任一平均半径核心区覆盖率；返回的分类分数不是校准概率。
    此项只更换最终分类，训练响应损失、建球和 memory 的定义不会跟随改变。
    新 checkpoint 配置记录 `classifier_mode`，meta 记录分类算法、半径和源码哈希；
    新实验请使用新 experiment 名称，不能从旧分类器的阶段继续并混用旧评估指标。
11. memory 每阶段重新选取，最多每球 5 张 uint8 原图。边界严格满足 mean_radius < d <= radius，
    FPS 在 512 维空间进行；不足 4 点不补造样本。没有边界时只选 core。
12. topology 保存稳定球 ID。少于 3 球或所有近远距离并列时，不生成不可能表达严格不等式的三元组。

## 输出与溯源

```text
out/continual/<experiment>/
    protocol.json
    stage_01/
        model_stage_01.pth
        balls_stage_01.npy
        memory_stage_01.npz
        topology_stage_01.npz
        stage_01_meta.json
    stage_02/ ...
```

球记录包含原分类器字段，并新增 `ball_id`、`effective_count`、`representative_ids`、
`parents`、`source`、`radius_is_proxy`。保存的 `sample_indices` 明确为官方训练集全局 ID；
运行时 `indices` 是当前特征池局部行号。两者不能混用。

ID 在一条 experiment 内由阶段号和单调计数生成；split/merge 创建新 ID 并记录父 ID。
meta 的事件列表保留包括中途被淘汰的球在内的结构 lineage，可沿各阶段回溯。
同一历史球吸收样本后保留 ID。`num_samples` 是有限支撑点数，不能用来替代 effective_count。

meta 还保存当前/新/已见类别、每类球数、memory 数、四项训练损失、验证和测试指标、
配置、随机种子、文件/源码哈希、近似标志。`smoke_test=true` 的准确率只能检查代码流程。
检查点包含模型与随机状态；上一阶段全部训练图片/feature 不会被作为下一阶段 memory 加载。
