"""独立 Task-Free 参数；不读取、改写 stage-wise formal.json。"""
from dataclasses import dataclass, field, asdict
import json
import math


@dataclass
class TaskFreeConfig:
    seed: int = 2026#随机种子
    window_size: int = 512##每次数据流取512个样本，组成一个训练窗口
    batch_size: int = 64#每次网络参数“更新”使用最多 64 个当前窗口样本。
    horizontal_flip: bool = True  # MNIST digits must not be mirrored.
    local_epochs: int = 5#当前窗口的数据（512）重复训练 5 遍，然后继续下一个窗口。不是整个数据集训练 5 遍。
    warmup_windows: int = 6#前 6 个窗口先进行 CE 训练(类似预训练)，第 6 个窗口训练结束后首次建立粒球。
    gb_full_update_interval_windows: int = 6#首次建球之后，每隔 6 个窗口完整维护一次粒球，并重选代表点、刷新历史参考。
    #taskFreeTrainer.init(line15),在这个代码中用到
    optimizer: dict = field(default_factory=lambda: dict(name='sgd', learning_rate=.01,#使用随机梯度下降优化器。当前配置校验只允许 SGD
                                                        momentum=.9, weight_decay=.0005))
    #learning_rate学习率0.01，momentum在更新中保留过去梯度方向的信息，减少更新方向的频繁摆动。weight_decay优化器中的权重衰减，用于约束网络参数大小。
    scheduler: dict = field(default_factory=lambda: dict(type='constant'))
    #学习率保持固定，不按 epoch 或窗口衰减。当前没有实际创建一个 LR scheduler 对象。
    device: str = 'auto'#PyTorch 检测到可用 CUDA 时使用 GPU，否则使用 CPU。
    cpu_threads: int = 4#设置 PyTorch CPU 运算线程数
    feature_batch_size: int = 128#特征提取时每批处理最多 128 张图片，包括粒球维护、历史代表点特征提取和验证相关前向。
    # 0 保持原始网络特征；正整数在首次建球时拟合 PCA，并固定投影到该维度。
    # PCA 只使用已到达的训练样本，不能用 validation/test 拟合。
    feature_projection_dim: int = 0
    # 粒球特征空间的距离实验。unit_euclidean 先将每个特征向量归一化，
    # 然后沿用同一套欧氏球几何；网络分类头的 CE 不受此开关影响。
    ball_feature_metric: str = 'euclidean'
    # 0 关闭代表图像 CE 回放。开启后将 memory 打乱并分批顺序遍历，
    # 每批至多这么多张；末批不足时不补齐，用完全部再重新打乱。
    # 遍历进度跨窗口延续，memory 在粒球维护后更新时重新开始。
    representative_replay_batch_size: int = 0
    # 首次建球前可选的临时 CE 回放池。0 保持原行为：warmup 阶段无回放。
    # 正数时只从已经完成训练的旧窗口 pending 图像中选最多这么多张；
    # 首次建球后自动切换到粒球代表点回放，不额外持久化第二份图片。
    warmup_replay_capacity: int = 0
    # global_cycle 保留原来的全 memory 随机循环；class_balanced_cycle
    # 先给当前 memory 中的类别分配尽量相等的回放配额，再在每个类别
    # 内部独立无放回循环。它只改变代表图像的抽样，不改变代表点选择。
    representative_replay_sampling: str = 'global_cycle'
    # random_members 仅用于 L_gb 消融：按全局图片预算从所有球成员中随机抽样，
    # 不按球心/半径挑几何点。fixed5 保留每球 5 张选择；fixed_k 用 max_per_ball
    # 指定每球 K 张（K=5 时与 fixed5 一致）；adaptive_coverage 从核心、
    # 典型半径、最大半径 3 张开始，再按最远点覆盖补充到误差阈值，最多 8 张。
    # class_balanced_budget 是旧的精确 E_k 贪心，会尽量填满预算；
    # budgeted_fast 把预算视为上限，按核心/边界/最远点逐层分配，
    # 每球最多 representative_max_per_ball 张，避免两两距离矩阵。
    representative_selection_mode: str = 'fixed5'
    representative_min_per_ball: int = 3
    representative_max_per_ball: int = 8
    representative_coverage_error: float = 0.25
    # Fixed raw-image budget used by class_balanced_budget selection.
    representative_memory_budget: int = 0
    # 实验开关：球的几何代表点保持不变，预算剩余部分保存只参与 CE 的
    # 已到达训练图像。两类原图去重后共享 representative_memory_budget。
    ce_replay_fill_budget: bool = False
    # Restrict core_radial to balls touched by the current replay batch.
    # This is transient loss sampling, not a persistent ball-activity score.
    gb_replay_ball_subset: bool = False
    #GranularBallHistory.loss(line84)
    lambda_gb: float = 1.#历史粒球保持损失的总权重。
    lambda_struct: float = 1.#粒球之间拓扑关系保持损失的权重。
    lambda_overlap: float = 1.#有真实见证样本的异类代理球重叠惩罚权重。
    gb_loss_mode: str = 'core_radial'#选择历史粒球损失的计算方式；当前使用 core 相对距离保持＋外围径向分布保持。
    alpha: float = 0.#仅在旧 structure 模式中控制中心保持项；当前模式不使用它。
    beta: float = 0.#仅在旧 structure 模式中控制半径保持项；当前模式不使用它。
    epsilon: float = 1e-8#数值稳定用的小正数，避免半径为零等情况导致除零。1e-8 就是 0.00000001。
    intra_refinement: bool = True#允许调用类内结构细分：根据候选子球的内部与球间散度决定是否接受分裂；不表示每个球一定分裂。
    # 仅改变类内候选分裂的接受规则；bw 保持旧实验行为，quality 使用明确的质量门槛。
    intra_split_mode: str = 'bw'
    quality_min_child_samples: int = 4
    quality_min_child_fraction: float = 0.05
    # quality 模式的可选 B/W 前置门槛。0 保持已有 quality 实验行为；
    # 1.0 表示候选分裂还必须满足 B > W，之后才计算异类核心侵入。
    quality_min_bw_ratio: float = 0.0
    # full_radius 保留旧的“完整最大半径包含”合并；
    # mean_in_max_quality 先在同标签内部寻找“平均半径核心被另一球最大半径包含”
    # 的冗余 pair，再用合并后的真实支撑集合复核几何质量；
    # mean_in_max_one_shot 对排序后的互不相交 pair 直接合并，每球一轮最多一次。
    redundant_merge_mode: str = 'full_radius'
    # 仅供新实验显式开启：同类合并结束后移除真正的单样本离群球。
    # 唯一类别球以及 effective mass > 1 的历史代理球会被保护。
    remove_singleton_balls: bool = False
    max_hetero_splits: int = 100#一次异类冲突处理调用最多接受 100 次冲突分裂,防止无限分裂
    # 只在固定已消费样本数处触发只读 evaluation；0 表示关闭。
    validation_interval_samples: int = 0#关闭训练过程中的周期性验证，数据流中已消费的新样本数
    classifier_mode: str = 'max_unique_then_adaptive_mean'

    def validate(self):
        '''
        检查训练参数、损失模式和分类器设置是否合法。
        :return:
        '''
        for key in ('window_size','batch_size','local_epochs','warmup_windows',
                    'gb_full_update_interval_windows','cpu_threads','feature_batch_size'):
            if type(getattr(self,key)) is not int or getattr(self,key)<1:
                raise ValueError(f'{key} must be a positive integer')
        if type(self.horizontal_flip) is not bool:
            raise ValueError('horizontal_flip must be boolean')
        if type(self.feature_projection_dim) is not int or self.feature_projection_dim < 0:
            raise ValueError('feature_projection_dim must be a nonnegative integer')
        if self.ball_feature_metric not in ('euclidean', 'unit_euclidean'):
            raise ValueError('ball_feature_metric must be euclidean or unit_euclidean')
        if (type(self.representative_replay_batch_size) is not int or
                self.representative_replay_batch_size < 0):
            raise ValueError('representative_replay_batch_size must be a nonnegative integer')
        if type(self.warmup_replay_capacity) is not int or self.warmup_replay_capacity < 0:
            raise ValueError('warmup_replay_capacity must be a nonnegative integer')
        if self.warmup_replay_capacity and not self.representative_replay_batch_size:
            raise ValueError('warmup replay requires representative_replay_batch_size > 0')
        if (self.warmup_replay_capacity and self.representative_memory_budget and
                self.warmup_replay_capacity > self.representative_memory_budget):
            raise ValueError('warmup replay capacity cannot exceed representative memory budget')
        if self.representative_replay_sampling not in ('global_cycle', 'class_balanced_cycle'):
            raise ValueError('representative_replay_sampling must be global_cycle or class_balanced_cycle')
        if self.representative_selection_mode not in ('fixed5', 'adaptive_coverage',
                                                        'class_balanced_budget',
                                                        'budgeted_fast',
                                                        'random_members', 'fixed_k'):
            raise ValueError('unsupported representative_selection_mode')
        if (type(self.representative_min_per_ball) is not int or
                type(self.representative_max_per_ball) is not int or
                self.representative_min_per_ball < 1 or
                self.representative_max_per_ball < self.representative_min_per_ball):
            raise ValueError('representative per-ball limits must be positive and ordered')
        if (not math.isfinite(self.representative_coverage_error) or
                self.representative_coverage_error < 0):
            raise ValueError('representative_coverage_error must be finite and nonnegative')
        if (type(self.representative_memory_budget) is not int or
                self.representative_memory_budget < 0):
            raise ValueError('representative_memory_budget must be a nonnegative integer')
        if type(self.ce_replay_fill_budget) is not bool:
            raise ValueError('ce_replay_fill_budget must be bool')
        if self.ce_replay_fill_budget and (
                self.representative_selection_mode not in ('fixed5', 'fixed_k') or
                self.representative_memory_budget < 1 or
                self.representative_replay_batch_size < 1):
            raise ValueError('CE-only budget fill requires fixed5/fixed_k, a positive memory budget and replay')
        if self.representative_selection_mode == 'fixed_k' and self.representative_max_per_ball < 3:
            raise ValueError('fixed_k requires representative_max_per_ball >= 3')
        if self.representative_selection_mode == 'random_members':
            if (self.representative_memory_budget < 1 or
                    self.representative_replay_batch_size < 1 or
                    self.lambda_gb != 0 or self.lambda_struct != 0 or
                    self.lambda_overlap != 0 or self.ce_replay_fill_budget):
                raise ValueError(
                    'random_members is an L_gb-off ablation: require positive memory/replay budgets, '
                    'all historical loss weights zero, and ce_replay_fill_budget=false')
        if (self.representative_selection_mode in ('class_balanced_budget',
                                                    'budgeted_fast') and
                self.representative_memory_budget < 1):
            raise ValueError('budgeted representative selection requires a positive memory budget')
        if type(self.gb_replay_ball_subset) is not bool:
            raise ValueError('gb_replay_ball_subset must be bool')
        if (self.gb_replay_ball_subset and
                (self.representative_replay_batch_size < 1 or
                 self.gb_loss_mode != 'core_radial')):
            raise ValueError(
                'gb_replay_ball_subset requires representative replay and core_radial mode')
        if self.optimizer.get('name') != 'sgd' or self.scheduler != {'type':'constant'}:
            raise ValueError('v1 supports SGD and constant scheduler only')
        for key in ('learning_rate','momentum','weight_decay'):
            x=self.optimizer[key]
            if not math.isfinite(x) or x<0 or (key=='learning_rate' and x==0):
                raise ValueError(f'invalid optimizer {key}')
        for key in ('lambda_gb','lambda_struct','lambda_overlap','alpha','beta','epsilon'):
            if not math.isfinite(getattr(self,key)) or getattr(self,key)<0:
                raise ValueError(f'invalid {key}')
        if self.epsilon==0 or self.gb_loss_mode not in ('none','response','structure','core_radial'):
            raise ValueError('invalid historical loss settings')
        if self.classifier_mode not in ('adaptive_boundary_mean', 'max_unique_then_adaptive_mean'):
            raise ValueError('unsupported classifier_mode')
        if self.intra_split_mode not in ('bw', 'quality'):
            raise ValueError('intra_split_mode must be bw or quality')
        if type(self.quality_min_child_samples) is not int or self.quality_min_child_samples < 1:
            raise ValueError('quality_min_child_samples must be a positive integer')
        if (not math.isfinite(self.quality_min_child_fraction) or
                not 0 < self.quality_min_child_fraction <= 0.5):
            raise ValueError('quality_min_child_fraction must be in (0, 0.5]')
        if (not math.isfinite(self.quality_min_bw_ratio) or
                self.quality_min_bw_ratio < 0):
            raise ValueError('quality_min_bw_ratio must be finite and nonnegative')
        if self.redundant_merge_mode not in (
                'none',
                'full_radius',
                'mean_in_max_quality',
                'mean_in_max_one_shot',
        ):
            raise ValueError('unsupported redundant_merge_mode')
        if type(self.remove_singleton_balls) is not bool:
            raise ValueError('remove_singleton_balls must be bool')
        if self.max_hetero_splits<0 or self.validation_interval_samples<0:
            raise ValueError('interval/limit cannot be negative')
        if self.validation_interval_samples % self.window_size:
            raise ValueError('validation interval must align with window_size')
        return self

    def to_dict(self):
        #将配置转成字典，用于日志、checkpoint 和恢复一致性检
        return asdict(self)

    @classmethod
    def load(cls,path):
        #读取 JSON 配置并执行校验,task_free_v1.json
        with open(path,encoding='utf-8') as f:
            return cls(**json.load(f)).validate()
