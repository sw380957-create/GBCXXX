"""Choose CE-only replay images without changing granular-ball geometry.

The five (or fewer) structural representatives of each ball are selected by
``memory.py``.  This module uses only capacity left after those anchors.  It
round-robins over classes and then current balls, shuffling candidates within
each ball with an independent deterministic RNG.  No validation/test image or
pairwise feature-distance matrix participates in this selection.
"""
from collections import deque

import numpy as np

from .memory import Memory


def select_ce_replay_extra(balls, pool_images, pool_labels,
                           pool_ids, anchors, previous_extra, previous_features,
                           budget, seed, revision):
    """Fill unused raw-image capacity with distinct, ball-stratified CE images.

    ``pool_*`` is exactly the finite support already used by the current
    maintenance.  Older CE-only images are separate: they never enter ball
    creation, centers, radii, representative selection or historical losses.
    They are reassigned to a current same-label ball solely to balance replay
    selection and to identify which ball their CE replay may activate.
    """
    if budget < len(anchors.labels):
        raise AssertionError('granular-ball anchors exceed the shared memory budget')
    capacity = budget - len(anchors.labels)
    if capacity == 0 or not balls:
        return Memory.empty()
    pool_labels = np.asarray(pool_labels, dtype=np.int64)
    pool_ids = np.asarray(pool_ids, dtype=np.int64)
    if len(pool_images) != len(pool_labels) or len(pool_ids) != len(pool_labels):
        raise ValueError('maintenance pool images, labels and IDs must align')
    if len(previous_extra.labels) != len(previous_features):
        raise ValueError('previous CE replay features must align with images')

    # Current pool members have exact ownership after the final merge/split.
    # Deleted outliers or pruned balls have no owner and are not replayed.
    owner = np.full(len(pool_ids), '', dtype='U64')
    ball_by_label = {}
    for ball in balls:
        key = str(ball.ball_id)
        rows = np.asarray(ball.indices, dtype=np.int64)
        if np.any(owner[rows] != ''):
            raise AssertionError('current ball ownership overlaps')
        if np.any(pool_labels[rows] != int(ball.label)):
            raise AssertionError('current ball owns a different-label sample')
        owner[rows] = key
        ball_by_label.setdefault(int(ball.label), []).append(ball)

    anchor_ids = set(map(int, anchors.sample_ids))
    pool_id_set = set(map(int, pool_ids))
    current_rows = np.asarray([
        i for i, sample_id in enumerate(pool_ids)
        if owner[i] and int(sample_id) not in anchor_ids
    ], dtype=np.int64)

    # Old CE-only pictures were intentionally excluded from geometry updates.
    # Re-express them under the current network and attach each to the nearest
    # current ball of its own label; no cross-label association is permitted.
    old_rows = []
    old_owners = []
    for label in sorted(ball_by_label):
        rows = np.flatnonzero(np.asarray(previous_extra.labels) == label)
        rows = np.asarray([
            row for row in rows
            if int(previous_extra.sample_ids[row]) not in anchor_ids
            and int(previous_extra.sample_ids[row]) not in pool_id_set
        ], dtype=np.int64)
        if not len(rows):
            continue
        same_label_balls = sorted(ball_by_label[label], key=lambda ball: str(ball.ball_id))
        centers = np.asarray([ball.center for ball in same_label_balls])
        points = np.asarray(previous_features[rows])
        # A class normally has only a few balls.  This (N x B_class) matrix
        # avoids the prohibitive N x B x feature-dimension broadcast.
        squared = (np.sum(points * points, axis=1)[:, None]
                   + np.sum(centers * centers, axis=1)[None, :]
                   - 2.0 * points @ centers.T)
        nearest = np.argmin(squared, axis=1)
        old_rows.extend(rows.tolist())
        old_owners.extend(str(same_label_balls[j].ball_id) for j in nearest)

    if len(current_rows) + len(old_rows) == 0:
        return Memory.empty()
    image_parts, label_parts, id_parts, owner_parts = [], [], [], []
    if len(current_rows):
        image_parts.append(pool_images[current_rows])
        label_parts.append(pool_labels[current_rows])
        id_parts.append(pool_ids[current_rows])
        owner_parts.append(owner[current_rows])
    if old_rows:
        rows = np.asarray(old_rows, dtype=np.int64)
        image_parts.append(previous_extra.images[rows])
        label_parts.append(previous_extra.labels[rows])
        id_parts.append(previous_extra.sample_ids[rows])
        owner_parts.append(np.asarray(old_owners, dtype='U64'))
    images = np.concatenate(image_parts)
    labels = np.concatenate(label_parts)
    sample_ids = np.concatenate(id_parts)
    ball_ids = np.concatenate(owner_parts)
    if len(np.unique(sample_ids)) != len(sample_ids):
        raise AssertionError('CE replay candidates contain duplicate sample IDs')

    grouped = {}
    for row, (label, ball_id) in enumerate(zip(labels, ball_ids)):
        grouped.setdefault(int(label), {}).setdefault(str(ball_id), []).append(row)
    rng = np.random.default_rng(np.random.SeedSequence([int(seed), int(revision)]))
    queues = {
        label:{ball_id:deque(rng.permutation(rows).tolist())
               for ball_id, rows in sorted(balls_for_class.items())}
        for label, balls_for_class in sorted(grouped.items())
    }
    ball_cycles = {label:deque(sorted(groups)) for label, groups in queues.items()}
    class_cycle = deque(sorted(queues))
    selected = []
    while class_cycle and len(selected) < capacity:
        label = class_cycle.popleft()
        cycle = ball_cycles[label]
        ball_id = cycle.popleft()
        selected.append(queues[label][ball_id].popleft())
        if queues[label][ball_id]:
            cycle.append(ball_id)
        if cycle:
            class_cycle.append(label)
    selected = np.asarray(selected, dtype=np.int64)
    if len(selected) != min(capacity, len(sample_ids)):
        raise AssertionError('CE replay allocation failed to use available slots')
    return Memory(images[selected].copy(), labels[selected].copy(),
                  sample_ids[selected].copy(), ball_ids[selected].copy(),
                  np.full(len(selected), 'ce', dtype='U8'))
