"""粒球代表点记忆选择。

每个粒球在每个阶段结束后，从最终粒球中重新选择最多 5 个代表样本，
保存原始图片而不是旧特征：

1. 第 1 个代表点：距离粒球中心最近的真实样本（core）。
2. 第 2 个代表点：距离粒球中心最远的真实样本（历史最大半径样本）。
3. 第 3~5 个代表点：优先从边界区域中选择，使第 2~5 个外围点的
   特征均值尽可能接近粒球中心。
4. 若边界区域不足 4 个样本（即除最大半径点外不足 3 个边界点），
   保留已有边界点，并从粒球内部样本中补足。
5. 若整个粒球样本数 <= 5，则直接保存该粒球的全部样本。

memory 中 images 是 uint8 NHWC 原图；feature 从不作为下一阶段 replay 数据。
ball_ids 将代表点关联到稳定球 ID。每个球的成员构成一个划分，因此代表点不重复。
"""

from dataclasses import dataclass
from itertools import combinations, islice
from math import comb

import numpy as np


# 当组合数不大时严格遍历所有候选组合；组合数过大时使用确定性的
# 贪心 + 局部替换，避免大粒球出现 O(n^3) 的不可接受开销。
_MAX_EXACT_COMBINATIONS = 50_000
_EXACT_BATCH_SIZE = 2_048


@dataclass
class Memory:
    images: np.ndarray
    labels: np.ndarray
    sample_ids: np.ndarray
    ball_ids: np.ndarray
    roles: np.ndarray

    @classmethod
    def empty(cls):
        return cls(
            np.empty((0, 32, 32, 3), np.uint8),
            np.empty(0, np.int64),
            np.empty(0, np.int64),
            np.empty(0, dtype="U64"),
            np.empty(0, dtype="U8"),
        )

    def save(self, path):
        np.savez_compressed(
            path,
            images=self.images,
            labels=self.labels,
            sample_ids=self.sample_ids,
            ball_ids=self.ball_ids,
            roles=self.roles,
        )

    @classmethod
    def load(cls, path):
        with np.load(path, allow_pickle=False) as data:
            return cls(
                **{
                    key: data[key].copy()
                    for key in (
                        "images",
                        "labels",
                        "sample_ids",
                        "ball_ids",
                        "roles",
                    )
                }
            )


def _centroid_error(points, indices, center):
    """外围代表点均值到粒球中心的欧氏距离。"""
    if len(indices) == 0:
        return np.inf
    centroid = np.mean(points[np.asarray(indices, dtype=np.int64)], axis=0)
    return float(np.linalg.norm(centroid - center))


def _exact_subset_min_centroid(points, center, fixed_indices, candidate_indices, choose_n):
    """严格遍历组合，选择使最终 4 个外围点均值最接近中心的子集。"""
    fixed_indices = [int(i) for i in fixed_indices]
    candidate_indices = np.asarray(candidate_indices, dtype=np.int64)

    if choose_n == 0:
        return []

    iterator = combinations(candidate_indices.tolist(), choose_n)
    best_choice = None
    best_error = np.inf

    while True:
        batch = list(islice(iterator, _EXACT_BATCH_SIZE))
        if not batch:
            break

        batch_arr = np.asarray(batch, dtype=np.int64)
        fixed_sum = np.sum(points[np.asarray(fixed_indices, dtype=np.int64)], axis=0)
        chosen_sum = np.sum(points[batch_arr], axis=1)

        # fixed + chosen 最终总数应为 4 个外围点。
        centroids = (fixed_sum[None, :] + chosen_sum) / 4.0
        errors = np.linalg.norm(centroids - center[None, :], axis=1)

        local_pos = int(np.argmin(errors))
        local_error = float(errors[local_pos])

        if local_error < best_error:
            best_error = local_error
            best_choice = batch_arr[local_pos].tolist()

    if best_choice is None:
        raise RuntimeError("代表点组合搜索失败。")

    return [int(i) for i in best_choice]


def _approx_subset_min_centroid(points, center, fixed_indices, candidate_indices, choose_n):
    """组合过多时的确定性近似：贪心初始化 + 单点局部替换。"""
    fixed = [int(i) for i in fixed_indices]
    pool = [int(i) for i in np.asarray(candidate_indices, dtype=np.int64).tolist()]

    if choose_n == 0:
        return []

    selected = []
    current_sum = np.sum(points[np.asarray(fixed, dtype=np.int64)], axis=0)

    # 贪心：每次选择最接近“剩余目标均值”的样本。
    for step in range(choose_n):
        remaining_slots = choose_n - step
        target_sum = 4.0 * center - current_sum
        target_per_slot = target_sum / float(remaining_slots)

        available = [i for i in pool if i not in selected]
        candidate_points = points[np.asarray(available, dtype=np.int64)]
        distances = np.linalg.norm(candidate_points - target_per_slot[None, :], axis=1)
        chosen = int(available[int(np.argmin(distances))])

        selected.append(chosen)
        current_sum = current_sum + points[chosen]

    # 局部替换：逐个位置尝试换成其他候选点，只接受使最终均值更接近中心的替换。
    improved = True
    while improved:
        improved = False
        base_indices = fixed + selected
        base_error = _centroid_error(points, base_indices, center)

        for pos in range(len(selected)):
            used_without_pos = set(fixed + selected[:pos] + selected[pos + 1 :])
            available = [i for i in pool if i not in used_without_pos]

            best_value = selected[pos]
            best_error = base_error

            for candidate in available:
                trial = selected.copy()
                trial[pos] = int(candidate)
                error = _centroid_error(points, fixed + trial, center)

                if error + 1e-12 < best_error:
                    best_error = error
                    best_value = int(candidate)

            if best_value != selected[pos]:
                selected[pos] = best_value
                improved = True
                break

    return selected


def _select_subset_min_centroid(points, center, fixed_indices, candidate_indices, choose_n):
    """选择若干点，使 fixed + selected 共 4 个外围点的均值最接近 center。"""
    candidate_indices = np.asarray(candidate_indices, dtype=np.int64)

    if choose_n < 0:
        raise ValueError("choose_n 不能为负数。")
    if choose_n == 0:
        return []
    if len(candidate_indices) < choose_n:
        raise ValueError("候选样本数不足，无法补足代表点。")

    combination_count = comb(len(candidate_indices), choose_n)

    if combination_count <= _MAX_EXACT_COMBINATIONS:
        return _exact_subset_min_centroid(
            points,
            center,
            fixed_indices,
            candidate_indices,
            choose_n,
        )

    return _approx_subset_min_centroid(
        points,
        center,
        fixed_indices,
        candidate_indices,
        choose_n,
    )


def _adaptive_coverage_indices(points, center, radius, mean_radius, min_count,
                               max_count, coverage_error, epsilon):
    """按可解释的几何覆盖误差为一个粒球选择 3～max_count 个代表点。

    初始三种角色分别是：离中心最近的核心点、最接近平均半径的典型点、
    最大半径点。随后每次加入距离当前代表集合最远的真实成员。停止量为

        mean_i min_{q in representatives} ||x_i-q|| / max(radius, epsilon)

    它衡量成员被当前代表集合覆盖时的平均相对误差，不读取 validation/test。
    """
    points=np.asarray(points)
    center=np.asarray(center)
    n=len(points)
    if n==0:
        return np.empty(0,np.int64),[]
    if min_count<1 or max_count<min_count or coverage_error<0 or epsilon<=0:
        raise ValueError('invalid adaptive representative settings')

    distances=np.linalg.norm(points-center,axis=1)
    core=int(np.argmin(distances))
    selected=[core]

    # 最大半径点优先从非 core 成员中取得，退化球也保证索引不同。
    remaining=np.asarray([i for i in range(n) if i!=core],dtype=np.int64)
    farthest=None
    if len(remaining):
        farthest=int(remaining[np.argmax(distances[remaining])])

    # 典型点是真实成员中最接近 mean_radius 的点，并与 core/max 不重复。
    typical_candidates=np.asarray(
        [i for i in range(n) if i!=core and i!=farthest],dtype=np.int64)
    typical=None
    if len(typical_candidates):
        typical=int(typical_candidates[
            np.argmin(np.abs(distances[typical_candidates]-float(mean_radius)))])
        selected.append(typical)
    if farthest is not None:
        selected.append(farthest)

    target_min=min(n,min_count)
    target_max=min(n,max_count)
    # 极小粒球或 min_count>3 时仍用同一最远点覆盖原则补足最小数量。
    while len(selected)<target_min:
        available=np.asarray([i for i in range(n) if i not in set(selected)],dtype=np.int64)
        nearest=np.linalg.norm(
            points[available,None]-points[np.asarray(selected,dtype=np.int64)][None],axis=2).min(axis=1)
        selected.append(int(available[np.argmax(nearest)]))

    denominator=max(float(radius),float(epsilon))
    while len(selected)<target_max:
        distance_to_selected=np.linalg.norm(
            points[:,None]-points[np.asarray(selected,dtype=np.int64)][None],axis=2)
        nearest=distance_to_selected.min(axis=1)
        relative_error=float(nearest.mean()/denominator)
        if relative_error<=coverage_error:
            break
        nearest[np.asarray(selected,dtype=np.int64)]=-np.inf
        selected.append(int(np.argmax(nearest)))

    if len(set(selected))!=len(selected):
        raise RuntimeError('adaptive representatives contain duplicate indices')
    return (np.asarray(selected,dtype=np.int64),
            ['core']+['boundary']*(len(selected)-1))


def representative_indices(points, center, radius, mean_radius, *, mode='fixed5',
                           min_count=3, max_count=8, coverage_error=0.25,
                           epsilon=1e-8):
    """返回粒球代表点的局部索引及角色。

    规则
    ----
    1. 若粒球样本数 <= 5，直接返回全部样本；为保持顺序语义，
       第一个位置放距离中心最近的样本，第二个位置（若存在）放最远样本。
    2. 若样本数 >= 5：
       - p1：距离中心最近的样本；
       - p2：距离中心最远的样本；
       - p3,p4,p5：优先从边界区域
         mean_radius < d <= radius 中选取，使 p2~p5 的均值最接近 center。
    3. 若边界区域总样本数 < 4，则保留所有已有边界样本，
       再从粒球内部 d <= mean_radius 的剩余样本中补足到 4 个外围代表点。

    注意
    ----
    roles 继续沿用旧代码中的 "core" / "boundary" 两类字符串，
    以避免破坏现有 memory 文件格式和下游代码。对于边界不足时由内部补入的样本，
    role 仍记为 "boundary"，其含义此时是“非 core 的外围/支撑代表点”。
    """
    if mode=='adaptive_coverage':
        return _adaptive_coverage_indices(
            points,center,radius,mean_radius,min_count,max_count,
            coverage_error,epsilon)
    if mode not in ('fixed5', 'fixed_k'):
        raise ValueError('representative mode must be fixed5, fixed_k or adaptive_coverage')

    points = np.asarray(points)
    center = np.asarray(center)

    n = len(points)
    if n == 0:
        return np.empty(0, np.int64), []

    distances = np.linalg.norm(points - center, axis=1)
    core = int(np.argmin(distances))

    # --------------------------------------------------------
    target_count = 5 if mode == 'fixed5' else int(max_count)
    if target_count < 3:
        raise ValueError('fixed_k requires at least 3 representatives per ball')
    target_count = min(target_count, n)

    # 小粒球：成员数不超过目标保存数时，全部保留。
    # 顺序保持 p1=core；若还有样本，p2 放最远的非 core 样本。
    # --------------------------------------------------------
    if n <= target_count:
        if n == 1:
            ordered = [core]
        else:
            non_core = np.asarray([i for i in range(n) if i != core], dtype=np.int64)
            farthest = int(non_core[np.argmax(distances[non_core])])
            remaining = [i for i in range(n) if i not in {core, farthest}]
            ordered = [core, farthest] + remaining

        roles = ["core"] + ["boundary"] * (len(ordered) - 1)
        return np.asarray(ordered, dtype=np.int64), roles

    # --------------------------------------------------------
    # p2：整个粒球中距离中心最远的真实样本。
    # 强制与 core 不同；即使所有点距离都相同也会选择另一个样本。
    # --------------------------------------------------------
    non_core = np.asarray([i for i in range(n) if i != core], dtype=np.int64)
    farthest = int(non_core[np.argmax(distances[non_core])])

    # --------------------------------------------------------
    # 边界区域：mean_radius < d <= radius。
    # 加一个很小的数值容差，避免浮点误差把恰好位于 radius 的点排除。
    # --------------------------------------------------------
    tol = 1e-12 * max(1.0, abs(float(radius)))
    boundary_all = np.flatnonzero(
        (distances > float(mean_radius))
        & (distances <= float(radius) + tol)
    ).astype(np.int64)

    # core 永远不作为外围点。
    boundary_all = boundary_all[boundary_all != core]

    # p2 是固定的最大半径代表点，不再进入 p3~p5 的候选集合。
    boundary_extra = boundary_all[boundary_all != farthest]

    # --------------------------------------------------------
    needed_extra = target_count - 2

    # 情况 A：边界区域足够，按目标 K 从边界候选中选择外围点。
    # 目标：最大半径点和其余外围点的均值尽量接近 center。
    # --------------------------------------------------------
    if len(boundary_extra) >= needed_extra:
        chosen = _select_subset_min_centroid(
            points=points,
            center=center,
            fixed_indices=[farthest],
            candidate_indices=boundary_extra,
            choose_n=needed_extra,
        )
        outer = [farthest] + chosen

    # --------------------------------------------------------
    # 情况 B：边界区域不足目标数。
    # p2 + 所有已有边界样本先固定，再从内部样本中补足。
    # --------------------------------------------------------
    else:
        fixed_outer = [farthest] + [int(i) for i in boundary_extra.tolist()]
        need = target_count - 1 - len(fixed_outer)

        fixed_set = set([core] + fixed_outer)

        # 优先只从真正的内部区域 d <= mean_radius 中补足。
        interior = np.flatnonzero(distances <= float(mean_radius)).astype(np.int64)
        interior = np.asarray(
            [int(i) for i in interior.tolist() if int(i) not in fixed_set],
            dtype=np.int64,
        )

        # 正常情况下 n >= target_count 时一定有足够剩余样本。
        # 如果由于 radius / mean_radius 与实际点距离不一致导致内部样本不足，
        # 再退化到“所有尚未使用的粒球样本”中补足，确保不 silently drop。
        if len(interior) < need:
            interior_set = set(interior.tolist())
            fallback = [
                i
                for i in range(n)
                if i not in fixed_set and i not in interior_set
            ]
            interior = np.concatenate(
                [interior, np.asarray(fallback, dtype=np.int64)]
            )

        chosen = _select_subset_min_centroid(
            points=points,
            center=center,
            fixed_indices=fixed_outer,
            candidate_indices=interior,
            choose_n=need,
        )
        outer = fixed_outer + chosen

    selected = [core] + outer

    # 防御性检查：样本足够时必须恰好选到目标数量，且不能重复。
    if len(selected) != target_count:
        raise RuntimeError(
            f"代表点数量错误：期望 {target_count}，实际 {len(selected)}。"
        )
    if len(set(selected)) != target_count:
        raise RuntimeError("代表点出现重复局部索引。")

    return (
        np.asarray(selected, dtype=np.int64),
        ["core"] + ["boundary"] * (target_count - 1),
    )


def _balanced_class_quotas(balls, budget, quota_offset=0):
    """Allocate a fixed image budget as evenly across labels as ball coverage permits.

    Every retained ball needs one real image so that it can be embedded again after
    the network changes.  The number of balls in a class is therefore a hard lower
    bound for that class.  Remaining slots are assigned to the currently smallest
    class allocation; ``quota_offset`` rotates deterministic remainder priority
    between maintenance revisions.
    """
    grouped = {}
    for ball in balls:
        grouped.setdefault(int(ball.label), []).append(ball)
    labels = sorted(grouped)
    capacities = {label: sum(len(ball.indices) for ball in grouped[label])
                  for label in labels}
    quotas = {label: len(grouped[label]) for label in labels}
    target = min(int(budget), sum(capacities.values()))
    required = sum(quotas.values())
    if target < required:
        raise ValueError(
            f"representative_memory_budget={budget} is smaller than "
            f"number_of_balls={required}; preserving every ball requires at least "
            "one real representative per ball"
        )
    if not labels:
        return grouped, quotas, target

    rotated = labels[quota_offset % len(labels):] + labels[:quota_offset % len(labels)]
    priority = {label: position for position, label in enumerate(rotated)}
    remaining = target - required
    while remaining:
        eligible = [label for label in labels if quotas[label] < capacities[label]]
        if not eligible:
            break
        label = min(eligible, key=lambda item: (quotas[item], priority[item]))
        quotas[label] += 1
        remaining -= 1
    return grouped, quotas, target


def _class_balanced_budget_rows(balls, features, budget, epsilon, quota_offset=0):
    """Select core/boundary/coverage representatives under one global budget.

    Selection has three deterministic layers:
      1. one center-nearest core for every current ball;
      2. while the class quota permits, farthest boundary anchors;
      3. remaining positions maximize effective-mass weighted reduction of the
         normalized nearest-representative coverage error E_k.

    The effective mass is an importance weight inside a class.  It is not a
    persistent activity score and is never used to delete a ball.
    """
    if budget < 1 or epsilon <= 0:
        raise ValueError('budget and epsilon must be positive')
    grouped, quotas, target = _balanced_class_quotas(balls, budget, quota_offset)
    selected_rows, selected_owners, selected_roles = [], [], []

    for label in sorted(grouped):
        class_balls = sorted(grouped[label], key=lambda ball: str(ball.ball_id))
        class_mass = sum(float(ball.effective_count) for ball in class_balls)
        states = []
        for ball in class_balls:
            local_points = np.asarray(features[ball.indices], dtype=np.float64)
            if not len(local_points):
                raise ValueError(f'ball {ball.ball_id} has no support samples')
            center_distances = np.linalg.norm(local_points - ball.center, axis=1)
            core = int(np.argmin(center_distances))
            # Pairwise distances are computed once per maintenance revision and
            # reused for every marginal coverage-gain decision for this ball.
            squared = (np.sum(local_points * local_points, axis=1)[:, None]
                       + np.sum(local_points * local_points, axis=1)[None, :]
                       - 2.0 * local_points @ local_points.T)
            pairwise = np.sqrt(np.maximum(squared, 0.0))
            non_core = np.asarray([i for i in range(len(local_points)) if i != core],
                                  dtype=np.int64)
            boundary = (int(non_core[np.argmax(center_distances[non_core])])
                        if len(non_core) else None)
            states.append({
                'ball': ball,
                'selected': [core],
                'roles': ['core'],
                'remaining': set(map(int, non_core.tolist())),
                'boundary': boundary,
                'pairwise': pairwise,
                'nearest': pairwise[:, core].copy(),
                'denominator': max(float(ball.radius), float(epsilon)),
                'mass_weight': (float(ball.effective_count) / class_mass
                                if class_mass else 0.0),
            })

        slots = quotas[label] - len(states)

        def gain(state, candidate):
            improved = np.minimum(state['nearest'], state['pairwise'][:, candidate])
            delta = float(np.mean(state['nearest'] - improved) /
                          state['denominator'])
            return state['mass_weight'] * delta

        def add(state, candidate):
            state['selected'].append(int(candidate))
            state['roles'].append('boundary')
            state['remaining'].remove(int(candidate))
            state['nearest'] = np.minimum(
                state['nearest'], state['pairwise'][:, int(candidate)])

        # Give farthest structural anchors before generic coverage points.  If a
        # class cannot afford all boundaries, the largest weighted gain wins.
        while slots:
            candidates = [(gain(state, state['boundary']), str(state['ball'].ball_id),
                           state['boundary'], state)
                          for state in states
                          if state['boundary'] is not None
                          and state['boundary'] in state['remaining']]
            if not candidates:
                break
            _, _, candidate, state = max(
                candidates, key=lambda item: (item[0], item[1], -int(item[2])))
            add(state, candidate)
            slots -= 1

        # Allocate all remaining class slots by exact marginal reduction of E_k.
        while slots:
            best = None
            for state in states:
                for candidate in state['remaining']:
                    proposal = (gain(state, candidate), str(state['ball'].ball_id),
                                -int(candidate), int(candidate), state)
                    if best is None or proposal[:3] > best[:3]:
                        best = proposal
            if best is None:
                break
            add(best[4], best[3])
            slots -= 1

        if slots:
            raise AssertionError(f'class {label} representative quota was not filled')
        for state in states:
            ball = state['ball']
            local = np.asarray(state['selected'], dtype=np.int64)
            global_rows = np.asarray(ball.indices, dtype=np.int64)[local]
            selected_rows.extend(global_rows.tolist())
            selected_owners.extend([ball.ball_id] * len(global_rows))
            selected_roles.extend(state['roles'])
            ball.representative_ids = []  # populated by reselect_memory below

    if len(selected_rows) != target:
        raise AssertionError(
            f'fixed memory selection produced {len(selected_rows)} rows, expected {target}')
    return (np.asarray(selected_rows, dtype=np.int64), selected_owners,
            selected_roles, quotas)


def select_balls_for_budget(balls, budget, *, retain_limit=None):
    """Only prune structures when even one image per ball exceeds the hard budget.

    The fast experiment keeps all balls while B <= M.  In the exceptional B > M
    case, it gives retained classes one ball before a class can receive another,
    and then prefers larger effective support.  The requested three-point
    overflow target is used when it can preserve every seen class; otherwise
    preserving one ball per class takes priority when M permits it.  Removed
    effective mass is returned to the caller for persistent mass accounting.
    """
    if len(balls) <= budget:
        return list(balls), [], 0.0
    if budget < 1:
        raise ValueError('memory budget must be positive')
    by_class = {}
    for ball in balls:
        by_class.setdefault(int(ball.label), []).append(ball)
    for group in by_class.values():
        group.sort(key=lambda ball: (-float(ball.effective_count), str(ball.ball_id)))
    class_count = len(by_class)
    if retain_limit is None:
        target = max(1, budget // 3)
        if class_count <= budget:
            target = max(target, class_count)
        target = min(target, budget)
    else:
        # fixed5 + hard-cap mode sacrifices as few structures as possible:
        # first reduce representative counts, and only when B>M remove B-M.
        target = min(int(retain_limit), budget)
    retained = []
    counts = {label: 0 for label in by_class}
    while len(retained) < target:
        eligible = [label for label, group in by_class.items() if group]
        label = min(eligible, key=lambda c: (counts[c],
                    -float(by_class[c][0].effective_count), c))
        retained.append(by_class[label].pop(0))
        counts[label] += 1
    retained_ids = {str(ball.ball_id) for ball in retained}
    removed = [ball for ball in balls if str(ball.ball_id) not in retained_ids]
    return retained, removed, float(sum(ball.effective_count for ball in removed))


def _budgeted_fast_rows(balls, features, budget, max_per_ball, epsilon):
    """Bound memory without filling unused capacity or building N-by-N matrices.

    Each ball gets a real center-nearest core.  Available slots add its farthest
    boundary point, then farthest-first coverage points.  This is an inexpensive
    approximation to the exact E_k marginal-gain search, not the same selector.
    Allocation proceeds in layers so 2B<=M and 3B<=M yield the intended
    two-/three-point guarantees, subject to a ball having enough distinct rows.
    """
    if budget < len(balls):
        raise ValueError('budgeted_fast requires at least one image per ball')
    states = []
    class_sizes = {}
    class_mass = {}
    for ball in balls:
        label = int(ball.label)
        class_sizes[label] = class_sizes.get(label, 0) + 1
        class_mass[label] = class_mass.get(label, 0.0) + ball.effective_count
    for ball in sorted(balls, key=lambda item: str(item.ball_id)):
        rows = np.asarray(ball.indices, dtype=np.int64)
        points = np.asarray(features[rows], dtype=np.float64)
        if not len(points):
            raise ValueError(f'ball {ball.ball_id} has no support samples')
        center_distance = np.linalg.norm(points - ball.center, axis=1)
        core = int(np.argmin(center_distance))
        nearest = np.linalg.norm(points - points[core], axis=1)
        states.append(dict(ball=ball, rows=rows, points=points,
                           center_distance=center_distance, selected=[core],
                           roles=['core'], nearest=nearest,
                           mass_weight=(ball.effective_count /
                                        class_mass[int(ball.label)])))
    target = min(int(budget), sum(min(len(s['rows']), max_per_ball) for s in states))
    class_alloc = {label: count for label, count in class_sizes.items()}
    remaining = target - len(states)
    for level in range(2, max_per_ball + 1):
        if remaining == 0:
            break
        eligible = [state for state in states
                    if len(state['selected']) == level - 1 and
                    len(state['rows']) >= level]
        while eligible and remaining:
            proposals = []
            for state in eligible:
                candidates = np.ones(len(state['rows']), dtype=bool)
                candidates[state['selected']] = False
                if level == 2:
                    score = state['center_distance'].copy()
                else:
                    score = state['nearest'].copy()
                score[~candidates] = -np.inf
                local = int(np.argmax(score))
                gain = float(score[local] / max(float(state['ball'].radius), epsilon))
                label = int(state['ball'].label)
                proposals.append((class_alloc[label],
                                  -state['mass_weight'] * gain,
                                  str(state['ball'].ball_id), local, state))
            _, _, _, local, chosen = min(proposals, key=lambda item: item[:4])
            chosen['selected'].append(local)
            chosen['roles'].append('boundary')
            chosen['nearest'] = np.minimum(
                chosen['nearest'], np.linalg.norm(
                    chosen['points'] - chosen['points'][local], axis=1))
            class_alloc[int(chosen['ball'].label)] += 1
            eligible = [state for state in eligible if state is not chosen]
            remaining -= 1
    if remaining:
        raise AssertionError('fast memory allocation did not fill attainable slots')
    selected_rows, owners, roles = [], [], []
    for state in states:
        rows = state['rows'][state['selected']]
        selected_rows.extend(rows.tolist())
        owners.extend([state['ball'].ball_id] * len(rows))
        roles.extend(state['roles'])
    return np.asarray(selected_rows, dtype=np.int64), owners, roles


def reselect_memory(balls, features, images, labels, sample_ids, *,
                    selection_mode='fixed5', min_per_ball=3, max_per_ball=8,
                    coverage_error=0.25, memory_budget=0, quota_offset=0,
                    epsilon=1e-8, random_seed=2026):
    rows, owners, roles = [], [], []

    if selection_mode == 'random_members':
        # L_gb 消融使用与几何代表点相同的全局图片预算，但不再根据球心、
        # 半径或边界挑点。将当前维护池中的真实 ownership 成员合并后，
        # 用固定 seed + maintenance revision 无放回均匀抽取 M 张。
        # 每张抽中的图片仍记录所属 ball_id，以保留同样的类别记忆和 CE 回放接口。
        if memory_budget < 1:
            raise ValueError('random_members requires a positive memory_budget')
        member_rows = np.concatenate([
            np.asarray(ball.indices, dtype=np.int64) for ball in balls
            if len(ball.indices)
        ]) if any(len(ball.indices) for ball in balls) else np.empty(0, dtype=np.int64)
        if len(np.unique(member_rows)) != len(member_rows):
            raise ValueError('ball ownership overlaps; random member sampling requires unique rows')
        take = min(int(memory_budget), len(member_rows))
        rng = np.random.default_rng(np.random.SeedSequence([int(random_seed), int(quota_offset)]))
        # 保底：每个非空球至少保留 1 个成员，否则下一轮无法恢复该历史球。
        guaranteed = [int(ball.indices[int(rng.integers(len(ball.indices)))])
                      for ball in balls if len(ball.indices)]
        if len(guaranteed) > take:
            raise ValueError(
                'random_members cannot preserve every current ball: '
                f'number_of_balls={len(guaranteed)} exceeds memory_budget={memory_budget}. '
                'Increase the memory budget or reduce the number of balls before this ablation.'
            )
        remaining = take - len(guaranteed)
        if remaining > 0:
            pool = np.asarray([int(r) for r in member_rows if int(r) not in guaranteed],
                              dtype=np.int64)
            extra = (rng.choice(pool, size=remaining, replace=False)
                     if remaining <= len(pool) else pool)
            rows = np.sort(np.concatenate(
                [np.asarray(guaranteed, dtype=np.int64), extra])).tolist()
        else:
            rows = np.sort(np.asarray(guaranteed, dtype=np.int64)).tolist()
        owner_by_row = np.empty(len(images), dtype='U64')
        ball_by_id = {str(ball.ball_id): ball for ball in balls}
        for ball in balls:
            owner_by_row[np.asarray(ball.indices, dtype=np.int64)] = str(ball.ball_id)
            ball.representative_ids = []
        owners = owner_by_row[np.asarray(rows, dtype=np.int64)].tolist()
        roles = ['random'] * len(rows)
        for row, owner in zip(rows, owners):
            ball_by_id[owner].representative_ids.append(int(sample_ids[row]))
    elif selection_mode == 'budgeted_fast':
        rows, owners, roles = _budgeted_fast_rows(
            balls, features, memory_budget, max_per_ball, epsilon)
        owner_array = np.asarray(owners, dtype='U64')
        for ball in balls:
            owned = rows[owner_array == str(ball.ball_id)]
            ball.representative_ids = sample_ids[owned].tolist()
    elif selection_mode == 'class_balanced_budget':
        rows, owners, roles, _ = _class_balanced_budget_rows(
            balls, features, memory_budget, epsilon, quota_offset)
        owner_array = np.asarray(owners, dtype='U64')
        for ball in balls:
            owned = rows[owner_array == str(ball.ball_id)]
            ball.representative_ids = sample_ids[owned].tolist()
    else:
        for ball in balls:
            local, kinds = representative_indices(
                features[ball.indices],
                ball.center,
                ball.radius,
                ball.mean_radius,
                mode=selection_mode,
                min_count=min_per_ball,
                max_count=max_per_ball,
                coverage_error=coverage_error,
                epsilon=epsilon,
            )
            selected = ball.indices[local]

            rows.extend(selected.tolist())
            owners.extend([ball.ball_id] * len(selected))
            roles.extend(kinds)
            ball.representative_ids = sample_ids[selected].tolist()

    if selection_mode in ('fixed5', 'fixed_k') and memory_budget and len(rows) > memory_budget:
        # First run the original fixed5 selector unchanged.  Only when its
        # actual output exceeds M do we trim that ordered set.  This retains
        # the original core, farthest boundary and p3..p5 order; no new
        # expensive E_k search or different representative-selection rule is
        # introduced.  Give every ball a core before allocating second,
        # third, fourth and fifth images in class-balanced layers.
        if len(balls) > memory_budget:
            raise ValueError('fixed5 budget needs ball pruning before memory selection')
        positions = {}
        for pos, owner in enumerate(owners):
            positions.setdefault(str(owner), []).append(pos)
        by_id = {str(ball.ball_id): ball for ball in balls}
        chosen = [items[0] for items in positions.values()]
        class_counts = {}
        class_mass = {}
        for ball in balls:
            label = int(ball.label)
            class_counts[label] = class_counts.get(label, 0) + 1
            class_mass[label] = class_mass.get(label, 0.0) + ball.effective_count
        remaining = memory_budget - len(chosen)
        max_level = (5 if selection_mode == 'fixed5' else max_per_ball)
        for level in range(1, max_level):
            if remaining == 0:
                break
            eligible = [key for key, items in positions.items() if len(items) > level]
            while eligible and remaining:
                key = min(eligible, key=lambda item: (
                    class_counts[int(by_id[item].label)],
                    -by_id[item].effective_count /
                    class_mass[int(by_id[item].label)], item))
                chosen.append(positions[key][level])
                class_counts[int(by_id[key].label)] += 1
                eligible.remove(key)
                remaining -= 1
        selected_positions = sorted(chosen)
        rows = [rows[i] for i in selected_positions]
        owners = [owners[i] for i in selected_positions]
        roles = [roles[i] for i in selected_positions]
        owner_array = np.asarray(owners, dtype='U64')
        row_array = np.asarray(rows, dtype=np.int64)
        for ball in balls:
            owned = row_array[owner_array == str(ball.ball_id)]
            ball.representative_ids = sample_ids[owned].tolist()

    if len(rows) == 0:
        return Memory.empty()

    rows = np.asarray(rows, dtype=np.int64)

    if len(np.unique(sample_ids[rows])) != len(rows):
        raise ValueError("memory 代表点全局 ID 重复；请检查球成员划分")

    return Memory(
        images[rows].copy(),
        labels[rows].copy(),
        sample_ids[rows].copy(),
        np.asarray(owners, dtype="U64"),
        np.asarray(roles, dtype="U8"),
    )
