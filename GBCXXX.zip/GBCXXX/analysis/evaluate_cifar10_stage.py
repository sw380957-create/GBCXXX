"""
analysis/evaluate_cifar10_stage.py这个是最终版本
============================================================
CIFAR-10 Task-Free 数据流阶段测试
============================================================
该脚本把以下步骤串联起来：
    当前阶段 ResNet18 checkpoint
            ↓
    CIFAR-10 官方 test set
            ↓
    提取当前阶段 512 维测试特征
            ↓
    根据 Task-Free 类别日程确定“截至当前阶段已见类别”
            ↓
    加载当前阶段粒球
            ↓
    基于粒球响应进行分类
            ↓
    输出 ACC / 每类 ACC / Coverage / Confusion Matrix
            ↓
    保存当前阶段测试特征、标签和 JSON 结果

============================================================
与现有工程保持一致
============================================================
1. 网络：
    models/resnet18_cifar.py
    ResNet18_CIFAR

    forward 返回：
        logits, feature

    feature 维度：
        512

2. checkpoint：
    train/pretrain.py 使用：

        torch.save(
            model.state_dict(),
            ".../resnet18_D1.pth"
        )

    因此本脚本直接加载 state_dict。

3. 输入预处理：
    data/cifar10_strict_stream.py 的训练集使用：transforms.ToTensor()
    因此官方 test set 也严格使用： transforms.ToTensor()
    不额外加入 Normalize，
    保证训练输入与测试输入处理一致。

4. Task-Free 测试协议：
    第 t 阶段只评价截至该阶段已经出现过的类别：C_seen^(t)=union_{tau=1}^t C_tau
    测试图片始终来自 CIFAR-10 官方 test set，
    不参与训练、粒球生成或持续学习更新。
============================================================
D1 示例
============================================================
当前数据流默认：D1 classes = [0,1,2,3]
因此 D1 后：C_seen^(1) = {0,1,2,3}
官方 CIFAR-10 test 每类 1000 张，
D1 阶段主要测试样本数为：4 × 1000 = 4000
============================================================
重要原则
============================================================
测试集图片固定，但“测试特征”不是固定的。
D1：z_test^(1) = f_theta1(x_test)
D2：z_test^(2) = f_theta2(x_test)
由于持续学习会更新网络参数，
每一个阶段都必须使用当前阶段 checkpoint
重新提取官方测试集特征。
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Dict, List, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

from data.cifar10_strict_stream import (
    build_balanced_class_schedule,
    NUM_BLOCKS,
    ACTIVE_CLASSES_PER_BLOCK,
    SEED,
)

from granular_ball.classifier import (
    GranularBallClassifier,
)
from models.resnet18_cifar import (
    ResNet18_CIFAR,
)

# ============================================================
# 1. 默认实验设置
# ============================================================
DEFAULT_PROJECT_ROOT = str(Path(__file__).resolve().parents[1])

# 与真正生成数据流的文件保持完全一致，
# 避免以后一个文件改成10块、
# 另一个文件忘记修改。
DEFAULT_NUM_BLOCKS = NUM_BLOCKS

DEFAULT_ACTIVE_CLASSES_PER_BLOCK = (
    ACTIVE_CLASSES_PER_BLOCK
)

DEFAULT_SEED = SEED

# 默认批次大小设置为128
# 批次大小是指在机器学习或深度学习中一次性输入模型进行训练的样本数量
# 较大的批次大小可以提高训练速度，但可能会占用更多内存
DEFAULT_BATCH_SIZE = 128


# ============================================================
# 2. 计算截至当前阶段已经出现过的类别
# ============================================================

def get_seen_classes(
    stage: int,
    num_blocks: int = DEFAULT_NUM_BLOCKS,
    active_classes_per_block: int = (
        DEFAULT_ACTIVE_CLASSES_PER_BLOCK
    ),
    seed: int = DEFAULT_SEED,
) -> Tuple[
    np.ndarray,
    np.ndarray,
]:
    """
    根据与训练数据流完全相同的类别日程，
    得到当前阶段以及累计已见类别。

    Parameters
    ----------
    stage : int
        当前阶段编号，从 1 开始。

        stage=1 表示 D1
        stage=2 表示 D2
        ...

    Returns
    -------
    current_classes : np.ndarray
        当前 D_t 中出现的类别。

    seen_classes : np.ndarray
        从 D1 到 D_t 累计出现过的所有类别。
    """
    if (
        stage < 1
        or
        stage > num_blocks
    ):
        raise ValueError(
            f"stage 必须位于 1~{num_blocks}。"
        )

    schedule = (
        build_balanced_class_schedule(
            num_blocks=num_blocks,
            active_classes_per_block=(
                active_classes_per_block
            ),
            num_classes=10,
            seed=seed,
            first_block_classes=(
                0,
                1,
                2,
                3,
            ),
        )
    )

    current_classes = np.unique(
        schedule[
            stage - 1
        ]
    )

    seen_classes = np.unique(
        schedule[
            :stage
        ].reshape(-1)
    )

    return (
        current_classes,
        seen_classes,
    )


# ============================================================
# 3. 加载当前阶段网络
# ============================================================

def load_stage_model(
    checkpoint_path: str,
    device: torch.device,
) -> ResNet18_CIFAR:
    """
    加载当前阶段的 ResNet18。

    当前 pretrain.py 保存格式为：

        torch.save(
            model.state_dict(),
            checkpoint_path
        )

    因此本函数直接加载 state_dict。

    同时兼容未来若改成：

        {
            "model_state_dict": ...
        }

    的保存格式。
    """
    if not os.path.isfile(
        checkpoint_path
    ):
        raise FileNotFoundError(
            "没有找到 checkpoint："
            f"{checkpoint_path}"
        )

    model = ResNet18_CIFAR(
        num_classes=10
    ).to(
        device
    )

    checkpoint = torch.load(
        checkpoint_path,
        map_location=device,
    )

    if (
        isinstance(
            checkpoint,
            dict,
        )
        and
        "model_state_dict"
        in checkpoint
    ):
        state_dict = checkpoint[
            "model_state_dict"
        ]
    else:
        state_dict = checkpoint

    model.load_state_dict(
        state_dict
    )

    model.eval()

    return model


# ============================================================
# 4. 提取当前阶段 CIFAR-10 官方测试特征
# ============================================================

def extract_test_features(
    model: ResNet18_CIFAR,
    data_root: str,
    device: torch.device,
    batch_size: int = DEFAULT_BATCH_SIZE,
) -> Tuple[
    np.ndarray,
    np.ndarray,
]:
    """
    使用当前阶段网络提取整个 CIFAR-10 官方 test set 特征。

    训练阶段额外使用：
        RandomCrop
        RandomHorizontalFlip

    这些属于训练专用随机数据增强，
    验证和测试阶段均不使用。

    测试阶段只使用：
        transforms.ToTensor()

    当前不额外使用 Normalize。

    Returns
    -------
    features : np.ndarray
        shape = (10000, 512)

    labels : np.ndarray
        shape = (10000,)
    """
    # --------------------------------------------------------
    # RandomCrop / RandomHorizontalFlip 只用于训练阶段。
    # 官方 test set 不做随机增强，只使用 ToTensor()。
    # --------------------------------------------------------
    transform = (
        transforms.ToTensor()
    )

    test_dataset = (
        datasets.CIFAR10(
            root=data_root,
            train=False,
            download=True,
            transform=transform,
        )
    )

    test_loader = (
        DataLoader(
            test_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=0,
        )
    )

    feature_list: List[
        np.ndarray
    ] = []

    label_list: List[
        np.ndarray
    ] = []

    model.eval()

    with torch.no_grad():

        for batch_index, (
            images,
            labels,
        ) in enumerate(
            test_loader
        ):

            images = images.to(
                device
            )

            # ------------------------------------------------
            # resnet18_cifar.py 定义：
            #
            # logits, feature = model(x)
            #
            # feature shape = (batch, 512)
            # ------------------------------------------------
            _, features = model(
                images
            )

            feature_list.append(
                features
                .cpu()
                .numpy()
            )

            label_list.append(
                labels.numpy()
            )

            if (
                batch_index + 1
            ) % 20 == 0:
                print(
                    "测试特征提取 batch:",
                    batch_index + 1,
                )

    features = np.concatenate(
        feature_list,
        axis=0,
    )

    labels = np.concatenate(
        label_list,
        axis=0,
    )

    if (
        features.shape[0]
        !=
        10000
    ):
        raise RuntimeError(
            "CIFAR-10 官方测试集应包含 10000 个样本，"
            f"当前得到 {features.shape[0]}。"
        )

    if (
        features.shape[1]
        !=
        512
    ):
        raise RuntimeError(
            "当前 ResNet18 特征应为 512 维，"
            f"当前得到 {features.shape[1]} 维。"
        )

    return (
        features,
        labels,
    )


# ============================================================
# 5. 保存当前阶段测试特征
# ============================================================

def save_test_features(
    features: np.ndarray,
    labels: np.ndarray,
    feature_path: str,
    label_path: str,
) -> None:
    """
    保存整个官方 test set 的当前阶段特征与标签。

    标签每个阶段相同；
    特征必须随着网络参数更新而重新提取。
    """
    feature_dir = os.path.dirname(
        feature_path
    )

    label_dir = os.path.dirname(
        label_path
    )

    if feature_dir:
        os.makedirs(
            feature_dir,
            exist_ok=True,
        )

    if label_dir:
        os.makedirs(
            label_dir,
            exist_ok=True,
        )

    np.save(
        feature_path,
        features,
    )

    np.save(
        label_path,
        labels,
    )

    print(
        "测试特征保存：",
        feature_path,
    )

    print(
        "测试标签保存：",
        label_path,
    )


# ============================================================
# 6. NumPy 混淆矩阵
# ============================================================

def confusion_matrix_numpy(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    classes: np.ndarray,
) -> np.ndarray:
    """
    行：真实类别
    列：预测类别
    """
    class_to_position = {
        int(c): i
        for i, c in enumerate(
            classes
        )
    }

    matrix = np.zeros(
        (
            len(classes),
            len(classes),
        ),
        dtype=np.int64,
    )

    for true_label, pred_label in zip(
        y_true,
        y_pred,
    ):

        if (
            int(true_label)
            in
            class_to_position
            and
            int(pred_label)
            in
            class_to_position
        ):

            matrix[
                class_to_position[
                    int(true_label)
                ],
                class_to_position[
                    int(pred_label)
                ],
            ] += 1

    return matrix

#
# ============================================================
# 7. 当前阶段粒球测试
# ============================================================


def evaluate_stage(
    features: np.ndarray,
    labels: np.ndarray,
    ball_path: str,
    current_classes: np.ndarray,
    seen_classes: np.ndarray,
    classifier_batch_size: int = 2048,
) -> Dict:
    """
    使用当前阶段粒球进行分类，并仅在累计已见类别上计算 ACC。
    测试集合：
        T_t
        =
        {(x,y) in T_test:
            y in C_seen^(t)}
    Returns
    -------
    result : dict
        包括：
            accuracy
            per_class_accuracy
            coverage_rate
            confusion_matrix
            current_classes
            seen_classes
    """
    if not os.path.isfile(
        ball_path
    ):
        raise FileNotFoundError(
            "没有找到粒球文件："
            f"{ball_path}"
        )

    # --------------------------------------------------------
    # 只取累计已见类别对应的官方测试样本。
    # --------------------------------------------------------
    mask = np.isin(
        labels,
        seen_classes,
    )

    X_eval = features[
        mask
    ]

    y_eval = labels[
        mask
    ]

    if len(y_eval) == 0:
        raise RuntimeError(
            "当前已见类别测试子集为空。"
        )

    classifier = (
        GranularBallClassifier.from_file(
            ball_path
        )
    )

    # --------------------------------------------------------
    # 当前所有已见类别都必须已有粒球。
    # --------------------------------------------------------
    missing_classes = (
        np.setdiff1d(
            seen_classes,
            classifier.classes,
        )
    )

    if len(
        missing_classes
    ) > 0:
        raise RuntimeError(
            "以下已见类别没有对应粒球："
            f"{missing_classes.tolist()}"
        )

    predictions, (
        best_class_scores
    ), covered = (
        classifier.predict_with_details(
            X_eval,
            batch_size=(
                classifier_batch_size
            ),
        )
    )

    # --------------------------------------------------------
    # 总体准确率：
    #
    # ACC_t
    # =
    # correct / N_test_seen
    # --------------------------------------------------------
    accuracy = float(
        np.mean(
            predictions
            ==
            y_eval
        )
    )

    # --------------------------------------------------------
    # 每类准确率
    # --------------------------------------------------------
    per_class_accuracy: Dict[
        str,
        float,
    ] = {}

    for c in seen_classes:

        class_mask = (
            y_eval == c
        )

        class_accuracy = float(
            np.mean(
                predictions[
                    class_mask
                ]
                ==
                y_eval[
                    class_mask
                ]
            )
        )

        per_class_accuracy[
            str(int(c))
        ] = class_accuracy

    # --------------------------------------------------------
    # 粒球几何覆盖率：
    # 样本是否落在其“预测类别”的至少一个粒球内部。
    # --------------------------------------------------------
    coverage_rate = float(
        np.mean(
            covered
        )
    )

    confusion = (
        confusion_matrix_numpy(
            y_true=y_eval,
            y_pred=predictions,
            classes=seen_classes,
        )
    )

    result = {
        "current_classes": [
            int(c)
            for c in current_classes
        ],
        "seen_classes": [
            int(c)
            for c in seen_classes
        ],
        "ball_classes": [
            int(c)
            for c in classifier.classes
        ],
        "num_test_samples": int(
            len(y_eval)
        ),
        "accuracy": accuracy,
        "accuracy_percent": (
            100.0 * accuracy
        ),
        "per_class_accuracy": (
            per_class_accuracy
        ),
        "coverage_rate": (
            coverage_rate
        ),
        "coverage_rate_percent": (
            100.0 * coverage_rate
        ),
        "mean_winning_class_response": float(
            np.mean(
                best_class_scores
            )
        ),
        "confusion_matrix": (
            confusion.tolist()
        ),
    }

    return result


# ============================================================
# 8. 输出结果
# ============================================================

def print_result(
    stage: int,
    result: Dict,
) -> None:
    """打印当前阶段测试结果。"""
    print(
        "\n"
        +
        "=" * 72
    )

    print(
        f"D{stage} Granular Ball Test"
    )

    print(
        "=" * 72
    )

    print(
        "当前块类别:",
        result[
            "current_classes"
        ],
    )

    print(
        "累计已见类别:",
        result[
            "seen_classes"
        ],
    )

    print(
        "测试样本数量:",
        result[
            "num_test_samples"
        ],
    )

    print(
        "ACC:",
        f"{result['accuracy_percent']:.4f}%",
    )

    print(
        "Coverage Rate:",
        f"{result['coverage_rate_percent']:.4f}%",
    )

    print(
        "\nPer-class Accuracy:"
    )

    for class_name, class_acc in (
        result[
            "per_class_accuracy"
        ].items()
    ):
        print(
            f"  Class {class_name}: "
            f"{100.0 * class_acc:.4f}%"
        )

    print(
        "\nConfusion Matrix:"
    )

    print(
        np.asarray(
            result[
                "confusion_matrix"
            ]
        )
    )


# ============================================================
# 9. 保存 JSON 结果
# ============================================================

def save_result(
    result: Dict,
    result_path: str,
) -> None:
    """保存当前阶段评估结果。"""
    result_dir = os.path.dirname(
        result_path
    )

    if result_dir:
        os.makedirs(
            result_dir,
            exist_ok=True,
        )

    with open(
        result_path,
        "w",
        encoding="utf-8",
    ) as file:

        json.dump(
            result,
            file,
            ensure_ascii=False,
            indent=2,
        )

    print(
        "测试结果保存：",
        result_path,
    )


# ============================================================
# 10. 命令行参数
# ============================================================

def parse_args() -> argparse.Namespace:
    """
    默认直接适配：

        当前代码所在的项目根目录

    对 D1 可只运行：

        python analysis/evaluate_cifar10_stage.py --stage 1

    如果未来 D2/D3 文件名保持：
        resnet18_D2.pth
        GB_D2_radial_bic.npy

    则只需改：
        --stage 2
        --stage 3
    """
    parser = argparse.ArgumentParser(
        description=(
            "CIFAR-10 Task-Free 当前阶段粒球测试"
        )
    )

    parser.add_argument(
        "--stage",
        type=int,
        default=1,
        help=(
            "当前数据流阶段，"
            "1 表示 D1。"
        ),
    )

    parser.add_argument(
        "--project-root",
        type=str,
        default=(
            DEFAULT_PROJECT_ROOT
        ),
        help=(
            "项目根目录。"
        ),
    )

    parser.add_argument(
        "--checkpoint-path",
        type=str,
        default=None,
        help=(
            "可选：显式指定当前阶段 checkpoint。"
        ),
    )

    parser.add_argument(
        "--ball-path",
        type=str,
        default=None,
        help=(
            "可选：显式指定当前阶段粒球文件。"
        ),
    )

    parser.add_argument(
        "--batch-size",
        type=int,
        default=(
            DEFAULT_BATCH_SIZE
        ),
        help=(
            "测试集特征提取 batch size。"
        ),
    )

    parser.add_argument(
        "--classifier-batch-size",
        type=int,
        default=2048,
        help=(
            "粒球分类计算 batch size。"
        ),
    )

    parser.add_argument(
        "--num-blocks",
        type=int,
        default=(
            DEFAULT_NUM_BLOCKS
        ),
    )

    parser.add_argument(
        "--active-classes-per-block",
        type=int,
        default=(
            DEFAULT_ACTIVE_CLASSES_PER_BLOCK
        ),
    )

    parser.add_argument(
        "--seed",
        type=int,
        default=(
            DEFAULT_SEED
        ),
    )

    return parser.parse_args()


# ============================================================
# 11. 主程序
# ============================================================

def main() -> None:

    args = parse_args()

    stage = args.stage

    project_root = (
        args.project_root
    )

    data_root = os.path.join(
        project_root,
        "data",
    )

    # --------------------------------------------------------
    # 与 pretrain.py 当前保存方式一致。
    # --------------------------------------------------------
    if args.checkpoint_path:
        checkpoint_path = (
            args.checkpoint_path
        )
    else:
        checkpoint_path = os.path.join(
            project_root,
            "checkpoints",
            f"resnet18_D{stage}.pth",
        )

    # --------------------------------------------------------
    # 当前 D1 粒球文件保存位置， 当前工程目录中粒球结果保存在：
    # <项目根目录>/out/final_balls_dip_bic.npy
    # 如果运行时通过 --ball-path 显式指定路径，
    # 则优先使用命令行传入的路径；# 否则使用下面的默认路径。
    if args.ball_path:
        ball_path = args.ball_path
    else:
        ball_path = os.path.join(
            project_root,
            "out",
            "compare_both_balls.npy",#final_balls_dip_bic.
        )

    feature_output_path = os.path.join(
        project_root,
        "features",
        f"CIFAR10_test_feature_D{stage}.npy",
    )

    label_output_path = os.path.join(
        project_root,
        "features",
        "CIFAR10_test_label.npy",
    )

    result_output_path = os.path.join(
        project_root,
        "out",
        f"D{stage}_granular_ball_test.json",
    )

    print(
        "=" * 72
    )

    print(
        "CIFAR-10 Stage Evaluation"
    )

    print(
        "=" * 72
    )

    print(
        "Stage:",
        stage,
    )

    print(
        "Checkpoint:",
        checkpoint_path,
    )

    print(
        "Granular balls:",
        ball_path,
    )

    # --------------------------------------------------------
    # 1. 根据原数据流日程得到当前类和累计已见类。
    # --------------------------------------------------------
    current_classes, seen_classes = (
        get_seen_classes(
            stage=stage,
            num_blocks=(
                args.num_blocks
            ),
            active_classes_per_block=(
                args.active_classes_per_block
            ),
            seed=args.seed,
        )
    )

    print(
        "当前块类别:",
        current_classes.tolist(),
    )

    print(
        "累计已见类别:",
        seen_classes.tolist(),
    )

    # --------------------------------------------------------
    # 2. 加载当前阶段网络。
    # --------------------------------------------------------
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print(
        "Device:",
        device,
    )

    model = load_stage_model(
        checkpoint_path=(
            checkpoint_path
        ),
        device=device,
    )

    # --------------------------------------------------------
    # 3. 用当前网络重新提取官方 test set 特征。
    # --------------------------------------------------------
    features, labels = (
        extract_test_features(
            model=model,
            data_root=data_root,
            device=device,
            batch_size=(
                args.batch_size
            ),
        )
    )

    print(
        "Test feature shape:",
        features.shape,
    )

    print(
        "Test label shape:",
        labels.shape,
    )

    # --------------------------------------------------------
    # 4. 保存当前阶段的测试特征。
    # --------------------------------------------------------
    save_test_features(
        features=features,
        labels=labels,
        feature_path=(
            feature_output_path
        ),
        label_path=(
            label_output_path
        ),
    )



    # --------------------------------------------------------
    # 6. 粒球分类并计算 ACC。
    # --------------------------------------------------------
    result = evaluate_stage(
        features=features,
        labels=labels,
        ball_path=ball_path,
        current_classes=(
            current_classes
        ),
        seen_classes=(
            seen_classes
        ),
        classifier_batch_size=(
            args.classifier_batch_size
        ),
    )

    print_result(
        stage=stage,
        result=result,
    )



    # --------------------------------------------------------
    # 7. 保存当前阶段结果。
    # --------------------------------------------------------
    save_result(
        result=result,
        result_path=(
            result_output_path
        ),
    )


if __name__ == "__main__":
    main()
