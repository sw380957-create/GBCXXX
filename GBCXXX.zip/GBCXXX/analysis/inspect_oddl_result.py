"""Read-only model diagnostic on a stratified VALIDATION subset; no tuning."""
import json
from pathlib import Path
import numpy as np
import torch
from torch.utils.data import DataLoader
from continual.data import ImageDataset
from baselines.task_free_protocol import FixedTaskFreeProtocol
from baselines.task_free_oddl import ODDLS2


def main():
    root = Path(__file__).resolve().parents[1]
    output = root/'baselines/runs/oddl_s2_cifar10_t045_20261010_162537'
    settings = json.loads((output/'settings.json').read_text(encoding='utf-8'))
    summary = json.loads((output/'summary.json').read_text(encoding='utf-8'))
    state = torch.load(summary['checkpoint'], map_location='cpu', weights_only=False)
    torch.set_num_threads(4)
    protocol = FixedTaskFreeProtocol(settings['protocol_path'], root/'data', settings['common']['seed'])
    learner = ODDLS2(10, settings['image_size'], settings['common'], settings['oddl'], 'cpu')
    learner.restore(state['learner'], protocol.stream[:state['position']])
    learner.eval()
    experts = [*learner.frozen, learner.active]
    rng = np.random.default_rng(2026)
    selected = []
    for c in range(10):
        ids = protocol.validation_ids[protocol.labels[protocol.validation_ids] == c]
        selected.extend(rng.choice(ids, min(50, len(ids)), replace=False).tolist())
    selected = np.asarray(selected)
    labels = protocol.labels[selected]
    loader = DataLoader(ImageDataset(protocol.images[selected], labels), batch_size=64, num_workers=0)
    predicted, chosen = [], []
    with torch.no_grad():
        for x, _ in loader:
            costs = torch.stack([e.vae.nll(x, stochastic=False) for e in experts], 1)
            chosen.append(costs.argmin(1).numpy())
            predicted.append(torch.stack([e.classifier(x)[0].argmax(1) for e in experts], 1).numpy())
    predicted, chosen = np.concatenate(predicted), np.concatenate(chosen)
    correct = predicted == labels[:, None]
    routed = correct[np.arange(len(labels)), chosen]
    result = {'scope': 'stratified_validation_50_per_class_no_training_or_selection',
              'sample_count': len(labels), 'sample_ids': selected.tolist(),
              'routed_accuracy': float(routed.mean()),
              'oracle_any_expert_accuracy_diagnostic_only': float(correct.any(1).mean()),
              'expert_accuracies': correct.mean(0).tolist(),
              'route_counts': np.bincount(chosen, minlength=len(experts)).tolist(),
              'per_class': {}}
    for c in range(10):
        mask = labels == c
        result['per_class'][str(c)] = {
            'routed_accuracy': float(routed[mask].mean()),
            'expert_accuracies': correct[mask].mean(0).tolist(),
            'oracle_any_expert_accuracy_diagnostic_only': float(correct[mask].any(1).mean()),
            'route_counts': np.bincount(chosen[mask], minlength=len(experts)).tolist()}
    path = output/'validation_routing_diagnostic.json'
    with path.open('x', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2, allow_nan=False)
    print(json.dumps({k: v for k, v in result.items() if k != 'sample_ids'}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
