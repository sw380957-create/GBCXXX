# 粒球结构记忆的 Task-Free 持续学习

本项目实现基于粒球结构记忆的 Task-Free 持续学习模型。模型按固定数据流接收样本，在窗口训练后执行粒球结构维护，并保存代表图像用于后续回放和历史结构约束。

本仓库只包含模型实现、数据协议及运行所需工具，不包含 baseline、对比实验脚本或大规模实验输出。

## 方法概要

- **网络**：CIFAR ResNet-18。网络使用分类交叉熵进行训练。
- **数据流**：由 `protocols/<dataset>/protocol.json` 固定。训练样本顺序和验证划分由协议确定。
- **粒球特征空间**：使用单位化特征上的欧氏距离。
- **粒球维护**：网络完成当前训练窗口后执行结构维护，包括新样本关联、未覆盖样本建球、类内细化和同类冗余合并；异构分裂由配置开关控制，当前主方法配置关闭。
- **代表点与回放**：每球最多选择 5 个代表图像，按类别均衡循环抽取用于回放。总 Memory 上限由对应配置决定。
- **粒球保持损失**：`L_gb = L_core + L_radial`，由 `lambda_gb` 控制；结构和 overlap 损失在当前主方法配置中关闭。
- **最终分类器**：`max_unique_then_adaptive_mean`。分类使用粒球结构；辅助全连接分类头用于训练交叉熵。
- **测试集**：只用于报告指标，不用于训练、建球、Memory 选择或参数选择。

## 目录说明

- `continual/`：Task-Free 训练入口、训练器、配置、粒球生命周期、Memory、损失和评估。
- `continual/configs/`：主方法配置文件。
- `granular_ball/`：粒球生成、更新依赖及分类器实现。
- `models/`：ResNet-18 网络定义。
- `data/`：数据流协议生成、数据集索引读取和数据准备工具。
- `protocols/`：固定数据流协议；外部数据集还包含索引和准备信息。
- `analysis/`：评估代码依赖。

实验结果、模型 checkpoint、原始图片、虚拟环境和临时缓存不属于源码仓库内容。

## 环境

建议使用 Python 3.10 或 3.11，并根据本机 CUDA 环境安装对应版本的 PyTorch、TorchVision。其余 Python 依赖见 `requirements.txt`。

```powershell
python -m pip install -r requirements.txt
```

CIFAR 数据应提前放在 `--data-root` 指定目录中。运行入口使用 `download=False`，不会自动下载数据集。

## CIFAR-10 主方法

从项目根目录运行：

```powershell
python -B -u -m continual.task_free_runner `
  --config continual/configs/task_free_quality_unit_euclidean_redundancy_v1.json `
  --protocol protocols/cifar10/protocol.json `
  --data-root data `
  --output out/task_free/cifar10/final_run `
  --evaluate-test `
  --eval-every-windows 8 `
  --set representative_max_per_ball=5 `
  --set warmup_replay_capacity=200 `
  --set representative_memory_budget=200 `
  --set ce_replay_fill_budget=true `
  --set gb_replay_ball_subset=true
```

## CIFAR-100 主方法

从项目根目录运行：

```powershell
python -B -u -m continual.task_free_runner `
  --config continual/configs/task_free_cifar100_fixed5_budget2000_replay_lgb_v1.json `
  --protocol protocols/cifar100/protocol.json `
  --data-root data `
  --output out/task_free/cifar100/final_run `
  --evaluate-test `
  --eval-every-windows 8 `
  --set warmup_replay_capacity=2000
```

请确保 CIFAR-10 和 CIFAR-100 命令使用的配置、协议与正式实验记录一致。若正式实验命令包含其他 `--set` 覆盖项，应在复现实验时一并使用。

## 协议与复现

协议文件固定了样本划分和数据到达顺序。复现实验时应使用仓库中对应数据集的同一份协议，不要重新随机生成协议。外部图片数据集还需要匹配的 `index.json` 和原始图片目录；索引中的数据集摘要必须与协议一致。

程序输出写入 `out/` 下的新目录，包括逐窗口日志、`settings.json`、`summary.json`、最终测试结果和 checkpoint。`out/` 不应提交到源码仓库。
