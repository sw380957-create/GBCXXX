"""
============================================================
基于半径归一化粒球响应的分类决策_旧分类器
============================================================

分类规则：

1. 半径归一化距离

rho_ik =
||z_i - M_k||_2 / (r_k + eps)


2. 粒球响应

s_ik =
exp(-rho_ik^2)


3. 类别响应

S_c(z_i)
=
max_{k:c_k=c} s_ik


4. 最终分类

y_hat_i
=
argmax_c S_c(z_i)


说明：

- 粒球中心和半径共同描述局部数据分布区域；
- 半径归一化距离消除不同粒球尺度差异；
- 高斯响应函数用于描述样本与粒球之间的匹配程度；
- 同类别粒球采用最大响应策略，避免多个局部区域平均造成响应稀释；
- 测试特征必须由与粒球生成阶段一致的网络提取。

============================================================
"""


from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import numpy as np


NUMERICAL_EPS = np.finfo(np.float64).eps



def load_granular_balls(
    ball_path: str,
) -> List[Dict]:
    """
    加载粒球文件。

    每个粒球必须包含：

        center
        radius
        label
        num_samples

    """

    raw = np.load(
        ball_path,
        allow_pickle=True,
    )

    balls = list(
        raw.tolist()
    )

    if len(balls) == 0:
        raise ValueError(
            "粒球文件为空。"
        )


    required_keys = {
        "center",
        "radius",
        "label",
        "num_samples",
    }


    for i, ball in enumerate(balls):

        missing = (
            required_keys
            -
            set(ball.keys())
        )

        if missing:

            raise ValueError(
                f"第{i}个粒球缺少字段："
                f"{sorted(missing)}"
            )


    return balls




class GranularBallClassifier:
    """
    基于半径归一化粒球响应的分类器。

    分类过程：

    特征
      ↓
    半径归一化距离
      ↓
    高斯粒球响应
      ↓
    类别最大响应
      ↓
    分类结果

    """

    def __init__(
        self,
        balls: Sequence[Dict],
    ) -> None:


        if len(balls) == 0:

            raise ValueError(
                "balls不能为空"
            )


        # ------------------------------------------------
        # 粒球中心
        # shape:
        # (num_balls, feature_dim)
        # ------------------------------------------------

        self.centers = np.stack(
            [
                np.asarray(
                    ball["center"],
                    dtype=np.float64,
                )
                for ball in balls
            ],
            axis=0,
        )


        # ------------------------------------------------
        # 粒球半径
        # ------------------------------------------------

        self.radii = np.asarray(
            [
                float(ball["radius"])
                for ball in balls
            ],
            dtype=np.float64,
        )


        # ------------------------------------------------
        # 粒球类别
        # ------------------------------------------------

        self.ball_labels = np.asarray(
            [
                int(ball["label"])
                for ball in balls
            ],
            dtype=np.int64,
        )


        # ------------------------------------------------
        # 保存粒球样本数量
        #
        # 后续结构分析可能使用
        # 当前分类阶段不参与计算
        # ------------------------------------------------

        self.ball_sizes = np.asarray(
            [
                int(ball["num_samples"])
                for ball in balls
            ],
            dtype=np.float64,
        )


        if np.any(
            self.ball_sizes <= 0
        ):

            raise ValueError(
                "num_samples必须大于0"
            )


        # 防止半径为0

        self.safe_radii = np.maximum(
            self.radii,
            NUMERICAL_EPS,
        )


        self.classes = np.unique(
            self.ball_labels
        )


        self.feature_dim = (
            self.centers.shape[1]
        )


        # ------------------------------------------------
        # 保存类别对应粒球索引
        # ------------------------------------------------

        self.class_ball_indices = {}


        for c in self.classes:

            indices = np.where(
                self.ball_labels == c
            )[0]


            self.class_ball_indices[
                int(c)
            ] = indices




    @classmethod
    def from_file(
        cls,
        ball_path: str,
    ) -> "GranularBallClassifier":

        return cls(
            load_granular_balls(
                ball_path
            )
        )




    def _check_features(
        self,
        X: np.ndarray,
    ) -> np.ndarray:

        """
        检查输入特征。
        """

        X = np.asarray(
            X,
            dtype=np.float64,
        )


        if X.ndim == 1:

            X = X.reshape(
                1,
                -1,
            )


        if X.ndim != 2:

            raise ValueError(
                "输入特征必须为二维数组"
            )


        if (
            X.shape[1]
            !=
            self.feature_dim
        ):

            raise ValueError(
                "特征维度不匹配"
            )


        return X




    def class_scores(
        self,
        X: np.ndarray,
        batch_size: int = 2048,
    ) -> np.ndarray:

        """
        计算样本对于各类别的响应。

        返回：

        scores:

        shape=(N,num_classes)

        """

        X = self._check_features(
            X
        )


        n_samples = len(X)

        n_classes = len(
            self.classes
        )


        scores = np.empty(
            (
                n_samples,
                n_classes,
            ),
            dtype=np.float64,
        )



        for start in range(
            0,
            n_samples,
            batch_size,
        ):


            end = min(
                start + batch_size,
                n_samples,
            )


            xb = X[
                start:end
            ]



            # --------------------------------------------
            # 欧氏距离
            #
            # d_ik=||z_i-M_k||
            # --------------------------------------------

            diff = (
                xb[:, None, :]
                -
                self.centers[
                    None,
                    :,
                    :
                ]
            )


            distances = np.linalg.norm(
                diff,
                axis=2,
            )



            # --------------------------------------------
            # 半径归一化距离
            #
            # rho=d/(r+eps)
            # --------------------------------------------

            rho = (
                distances
                /
                self.safe_radii[
                    None,
                    :
                ]
            )



            # --------------------------------------------
            # 高斯粒球响应
            #
            # s=exp(-rho^2)
            # --------------------------------------------

            ball_responses = np.exp(
                -rho ** 2
            )



            # --------------------------------------------
            # 类别响应
            #
            # S_c=max(s_ik)
            # --------------------------------------------

            for class_pos, c in enumerate(
                self.classes
            ):

                indices = (
                    self.class_ball_indices[
                        int(c)
                    ]
                )


                scores[
                    start:end,
                    class_pos,
                ] = np.max(
                    ball_responses[
                        :,
                        indices,
                    ],
                    axis=1,
                )


        return scores




    def predict(
        self,
        X: np.ndarray,
        batch_size: int = 2048,
    ) -> np.ndarray:

        """
        输出预测类别：

        y_hat=argmax S_c
        """

        scores = self.class_scores(
            X,
            batch_size,
        )


        best_class_position = np.argmax(
            scores,
            axis=1,
        )


        return self.classes[
            best_class_position
        ]




    def predict_with_details(
        self,
        X: np.ndarray,
        batch_size: int = 2048,
    ) -> Tuple[
        np.ndarray,
        np.ndarray,
        np.ndarray,
    ]:

        """
        返回：

        predictions:
            分类结果

        best_class_scores:
            最大类别响应

        covered:
            是否存在预测类别粒球覆盖样本

        """

        X = self._check_features(
            X
        )


        scores = self.class_scores(
            X,
            batch_size,
        )


        best_class_position = np.argmax(
            scores,
            axis=1,
        )


        predictions = (
            self.classes[
                best_class_position
            ]
        )


        best_class_scores = (
            scores[
                np.arange(
                    len(scores)
                ),
                best_class_position,
            ]
        )



        covered = np.zeros(
            len(X),
            dtype=bool,
        )



        # --------------------------------------------
        # 判断预测类别是否覆盖样本
        #
        # rho<=1
        # --------------------------------------------

        for start in range(
            0,
            len(X),
            batch_size,
        ):


            end = min(
                start + batch_size,
                len(X),
            )


            xb = X[
                start:end
            ]


            diff = (
                xb[:, None, :]
                -
                self.centers[
                    None,
                    :,
                    :
                ]
            )


            distances = np.linalg.norm(
                diff,
                axis=2,
            )


            rho = (
                distances
                /
                self.safe_radii[
                    None,
                    :
                ]
            )


            pred_batch = predictions[
                start:end
            ]


            for local_i, pred_c in enumerate(
                pred_batch
            ):


                indices = (
                    self.class_ball_indices[
                        int(pred_c)
                    ]
                )


                covered[
                    start + local_i
                ] = bool(
                    np.any(
                        rho[
                            local_i,
                            indices,
                        ]
                        <=1.0
                    )
                )


        return (
            predictions,
            best_class_scores,
            covered,
        )