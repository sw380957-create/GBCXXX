"""
final_granulation_final_switch.py

最终版粒球生成程序

流程：
1. D1 特征空间按类别初始化粒球；
2. 阶段 I：基于真实样本共同覆盖的异构冲突消解
   2.1 几何重叠预筛选：
       ||c_i-c_j|| < r_i^max + r_j^max
   2.2 对通过筛选的异类粒球对检测是否存在真实样本共同覆盖；
   2.3 对冲突粒球对采用 compare-both 双向候选分裂；
   2.4 按 (C, O) 字典序选择能够改善全局冲突的分裂；
3. 阶段 II（可选）：基于类内/类间离散度的粒球结构递归细化
   3.1 在平均半径与最大半径之间选择外围候选点；
   3.2 构造候选二分；
   3.3 计算
           W = sum ||x-c_k||^2
           B = (n1*n2/n) * ||c1-c2||^2
   3.4 当 B > W 时接受分裂，并继续对子粒球进行结构细化；
4. 保存最终粒球，供后续 classifier.py 使用。

输入：
<项目根目录>/features/D1_feature.npy
<项目根目录>/features/D1_label.npy

输出：
<项目根目录>/out/compare_both_balls.npy

说明：
- directional 方法已完全删除；
- 当前只有 compare-both 一种异构冲突处理机制；
- 保留 compare_both_balls.npy 文件名，以兼容已有后续代码；
- 第二阶段不再以跨类别冲突作为分裂判据；
- 通过 ENABLE_INTRA_REFINEMENT 控制是否执行类内结构细化。
"""

import os
from pathlib import Path
from dataclasses import dataclass
from itertools import combinations
import numpy as np


# ============================================================
# 0. 路径与参数
# ============================================================

ROOT = str(Path(__file__).resolve().parents[1])

FEATURE_PATH = os.path.join(
    ROOT, "features", "D1_feature.npy"
)

LABEL_PATH = os.path.join(
    ROOT, "features", "D1_label.npy"
)

OUT_DIR = os.path.join(
    ROOT, "out"
)

# 保留原输出名，避免影响后续 classifier.py
OUTPUT_FILE = "compare_both_balls.npy"

# 每个子粒球至少包含的样本数
MIN_CHILD_SIZE = 2

# 异构冲突阶段最多接受的分裂次数
MAX_HETERO_SPLIT = 100

# 是否运行阶段 II：类内结构递归细化
# True  -> 运行 B/W 类内结构分裂
# False -> 异构冲突处理结束后直接保存粒球
ENABLE_INTRA_REFINEMENT = True

# 浮点数比较容差
EPS = 0


# ============================================================
# 1. 粒球定义
# ============================================================

@dataclass
class Ball:
    id: int
    label: int
    indices: np.ndarray
    depth: int = 0

    def update(self, X):
        """
        `self` 代表这个类实例本身，当你创建一个 `Ball` 对象后，
        `self` 就是这个对象在类内部的代名词，用来访问这个实例自己的属性和方法。
        根据当前成员样本更新：
        center      粒球中心
        radius      最大半径
        mean_radius 平均半径
        """
        if len(self.indices) == 0:
            raise ValueError("粒球不能为空。")

        points = X[self.indices]

        self.center = np.mean(points, axis=0)

        distances = np.linalg.norm(
            points - self.center,
            axis=1
        )

        self.radius = float(np.max(distances))
        self.mean_radius = float(np.mean(distances))


# ============================================================
# 2. 按类别初始化粒球
# ============================================================

def initialize_balls(X, y):
    """
    D1 中每个类别首先形成一个初始粒球。
    """
    balls = []
    for ball_id, label in enumerate(np.unique(y)):
        indices = np.where(y == label)[0]
        ball = Ball(
            id=ball_id,
            label=int(label),
            indices=indices,
            depth=0
        )
        ball.update(X)
        balls.append(ball)

    return balls


# ============================================================
# 3. 异构冲突检测
# ============================================================

def geometry_overlap(ball_a, ball_b):
    """
    几何重叠快速预筛选。
    本文将两个粒球存在严格几何交叠定义为：
        ||c_i-c_j|| < r_i + r_j
    仅当异标签粒球满足该条件时，
    才进一步检查交叠覆盖区域中是否存在真实样本。
    注意：这里使用严格小于号，边界相切不作为几何重叠处理。
    """
    center_distance = np.linalg.norm(
        ball_a.center - ball_b.center
    )

    return (
        center_distance
        < ball_a.radius + ball_b.radius
    )


def cover_samples(source_ball, target_ball, X):
    """
    检查 source_ball 自己的成员样本中，
    哪些样本同时被 target_ball 的几何范围覆盖。

    source_ball.indices:
        样本真正所属的粒球成员。

    target_ball:
        已经过几何重叠预筛选的异类候选粒球。

    返回：
        source_ball 成员中同时进入 target_ball 覆盖范围的样本索引。
    """

    rows = np.asarray(
        source_ball.indices,
        dtype=np.int64
    )

    if len(rows) == 0:
        return np.empty(0, dtype=np.int64)

    points = np.asarray(
        X[rows],
        dtype=np.float64
    )

    distances = np.linalg.norm(
        points - target_ball.center,
        axis=1
    )

    return rows[
        distances <= target_ball.radius + EPS
    ]


def conflict_pair_key(ball_a, ball_b):
    """
    为两个粒球生成与顺序无关的唯一 pair key。
    例如： (G1, G2)和：(G2, G1)
    应当被认为是同一条冲突边。
    统一转成字符串以后再排序，可以兼容：int 类型 idstr 类型 id
    """
    a = str(ball_a.id)
    b = str(ball_b.id)
    return (a, b) if a <= b else (b, a)




def conflict_info(X, balls):
    """
    计算当前粒球集合中的真实样本异构冲突。
    ================================================================
    总体思想
    ================================================================
    整个检测分成两层：第一层：粒球级几何预筛选
    ---------------------------------------------------------------
    对所有异标签粒球对 (GB_i, GB_j)，首先判断：
        ||c_i - c_j|| < r_i + r_j
    只有满足几何重叠的异类粒球对，才进入后续真实样本检测。因此，后面不需要让每个粒球检查所有其它粒球。
    第二层：真实成员样本冲突检测
    ---------------------------------------------------------------
    对一个候选粒球 GB_i：只扫描真正属于 GB_i 的成员样本 ball_i.indices
    并且只检查：与 GB_i 已经发生几何重叠的异类邻居粒球。
    对 x ∈ GB_i，如果：||x - c_j|| <= r_j
    则说明： x 虽然属于 GB_i，但同时进入了 GB_j 的几何覆盖区域。
    ================================================================
    多粒球冲突
    ================================================================
    一个样本可能同时被：GB_1,GB_2,GB_3覆盖。
    因此我们不只是简单记录 pair，
    而是首先记录每个冲突样本对应的完整覆盖粒球集合：G(x) = {GB_1, GB_2, GB_3, ...}
    再根据其中不同类别数量计算 C 和 O。
    ================================================================
    C：冲突样本比例
    如果样本 x 同时被至少两个不同类别粒球覆盖，
    则它是一个异构冲突样本。 C = N_conflict / N
    ================================================================
    O：冲突强度
    对每个冲突样本：O_x = |Y(x)| - 1
    Y(x) 是覆盖该样本的不同类别集合。
    最终：O = sum_x O_x / N
    ================================================================
    pair_conflict_counts
    除全局 C / O 外，同时统计每个异类粒球 pair
    共同参与了多少真实样本冲突：
        w_ij = |S_ij|
    后续 resolve_conflicts 不再随机选择 pair，
    而是优先处理 w_ij 最大的冲突 pair。
    ================================================================
    返回
    C: 全局冲突样本比例。
    O:全局异构覆盖强度。
    conflict_pairs:真正存在真实样本冲突的异标签粒球对。
    pair_conflict_counts:
        字典：{(ball_i_id, ball_j_id): 冲突样本数, ...
            }
        即 w_ij。
    """
    n_samples = len(X)
    if n_samples == 0:
        raise ValueError("输入样本为空。")
    # ==============================================================
    # Step 1：异标签粒球几何预筛选
    # ==============================================================
    geometric_pairs = []
    # 邻接表：# neighbors[ball_id] = 所有与该球发生异类几何重叠的候选粒球
    # 后面一个粒球只检查这些邻居，不需要检查全部 G 个粒球。
    neighbors = {ball.id: []for ball in balls}
    # 保存 key -> 实际粒球对象 pair
    geometric_pair_map = {}
    for i in range(len(balls)):
        ball_i = balls[i]
        for j in range(i + 1, len(balls)):
            ball_j = balls[j]
            # 同标签粒球不属于“异构冲突”
            if ball_i.label == ball_j.label:
                continue
            # ------------------------------------------------------
            # 第一级： 必须先存在严格几何重叠 ||ci-cj|| < ri+rj
            if not geometry_overlap(ball_i, ball_j):
                continue
            geometric_pairs.append((ball_i, ball_j))

            neighbors[ball_i.id].append(ball_j)

            neighbors[ball_j.id].append(ball_i)
            key = conflict_pair_key(ball_i,ball_j)

            geometric_pair_map[key] = (ball_i,ball_j)
    # --------------------------------------------------------------
    # 一个异类几何重叠pair都没有，后面肯定不存在真实异构冲突。
    # --------------------------------------------------------------
    if not geometric_pairs:
        return 0.0, 0.0, [], {}
    # ==============================================================
    # Step 2：真实成员样本冲突检测
    # ==============================================================
    # sample_cover_balls[idx]:保存样本 idx 当前被哪些候选粒球共同覆盖。
    # 注意：idx 本身真实只属于一个粒球，但是几何上可能同时进入多个其它粒球。
    sample_cover_balls = {}
    for ball in balls:
        candidate_neighbors = neighbors.get(ball.id,[])
        # ----------------------------------------------------------
        # 如果这个粒球根本没有异类几何重叠邻居，它的成员不可能产生当前定义下的异构冲突。
        if not candidate_neighbors:
            continue
        # ----------------------------------------------------------
        # 只遍历 ball 自己真正拥有的成员点。
        own_rows = np.asarray(ball.indices,dtype=np.int64)
        if len(own_rows) == 0:
            continue

        for other in candidate_neighbors:
            # ------------------------------------------------------
            # 找出：属于 ball，同时又进入 other 覆盖区域的真实样本。
            shared_rows =  cover_samples(ball,other,X)

            if len(shared_rows) == 0:
                continue

            for idx in shared_rows:
                idx = int(idx)
                if idx not in sample_cover_balls:
                    sample_cover_balls[idx] = set()
                # 样本真正所属粒球
                sample_cover_balls[idx].add(ball.id)
                # 同时覆盖该样本的异类候选球
                sample_cover_balls[idx].add(other.id)

    # 如果几何有重叠，但没有任何真实成员样本进入异类区域，
    # 则不认为存在真实异构冲突。
    if not sample_cover_balls:
        return 0.0, 0.0, [], {}
    # ==============================================================
    # Step 3：准备粒球ID映射
    ball_by_id = {ball.id: ball for ball in balls}
    # =============================================================
    # Step 4：计算全局 C / O；同时计算每个pair的真实冲突样本数 w_ij
    conflict_sample_num = 0#冲突样本数
    overlap_num = 0
    pair_conflict_counts = {key: 0
                            for key in geometric_pair_map}
    for idx, covered_ids in sample_cover_balls.items():

        covered_balls = [ball_by_id[ball_id]
            for ball_id in covered_ids]

        covered_labels = {ball.label
            for ball in covered_balls}
        # ----------------------------------------------------------
        # 至少被两个不同类别覆盖，才是真正的异构冲突样本。
        if len(covered_labels) <= 1:
            continue
        conflict_sample_num += 1
        # ----------------------------------------------------------
        # 一个样本被 K 个不同类别覆盖： O贡献 = K - 1
        # ----------------------------------------------------------
        overlap_num += (len(covered_labels) - 1)
        # ----------------------------------------------------------
        # 统计这个样本对哪些异类pair产生贡献。 # 比如样本同时被： G1(A), G2(B), G3(C)
        #则 w12 += 1； w13 += 1； w23 += 1 ； 这样才能正确描述三球甚至多球共同冲突。
        # ----------------------------------------------------------
        for ball_a, ball_b in combinations(covered_balls,2):
            # 同类别不算异构pair
            if ball_a.label == ball_b.label:
                continue
            key = conflict_pair_key(ball_a,ball_b)
            # 理论上如果两球共同覆盖同一样本，它们应该通过几何预筛选。
            # 这里仍然做一次保护，保持“先几何、后样本”的定义。
            if key not in pair_conflict_counts:
                continue
            pair_conflict_counts[key] += 1
    # ==============================================================
    # Step 5：删除没有真实样本支持的几何pair
    # ==============================================================
    pair_conflict_counts = {
        key: count
        for key, count in pair_conflict_counts.items()
        if count > 0
    }
    conflict_pairs = [
        geometric_pair_map[key]
        for key in pair_conflict_counts
    ]
    # --------------------------------------------------------------
    # 为了后面调试/输出更加稳定，按真实冲突样本数从大到小排列。相同数量时按ID排序，避免遍历顺序造成随机性。
    # --------------------------------------------------------------
    conflict_pairs.sort(
        key=lambda pair: (
            -pair_conflict_counts[
                conflict_pair_key(
                    pair[0],
                    pair[1]
                )
            ],
            str(pair[0].id),
            str(pair[1].id)
        )
    )
    # ==============================================================
    # Step 6：计算全局指标
    # ==============================================================
    C = (conflict_sample_num/n_samples)
    O = (overlap_num/n_samples)

    return (
        float(C),
        float(O),
        conflict_pairs,
        pair_conflict_counts
    )


# ============================================================
# 4. 通用候选二分
# ============================================================

def split_ball(ball, X, new_id):#new_id，int，整型
    """
    为单个粒球构造候选二分。
    第一个参考点 a：
        粒球内距离中心最远的样本。
    外围候选区域：
        mean_radius < ||x-c|| <= max_radius
    第二个候选点 b：
        在外围候选区域中选择距离 a 最远的样本。
    若：
        ||a-b|| > mean_radius
    则使用 (a, b) 作为两个参考点；
    否则使用 (a, center)。
    最后依据最近参考点原则进行二分。
    """
    # 若当前粒球样本总数不足以产生两个合法子球，直接停止
    if len(ball.indices) < 2 * MIN_CHILD_SIZE:
        return None
    points = X[ball.indices]
    # 样本到当前粒球中心的距离
    distances_to_center = np.linalg.norm(
        points - ball.center,
        axis=1
    )
    # a：距离粒球中心最远的真实样本及其索引
    idx_a = np.argmax(distances_to_center)
    a = points[idx_a]

    # 外围候选区域：mean_radius < d(x,c) <= max_radius
    edge_mask = (
        (distances_to_center > ball.mean_radius)
        &
        (distances_to_center <= ball.radius + EPS)
    )
    # 在外围区域剔除a本身
    edge_mask_without_a = edge_mask.copy()
    edge_mask_without_a[idx_a] = False
    edge_points_without_a = points[edge_mask_without_a]

    if len(edge_points_without_a) > 0:
        # 外围区域除a外还有其他样本，寻找离a最远的候选b
        distances_to_a = np.linalg.norm(
            edge_points_without_a - a,
            axis=1
        )
        candidate_b = edge_points_without_a[np.argmax(distances_to_a)]
        # 若两个外围方向具有足够分离程度，则采用 (a,b)
        if np.linalg.norm(candidate_b - a) > ball.mean_radius:
            q2 = candidate_b
        else:
            q2 = ball.center
    else:
        # 外围区域只有a，无其他候选点，退化为(a, center)划分
        q2 = ball.center

    q1 = a

    # 按最近参考点划分
    distances_to_q1 = np.linalg.norm(
        points - q1,
        axis=1
    )
    distances_to_q2 = np.linalg.norm(
        points - q2,
        axis=1
    )
    mask = (
        distances_to_q1
        <= distances_to_q2
    )
    n1 = int(np.sum(mask))
    n2 = int(np.sum(~mask))

    # 最小子粒球样本数约束
    if (
        n1 < MIN_CHILD_SIZE
        or n2 < MIN_CHILD_SIZE
    ):
        return None

    child_1 = Ball(
        id=new_id,
        label=ball.label,
        indices=ball.indices[mask],
        depth=ball.depth + 1
    )
    child_2 = Ball(
        id=new_id + 1,
        label=ball.label,
        indices=ball.indices[~mask],
        depth=ball.depth + 1
    )
    child_1.update(X)
    child_2.update(X)
    return child_1, child_2



# ============================================================
# 5. 阶段 I：Compare-Both 异构冲突消解
# ============================================================

def compare_both(balls, X, new_id):
    """
    对当前真实异构冲突粒球执行 compare-both 候选分裂。
    ============================================================
    当前机制
    ============================================================
    1. 调用 conflict_info() 得到：C0,O0,conflict_pairs,pair_conflict_counts
    2. 对每个真实冲突粒球对定义：
           w_ij = |S_ij|
       即两个粒球共同造成的真实异构冲突样本数量。
    3. 按 w_ij 从大到小确定冲突处理优先级。
    4. 对当前冲突 pair (GB_i, GB_j)：
           候选1：只分裂 GB_i
           候选2：只分裂 GB_j
    5. 每个候选分裂后重新计算整个粒球系统的：
           C_new
           O_new
    6. 按字典序比较：
           首先最小化 C；
           C 相同时最小化 O。
    7. 只有候选结构相对于当前结构真正改善 (C,O)，
       才接受该分裂。
    8. 如果当前最严重 pair 无法改善，
       则继续尝试下一严重 pair。
    ============================================================
    返回
    ============================================================
    如果找到可以接受的分裂：
        (被分裂父球,两个子球,新C,新O)
    如果所有冲突 pair 都无法改善：
        return None
    """
    # --------------------------------------------------------
    # 当前全局异构冲突状态
    # --------------------------------------------------------
    (C0, O0, conflict_pairs, pair_conflict_counts) = conflict_info(X, balls)

    # 已经没有真实异构冲突
    if not conflict_pairs:
        return None
    # --------------------------------------------------------
    # 按真实冲突样本数量 w_ij 从大到小排序
    # conflict_info() 本身已经排序，
    # 这里再次显式排序，使 compare_both 独立且逻辑清晰。
    # --------------------------------------------------------
    ordered_pairs = sorted(
        conflict_pairs,
        key=lambda pair: (
            -pair_conflict_counts[conflict_pair_key(pair[0], pair[1])],
            str(pair[0].id),
            str(pair[1].id)
        )
    )
    # --------------------------------------------------------
    # 从当前最严重的异构冲突 pair 开始尝试
    # --------------------------------------------------------
    for ball_a, ball_b in ordered_pairs:
        candidates = []
        # ----------------------------------------------------
        # compare-both：分别尝试拆 ball_a 和 ball_b
        for target in (ball_a,ball_b):
            children = split_ball( target, X, new_id)

            # 该粒球无法产生合法二分
            if children is None:
                continue
            # ------------------------------------------------
            # 构造候选结构：
            # 当前balls
            # - 被分裂父球
            # + 两个候选子球
            # ------------------------------------------------
            candidate_balls = [
                ball
                for ball in balls
                if ball.id != target.id
            ]
            candidate_balls.extend(
                children
            )

            # ------------------------------------------------
            # 分裂一个球可能改变其它粒球之间的冲突，
            # 因此这里重新计算整个系统的 C/O，
            # 不能只看当前这一对。
            # ------------------------------------------------
            (C_new, O_new, _, _) = conflict_info(X, candidate_balls)
            candidates.append((C_new, O_new, target, children)
            )

        # 当前pair两边都无法分裂
        if not candidates:
            continue
        # ----------------------------------------------------
        # 选择两种候选分裂中全局效果更好的一个。
        # Python tuple排序天然实现：
        # 先比较C
        # 再比较O
        # ----------------------------------------------------
        candidates.sort(
            key=lambda item: (
                item[0],
                item[1]
            )
        )

        (
            best_C,
            best_O,
            best_target,
            best_children
        ) = candidates[0]

        # ----------------------------------------------------
        # 只有真正改善全局冲突才接受：
        #
        # 1. C下降；
        # 或
        # 2. C基本不变但O下降。
        # ----------------------------------------------------
        improved = (
            best_C < C0 - EPS
            or
            (
                abs(best_C - C0) <= EPS
                and
                best_O < O0 - EPS
            )
        )

        if improved:
            return (
                best_target,
                best_children,
                best_C,
                best_O
            )
        # ----------------------------------------------------
        # 当前最严重pair不能改善，
        # 不立即停止。
        #
        # 继续检查下一严重pair。
        # ----------------------------------------------------
    # 所有真实冲突pair都无法改善
    return None




def resolve_heterogeneous_conflicts(balls,X,next_id):
    """
    迭代执行异构冲突消解。
    ============================================================
    每一轮
    ============================================================
    1. 根据当前粒球集合重新计算全部异构冲突；
    2. 根据真实冲突样本数量：
           w_ij = |S_ij|
       确定冲突 pair 优先级；
    3. compare-both 分别尝试分裂 pair 两端；
    4. 只有能够改善全局 (C,O) 的分裂才接受；
    5. 一旦接受一次分裂：
           原来的冲突关系立即失效，
           下一轮重新检测当前整个粒球结构。
    因此不会：
        一次生成所有pair
        ->
        按旧pair列表连续分裂
    从而降低由于旧冲突关系造成的过度分裂风险。
    ============================================================
    停止条件
    ============================================================
    1. 当前没有真实异构冲突；
    2. 当前所有冲突pair均无法改善(C,O)；
    3. 达到 MAX_HETERO_SPLIT。
    """
    balls = list(balls)
    accepted_splits = 0

    while accepted_splits < MAX_HETERO_SPLIT:
        # ----------------------------------------------------
        # compare_both 内部会基于“当前balls”
        # 重新计算： C/O
        # conflict_pairs
        # pair_conflict_counts
        # 因此每一轮使用的都是最新冲突状态。
        # ----------------------------------------------------
        result = compare_both(balls, X, next_id)

        # 当前已经没有可以改善(C,O)的异构分裂
        if result is None:
            break

        (
            old_ball,
            children,
            _,
            _
        ) = result

        # ----------------------------------------------------
        # 正式接受本轮split：
        # 删除父球 + 加入两个子球
        # ----------------------------------------------------
        balls = [
            ball
            for ball in balls
            if ball.id != old_ball.id
        ]
        balls.extend(
            children
        )

        # 本次split正式占用两个新ID
        next_id += 2
        accepted_splits += 1

        # ----------------------------------------------------
        # 注意：
        # 不继续使用本轮旧的 conflict_pairs。
        # while下一轮会重新调用 compare_both，
        # 再次重新计算完整当前冲突状态。
        # ----------------------------------------------------

    # --------------------------------------------------------
    # 最后重新检测最终粒球结构
    # --------------------------------------------------------
    (
        C_final,
        O_final,
        pairs_final,
        _
    ) = conflict_info(
        X,
        balls
    )

    reached_limit = (
        accepted_splits
        >= MAX_HETERO_SPLIT
    )

    return (
        balls,
        next_id,
        accepted_splits,
        C_final,
        O_final,
        len(pairs_final),
        reached_limit
    )


# ============================================================
# 6. 阶段 II：类内/类间离散度结构细化
# ============================================================

def structure_scatter(children, X):
    """
    计算候选二分后的 W 与 B。
    W： W = sum_{x in GB1} ||x-c1||^2+ sum_{x in GB2} ||x-c2||^2
    B：B = (n1*n2/n) * ||c1-c2||^2
    """
    child_1, child_2 = children
    points_1 = X[child_1.indices]
    points_2 = X[child_2.indices]

    W1 = np.sum((points_1 - child_1.center) ** 2)
    W2 = np.sum((points_2 - child_2.center) ** 2)

    W = float(W1 + W2)

    n1 = len(child_1.indices)
    n2 = len(child_2.indices)
    n = n1 + n2

    center_difference = (child_1.center-child_2.center)
    center_distance_squared = float(
        np.dot(center_difference, center_difference)
    )
    B = float((n1 * n2 / n)*center_distance_squared)
    return W, B


def refine_intra_ball_structure(
    balls,
    X,
    next_id
):
    """
    对阶段 I 输出的每一个粒球独立进行结构细化。

    判据：
        B > W  ：接受候选分裂，并继续处理两个子粒球；
        B <= W ：拒绝分裂，当前粒球成为最终粒球。

    这里使用显式栈实现与递归完全等价的过程，
    避免数据量较大时出现 Python 递归深度限制。
    """
    final_balls = []

    # 逆序入栈，使处理顺序尽量保持与原列表一致
    stack = list(reversed(balls))

    accepted_splits = 0

    while stack:
        ball = stack.pop()

        children = split_ball(
            ball,
            X,
            next_id
        )

        if children is None:
            final_balls.append(ball)
            continue

        W, B = structure_scatter(
            children,
            X
        )

        # 最终结构分裂判据
        if B > W:
            child_1, child_2 = children

            # 只有真正接受该分裂后才占用两个新 ID
            next_id += 2
            accepted_splits += 1

            # 继续对子粒球进行相同结构判断
            stack.append(child_2)
            stack.append(child_1)

        else:
            final_balls.append(ball)

    return (
        final_balls,
        next_id,
        accepted_splits
    )


# ============================================================
# 7. 完整粒球生成流程
# ============================================================

def run_granulation(X, y):
    """
    完整流程：
        类别初始化
            ->
        阶段 I：真实样本共同覆盖支持的异构冲突消解
            ->
        [可选] 阶段 II：B/W 类内结构递归细化
            ->
        最终粒球集合

    ENABLE_INTRA_REFINEMENT：
        True  -> 执行阶段 II；
        False -> 阶段 I 结束后直接返回并保存粒球。
    """
    # -------------------------
    # Stage 0：类别初始化
    # -------------------------
    balls = initialize_balls(
        X,
        y
    )

    next_id = len(balls)

    # -------------------------
    # Stage I：异构冲突消解
    # -------------------------
    (
        balls,
        next_id,
        hetero_splits,
        C_hetero,
        O_hetero,
        hetero_pair_num,
        reached_limit
    ) = resolve_heterogeneous_conflicts(
        balls,
        X,
        next_id
    )

    hetero_ball_num = len(balls)

    # -------------------------
    # Stage II：类内结构细化（可选）
    # -------------------------
    structure_splits = 0

    if ENABLE_INTRA_REFINEMENT:
        (
            balls,
            next_id,
            structure_splits
        ) = refine_intra_ball_structure(
            balls,
            X,
            next_id
        )

    stats = {
        "hetero_splits": hetero_splits,
        "hetero_ball_num": hetero_ball_num,
        "hetero_C": C_hetero,
        "hetero_O": O_hetero,
        "hetero_conflict_pairs": hetero_pair_num,
        "hetero_reached_limit": reached_limit,

        "intra_refinement_enabled": ENABLE_INTRA_REFINEMENT,
        "structure_splits": structure_splits,
        "final_ball_num": len(balls)
    }

    return balls, stats


# ============================================================
# 8. 最终结果检查与保存
# ============================================================

def validate_partition(balls, n_samples):
    """
    检查最终粒球是否仍然构成原始样本的完整划分：
    1. 不丢失样本；
    2. 不重复分配样本。
    """
    if not balls:
        raise ValueError("最终粒球集合为空。")

    all_indices = np.concatenate(
        [
            ball.indices
            for ball in balls
        ]
    )

    if len(all_indices) != n_samples:
        raise RuntimeError(
            "粒球划分后的样本总数与原始样本数不一致。"
        )

    unique_indices, counts = np.unique(
        all_indices,
        return_counts=True
    )

    if len(unique_indices) != n_samples:
        raise RuntimeError(
            "粒球划分存在样本缺失。"
        )

    if np.any(counts != 1):
        raise RuntimeError(
            "粒球划分存在重复样本。"
        )

    if (
        unique_indices[0] != 0
        or unique_indices[-1] != n_samples - 1
    ):
        raise RuntimeError(
            "最终样本索引范围异常。"
        )


def save_balls(balls):
    """
    保存格式保持与原程序一致，
    以兼容后续 classifier.py。
    """
    os.makedirs(
        OUT_DIR,
        exist_ok=True
    )

    data = []

    for ball in balls:
        data.append(
            {
                "center": ball.center,
                "radius": ball.radius,
                "mean_radius": ball.mean_radius,
                "label": ball.label,
                "num_samples": len(ball.indices),
                "sample_indices": ball.indices,
                "depth": ball.depth
            }
        )

    output_path = os.path.join(
        OUT_DIR,
        OUTPUT_FILE
    )

    np.save(
        output_path,
        np.array(
            data,
            dtype=object
        )
    )

    return output_path


# ============================================================
# 9. 主程序
# ============================================================

def main():
    X = np.load(
        FEATURE_PATH,
        allow_pickle=False
    )

    y = np.load(
        LABEL_PATH,
        allow_pickle=False
    )

    y = np.asarray(y).reshape(-1)

    # 输入检查
    if X.ndim != 2:
        raise ValueError(
            f"特征 X 必须为二维数组，当前 shape={X.shape}"
        )

    if len(X) != len(y):
        raise ValueError(
            "特征数与标签数不一致："
            f"len(X)={len(X)}, len(y)={len(y)}"
        )

    if len(X) == 0:
        raise ValueError("输入数据为空。")

    # 执行粒球生成
    balls, stats = run_granulation(
        X,
        y
    )

    # 检查最终成员划分：
    # 每个真实样本只能属于一个粒球，不能丢失或重复。
    validate_partition(
        balls,
        len(X)
    )

    # 控制台仅保留核心阶段信息
    print(
        "异构冲突处理后粒球数量:",
        stats["hetero_ball_num"]
    )

    if stats["intra_refinement_enabled"]:
        print(
            "类内结构细化后粒球数量:",
            stats["final_ball_num"]
        )
    else:
        print(
            "类内结构细化已关闭，最终粒球数量:",
            stats["final_ball_num"]
        )

    if stats["hetero_reached_limit"]:
        print(
            "警告：异构分裂达到最大次数",
            MAX_HETERO_SPLIT
        )

    # 保存最终粒球
    save_balls(
        balls
    )


if __name__ == "__main__":
    main()
