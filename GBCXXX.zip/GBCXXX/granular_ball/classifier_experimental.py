"""核心分类决策
实验型粒球分类器
模式说明：
原始规则：最大半径 + 同类粒球最大响应值
平均半径 + 在每一类全部粒球上计算归一化距离的平均值
平均半径 + 稳定核心判定 + 基于边界距离的自适应局部候选样本筛选
在最大半径覆盖区内仅存在单一类别标签时，直接判定类别；
异类重叠区域以及未被覆盖的样本点，则采用平均半径自适应响应机制。
"""

from __future__ import annotations

from typing import Dict, List, Sequence, Tuple

import numpy as np


DEFAULT_EPS = 1e-8


def load_granular_balls(ball_path: str,) -> List[Dict]:
    raw = np.load(ball_path,allow_pickle=True,)
    balls = list(raw.tolist())
    if len(balls) == 0:
        raise ValueError("粒球文件为空。")

    required_keys = {
        "center",
        "radius",
        "label",
        "num_samples",
    }

    for i, ball in enumerate(balls):
        missing = required_keys - set(ball.keys())

        if missing:
            raise ValueError(
                f"第{i}个粒球缺少字段："
                f"{sorted(missing)}")
    return balls

#实验版粒球分类器主类
class ExperimentalGranularBallClassifier:
#构造函数：加载并预处理所有粒球
    def __init__(
        self,
        balls: Sequence[Dict],#粒球列表，每个元素是字典，存储单个粒球信息
        decision_mode: str = "original_max",#4 种决策模式二选一
        adaptive_aggregate: str = "sum",#自适应边界模式下，同类候选粒球响应的聚合方式，
        epsilon: float = DEFAULT_EPS,#极小值，防止除 0，数值稳定保护
    ) -> None:

        if len(balls) == 0:
            raise ValueError("balls不能为空")

        self.decision_mode = decision_mode
        self.adaptive_aggregate = adaptive_aggregate
        self.epsilon = float(epsilon)

        valid_modes = {
            "original_max",
            "mean_all_distance",
            "adaptive_boundary",
            "max_unique_then_adaptive_mean",
        }

        if decision_mode not in valid_modes:
            raise ValueError(
                f"unknown decision_mode: {decision_mode}")

        if adaptive_aggregate not in {"sum","mean",}:
            raise ValueError("adaptive_aggregate must be "
                "'sum' or 'mean'")
        # -------------------------------------------------
        # Centers所有粒球中心坐标，shape = [球数量,特征维度]
        # --------------------------------------------------
        self.centers = np.stack(
            [np.asarray(ball["center"],dtype=np.float64,)
                for ball in balls],axis=0,)
        # --------------------------------------------------
        # Maximum radius每个粒球的最大半径 max_radii
        # --------------------------------------------------
        self.max_radii = np.asarray(
            [float(ball["radius"])
                for ball in balls],dtype=np.float64,)
        # --------------------------------------------------
        # Mean radius每个粒球的平均半径 mean_radius
        # --------------------------------------------------
        mean_radii = []
        for i, ball in enumerate(balls):
            if "mean_radius" not in ball:
                raise ValueError(
                    f"第{i}个粒球没有mean_radius。")
            mean_radii.append(float(ball["mean_radius"]))
        self.mean_radii = np.asarray(mean_radii,dtype=np.float64,)
        # --------------------------------------------------
        # Labels每个粒球对应的类别标签
        self.ball_labels = np.asarray(
            [int(ball["label"])
                for ball in balls],
            dtype=np.int64,)
        # ball_sizes：每个粒球包含多少原始样本
        self.ball_sizes = np.asarray(
            [int(ball["num_samples"])
                for ball in balls],
            dtype=np.float64,)
        ## classes：全部不重复的类别（已学习类别集合 seen_classes）
        self.classes = np.unique(
            self.ball_labels)

        self.class_to_position = {
            int(c): i
            for i, c in enumerate(self.classes)}
        self.class_ball_indices = {}#特征维度
        for c in self.classes:## class_ball_indices：每个类别c，对应所有属于该类的粒球下标
            self.class_ball_indices[int(c)] = (np.where(self.ball_labels == c
                )[0])

        self.feature_dim = (self.centers.shape[1])#特征维度
        # --------------------------------------------------
        # Numerical protection数值保护，半径不能小于epsilon，避免分母为0
        self.safe_max_radii = np.maximum(self.max_radii,self.epsilon,)
        self.safe_mean_radii = np.maximum(self.mean_radii,self.epsilon,)

    @classmethod##从文件加载粒球
    def from_file(cls,ball_path: str,**kwargs,) -> "ExperimentalGranularBallClassifier":
        return cls(load_granular_balls(ball_path),**kwargs,)

    def _check_features(self,X: np.ndarray,) -> np.ndarray:
        X = np.asarray(X,dtype=np.float64,)
        if X.ndim == 1:
            X = X.reshape(1, -1)
        if X.ndim != 2:
            raise ValueError("输入特征必须为二维数组")
        if X.shape[1] != self.feature_dim:
            raise ValueError("特征维度不匹配")
        return X

    #批量计算样本到所有粒球中心欧氏距离
    def _euclidean_distances(self,X: np.ndarray,) -> np.ndarray:
        diff = (X[:, None, :]-self.centers[None, :, :])
        return np.linalg.norm(diff,axis=2,)

    # ======================================================
    # Mode 1:
    # Original max-radius + max response原始模式
    # ======================================================

    def _scores_original_max(self,distances: np.ndarray,) -> np.ndarray:
        rho = (distances/self.safe_max_radii[None, :])
        responses = np.exp(-(rho ** 2))
        scores = np.zeros((distances.shape[0],len(self.classes),),dtype=np.float64,)
        for class_pos, c in enumerate(self.classes):
            indices = (self.class_ball_indices[int(c)])
            scores[:, class_pos] = np.max(responses[:, indices],axis=1,)
        return scores

    # ======================================================
    # Mode 2:全粒球均值模式:同类所有粒球归一化距离取均值，取最大类别响应对应的类别
    # Mean radius + mean distance of ALL balls in class
    # ======================================================

    def _scores_mean_all_distance(self,distances: np.ndarray,) -> np.ndarray:
        rho = (distances/self.safe_mean_radii[None, :])
        scores = np.zeros((distances.shape[0],len(self.classes),),dtype=np.float64,)

        for class_pos, c in enumerate(self.classes):
            indices = (self.class_ball_indices[int(c)])
            # Average normalized distance from the
            # sample to ALL balls belonging to class c.
            mean_rho = np.mean(rho[:, indices],axis=1,)
            # Convert distance to high-is-better score.
            scores[:, class_pos] = np.exp(-(mean_rho ** 2))
        return scores

    # ======================================================
    # Mode 3:现在的方法，平均半径以及距离自适应筛选粒球
    # Mean-radius stable core自适应边界模式
    # +
    # adaptive boundary candidate set
    # ======================================================

    # 入参`direct_radii=None`；默认用`mean_radii`做核心判定
# max_unique_then_adaptive_mean：调用时传入`direct_radii=self.max_radii`，用 max 半径做核心判定
    def _scores_adaptive_boundary(
            self,
            distances: np.ndarray,
            direct_radii: np.ndarray | None = None,
    ) -> np.ndarray:
        n_samples = distances.shape[0]
        n_classes = len(self.classes)
        scores = np.zeros((n_samples,n_classes,),dtype=np.float64,)

        # mean radius normalized response
        rho = (distances/self.safe_mean_radii[None, :])
        responses = np.exp(-(rho ** 2))

        # 旧模式以 mean radius 决定直接判类；新模式以max radius
        # 判断覆盖标签是否唯一。异类重叠和球外仍使用 mean-radius 响应。
        if direct_radii is None:
            direct_radii = self.mean_radii
        inside_matrix = (distances<=direct_radii[None, :])

        for sample_i in range(
                n_samples
        ):

            d = distances[sample_i]

            inside = inside_matrix[
                sample_i
            ]

            # ==================================================
            # Case 1:
            # 单类别核心覆盖
            #
            # 直接高置信度分类
            # ==================================================

            if np.any(inside):

                inside_indices = np.where(inside)[0]

                inside_labels = np.unique(self.ball_labels[inside_indices])

                if len(inside_labels) == 1:
                    c = int(inside_labels[0])
                    class_pos = (self.class_to_position[c])

                    scores[sample_i,class_pos,] = 1.0
                    continue
            # ==================================================
            # Case 2:
            # 异类核心覆盖 或无核心覆盖
            # 统一进入 adaptive boundary
            # ==================================================
            # 最近球心距离 l_c 给出本样本的候选搜索尺度。
            # 对每个球计算平均半径边界距离 b_k = d_k - r_mean_k，
            # 所有 b_k < l_c 的球都参与后续按类别聚合响应。
            boundary_distance = (d-self.mean_radii)
            nearest_ball = int(np.argmin(d))
            nearest_center_distance = float(d[nearest_ball])
            candidate_mask = (boundary_distance < nearest_center_distance)

            # 平均半径为零或恰好落在边界上时，严格小于号可能
            # 使最近球心不满足条件；仍须保证它参加分类。

            candidate_mask[
                nearest_ball
            ] = True

            candidate_indices = np.where(
                candidate_mask
            )[0]

            # ==================================================
            # candidate response aggregation
            # ==================================================

            candidate_labels = (
                self.ball_labels[
                    candidate_indices
                ]
            )

            candidate_responses = (
                responses[
                    sample_i,
                    candidate_indices
                ]
            )

            for c in np.unique(
                    candidate_labels
            ):

                class_mask = (
                        candidate_labels == c
                )

                values = (
                    candidate_responses[
                        class_mask
                    ]
                )

                class_pos = (
                    self.class_to_position[
                        int(c)
                    ]
                )

                if self.adaptive_aggregate == "sum":

                    class_score = np.sum(
                        values
                    )

                else:

                    class_score = np.mean(
                        values
                    )

                scores[
                    sample_i,
                    class_pos,
                ] = class_score

            # ==================================================
            # numerical fallback
            # ==================================================

            if np.max(
                    scores[sample_i]
            ) <= 0.0:
                nearest_class = int(
                    self.ball_labels[
                        nearest_ball
                    ]
                )

                class_pos = (
                    self.class_to_position[
                        nearest_class
                    ]
                )

                scores[
                    sample_i,
                    class_pos,
                ] = 1.0

        return scores

    def class_scores(
        self,
        X: np.ndarray,
        batch_size: int = 2048,
    ) -> np.ndarray:

        X = self._check_features(X)

        n_samples = len(X)

        scores = np.empty(
            (
                n_samples,
                len(self.classes),
            ),
            dtype=np.float64,
        )

        for start in range(
            0,
            n_samples,
            batch_size,
        ):

            end = min(
                start + batch_size,
                n_samples,
            )

            xb = X[start:end]

            distances = (
                self._euclidean_distances(
                    xb
                )
            )

            if (
                self.decision_mode
                ==
                "original_max"
            ):

                batch_scores = (
                    self._scores_original_max(
                        distances
                    )
                )

            elif (
                self.decision_mode
                ==
                "mean_all_distance"
            ):

                batch_scores = (
                    self._scores_mean_all_distance(
                        distances
                    )
                )

            elif (
                self.decision_mode
                ==
                "adaptive_boundary"
            ):

                batch_scores = (
                    self._scores_adaptive_boundary(
                        distances
                    )
                )

            elif self.decision_mode == "max_unique_then_adaptive_mean":
                batch_scores = self._scores_adaptive_boundary(
                    distances, direct_radii=self.max_radii
                )

            else:
                raise RuntimeError(
                    "invalid decision_mode"
                )

            scores[
                start:end
            ] = batch_scores

        return scores

    def predict(self,X: np.ndarray,batch_size: int = 2048,) -> np.ndarray:
        scores = self.class_scores(X,batch_size=batch_size,)
        best_class_position = np.argmax(scores,axis=1,)
        return self.classes[best_class_position]
#给出预测。
    def predict_with_details(self,X: np.ndarray,batch_size: int = 2048,
    ) -> Tuple[np.ndarray,np.ndarray,np.ndarray,]:
        X = self._check_features(X)#检查特征维度
        scores = self.class_scores(X,batch_size=batch_size,)#核心打分函数
        best_class_position = np.argmax(scores,axis=1,)#找到**得分最高的类别索引**
        predictions = (self.classes[best_class_position]) #把下标映射成真实类别标签：
        best_class_scores = (scores[np.arange(len(scores)),best_class_position,])
        #取出每个样本**最高分的那个分数**，也就是获胜类响应值。
        # --------------------------------------------------
        # Coverage definition
        # Original mode:
        # max radius
        # Experimental mean-radius modes:
        # mean radius#Coverage 覆盖判定逻辑
        # --------------------------------------------------

        if (self.decision_mode
            in ("original_max", "max_unique_then_adaptive_mean")):
            coverage_radii = (self.max_radii)
        else:
            coverage_radii = (self.mean_radii)
        covered = np.zeros(len(X),dtype=bool,)
        for start in range(0,len(X),batch_size,):#分批计算欧氏距离，判断覆盖：
            end = min(start + batch_size,len(X),)
            xb = X[start:end]
            distances = (self._euclidean_distances(xb))#计算这批样本到**所有粒球中心**的欧氏距离
            covered[start:end] = np.any(distances<=coverage_radii[None, :],axis=1,)
            #np.any(..., axis=1)：只要落在任意一个粒球的覆盖半径内，就标记为 covered=True
#预测类别、获胜类得分、样本是否被粒球覆盖的布尔标记。
        return (
            predictions,
            best_class_scores,
            covered,
        )
