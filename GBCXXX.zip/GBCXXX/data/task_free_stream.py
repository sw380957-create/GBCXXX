"""
task_free_stream.py
============================================================
通用 Task-Free Continual Learning 数据流协议生成器
============================================================
设计目标原始训练集 labels —— 全局划分 train / validation —— 定义若干隐藏anchor —— 把train样本严格分配给不同anchor
——在相邻anchor之间做平滑过渡 —— 形成一个连续的Task-Free stream —— 验证：样本不重复；train / validation 不重叠
    所有样本完整覆盖 ↓ 保存 protocol.json
--------
1. 数据流中不向 learner 暴露 task_id / stage_id / anchor_id / boundary。
2. 原始样本在“新数据流”中只分配一次；是否在局部训练窗口内重复优化，
   由后续 trainer 决定，与本文件无关。
3. 保留原 strict-stream 版本的优点：
   - 固定随机种子；
   - 样本级严格不重复；
   - train / validation 严格分离；
   - 可复现 manifest / hash。
4. 将原来的离散 D1 -> D2 -> ... 改为隐藏分布锚点之间的平滑过渡。
5. 核心逻辑只依赖 labels / sample IDs / anchors，不写死 CIFAR-10，
   因此可复用于 CIFAR-100、CUB-200 或其他分类数据集。
核心思想
--------
先把 train IDs 按类别分配给若干“隐藏分布锚点” anchor pools。
例如 CIFAR-10：A1=[0,1,2,3]；A2=[1,3,4,6]
每个类别内部只建立一次随机样本队列，因此同一原始样本不会重复分配。
随后在相邻 anchor pools 的边界处，取：
    - 当前 anchor 尾部的一部分样本
    - 下一 anchor 头部的一部分样本
做逐渐从“当前 anchor 主导”到“下一 anchor 主导”的交织重排。
重要：这里的 smooth transition 只改变“数据到达顺序”，不会复制样本，
不会把同一张图片同时放进两个 anchor，也不会要求 learner 知道边界。
本文件只负责“数据协议层”，不负责：
- ResNet / backbone
- optimizer / scheduler
- local epochs
- loss
- granular-ball update
- classifier
推荐用法
--------
A. 通用数据集：
    labels = np.asarray(...)
    protocol = build_task_free_protocol(
        labels=labels,
        anchors=[...],
        val_ratio=0.1,
        seed=2026,
        transition_fraction=0.2,
    )

B. CIFAR-10：
    python task_free_stream.py --dataset cifar10 \
        --data-root data \
        --output out/task_free/tf_v1/protocol.json

训练器后续只应读取 learner_view(protocol)，不要读取 analysis_only 元数据。
"""

from __future__ import annotations

import argparse
import hashlib
import json
import random
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np


# ============================================================
# 1. 默认设置
# ============================================================
SEED = 2026#随机种子
DEFAULT_VAL_RATIO = 0.1#原始 training set 被拿出来作为验证集
DEFAULT_TRANSITION_FRACTION = 0.2#控制 平滑过渡 的参数,相邻两个隐藏anchor之间，有多少比例的样本参与平滑过渡。
DEFAULT_DIAGNOSTIC_WINDOW = 512#每 512 个 stream sample 统计一次类别分布。用来画图或者检查：数据是不是按照预期渐进变化。
DEFAULT_TRANSITION_BINS = 10

# 保留你当前 CIFAR-10 已经确定的 overlapping class schedule，
# 但这里把它重新定义为“隐藏分布锚点”，不是 learner 可见的 task/stage。
CIFAR10_DEFAULT_ANCHORS: List[List[int]] = [
    [0, 1, 2, 3],
    [1, 3, 4, 6],
    [2, 4, 8, 9],
    [3, 5, 7, 9],
    [2, 5, 7, 8],
    [0, 2, 5, 7],
    [1, 4, 5, 6],
    [1, 3, 4, 9],
    [0, 6, 8, 9],
    [0, 6, 7, 8],
]

# ============================================================
# 2. 随机种子
# ============================================================
def set_random_seed(seed: int = SEED) -> None:
    """固定 Python / NumPy 随机种子。
    本文件本身不依赖 PyTorch；如果 trainer 使用 PyTorch，
    请在 trainer 中继续固定 torch / CUDA seed。
    """
    random.seed(seed)
    np.random.seed(seed)

# ============================================================
# 3. 工具函数:
# ============================================================
def _as_int_labels(labels: Sequence[int]) -> np.ndarray:
    #检查并转换整数标签
    arr = np.asarray(labels)
    if arr.ndim != 1:
        raise ValueError("labels 必须是一维数组。")
    if len(arr) == 0:
        raise ValueError("labels 不能为空。")
    if not np.issubdtype(arr.dtype, np.integer):
        raise ValueError("labels 必须为整数，不能静默截断浮点标签。")
    return arr.astype(np.int64, copy=False)


def _canonical_json_bytes(value: Mapping) -> bytes:
    """用于稳定 hash 的 JSON 编码。生成稳定的 JSON 字节表示"""
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")

def _sha256_bytes(data: bytes) -> str:
    #计算内容或索引序列的哈希
    return hashlib.sha256(data).hexdigest()

def _sha256_int64(values: np.ndarray) -> str:
    #计算内容或索引序列的哈希
    arr = np.asarray(values, dtype=np.int64)
    return _sha256_bytes(arr.tobytes())

def _class_count_dict(labels: np.ndarray, ids: np.ndarray) -> Dict[str, int]:
    #统计指定样本中的类别数量
    if len(ids) == 0:
        return {}
    classes, counts = np.unique(labels[ids], return_counts=True)  ##就是类别统计。
    return {str(int(c)): int(n) for c, n in zip(classes, counts)}


def _validate_anchor_definitions(
    anchors: Sequence[Sequence[int]],
    class_values: np.ndarray,
) -> List[List[int]]:
    ##检查样本索引合法、不重复，训练与验证独立且完整覆盖数据。anchor定义是否合法
    if len(anchors) < 1:
        raise ValueError("至少需要一个隐藏分布锚点。")

    allowed = set(map(int, class_values.tolist()))
    normalized: List[List[int]] = []

    for i, anchor in enumerate(anchors):
        row = [int(c) for c in anchor]
        if not row:
            raise ValueError(f"anchor {i} 不能为空。")
        if len(row) != len(set(row)):
            raise ValueError(f"anchor {i} 内不能出现重复类别。")
        unknown = sorted(set(row) - allowed)
        if unknown:
            raise ValueError(f"anchor {i} 包含数据集中不存在的类别: {unknown}")
        normalized.append(row)

    covered = set(c for row in normalized for c in row)
    missing = sorted(allowed - covered)
    if missing:
        raise ValueError(
            "存在从未出现在任何 anchor 中的类别，无法把其 train 样本分配到流中: "
            f"{missing}"
        )

    return normalized
# ============================================================
# 4. 全局、分层 train / validation 划分
# ============================================================
def stratified_train_validation_split(
    labels: Sequence[int],
    val_ratio: float = DEFAULT_VAL_RATIO,
    seed: int = SEED,
) -> Tuple[np.ndarray, np.ndarray]:
    """对整个原始训练集做一次固定的全局分层划分。
    与旧 stage-wise 方案不同：
    - validation 不再按 D1/D2/... 分块；
    - validation 永远不进入 continual stream；
    - validation 只用于后续全局超参数选择。
    返回
    train_ids, validation_ids
        都是原始数据集中的全局 sample ID。
    """
    labels_arr = _as_int_labels(labels)
    if not (0.0 <= val_ratio < 1.0):
        raise ValueError("val_ratio 必须满足 0 <= val_ratio < 1。")

    rng = np.random.default_rng(seed)
    train_parts: List[np.ndarray] = []
    val_parts: List[np.ndarray] = []

    for c in np.unique(labels_arr):
        ids = np.flatnonzero(labels_arr == c).astype(np.int64) # 找到该类全部sample ID：,
        rng.shuffle(ids)#并随机打乱

        n = len(ids)
        n_val = int(round(n * val_ratio))
        if val_ratio > 0 and n >= 2:
            n_val = max(1, min(n - 1, n_val))
        elif val_ratio == 0:
            n_val = 0

        val_parts.append(ids[:n_val])
        train_parts.append(ids[n_val:])

    train_ids = np.concatenate(train_parts).astype(np.int64)
    validation_ids = (
        np.concatenate(val_parts).astype(np.int64)
        if any(len(x) for x in val_parts)
        else np.empty(0, dtype=np.int64)
    )

    # 这里的全局 shuffle 只影响初始 ID 顺序；真正 stream 顺序随后由 anchor 生成器决定。
    rng.shuffle(train_ids)
    rng.shuffle(validation_ids)

    return train_ids, validation_ids

# ============================================================
# 5. 通用的平衡 anchor 日程生成器（可选）
# ============================================================
def build_balanced_anchor_schedule(
    num_classes: int,#数据集总类别数
    num_anchors: int,#总共生成多少个隐藏 anchor
    active_classes_per_anchor: int,#每个 anchor 里放多少个不同类别
    seed: int = SEED,#随机种子
    first_anchor: Optional[Sequence[int]] = None,#你可以手动固定第一个 anchor
    overlap_bias: float = 0.75,#相邻 anchor 的重叠偏置。上一 anchor 里出现过的类别，在下一 anchor 中会获得额外抽样权重。它只是“倾向重叠”，不是强制重叠。
    max_restarts: int = 10000,#如果随机生成到后面发现无法满足“每类出现次数完全平衡”，就重新生成。这个参数规定最多重试多少次
) -> List[List[int]]:
    """自动生成一个类别出现次数严格平衡的 anchor schedule。
    这是旧 build_balanced_class_schedule 的通用版本。
    对于 CIFAR-100 等数据集，如果不想手工指定 anchor，可以使用它。
    限制：num_anchors * active_classes_per_anchor 必须能被 num_classes 整除，
        才能让每个类别出现次数完全一致。
        数据集总类别数
    """

    if num_classes <= 0 or num_anchors <= 0 or active_classes_per_anchor <= 0:
        raise ValueError("num_classes / num_anchors / active_classes_per_anchor 必须为正数。")
    if active_classes_per_anchor > num_classes:
        raise ValueError("active_classes_per_anchor 不能大于 num_classes。")

    total_slots = num_anchors * active_classes_per_anchor#所有 anchor 的类别位置总和 = anchor 数量 × 每个 anchor 的类别数量
    if total_slots % num_classes != 0:
        raise ValueError(
            "num_anchors * active_classes_per_anchor 必须能被 num_classes 整除，"
            "否则无法保证每类出现次数严格相同。"
        )

    appearances_per_class = total_slots // num_classes ##每个类别出现多少次，按照这10数据集来看是出现4次

    if first_anchor is not None:
        first = [int(c) for c in first_anchor]
        if len(first) != active_classes_per_anchor:
            raise ValueError("first_anchor 长度必须等于 active_classes_per_anchor。")
        if len(set(first)) != len(first):
            raise ValueError("first_anchor 不能包含重复类别。")
        if min(first) < 0 or max(first) >= num_classes:
            raise ValueError("first_anchor 包含非法类别编号。")
    else:
        first = []
#随机搜索构造 schedule（带重启机制）
    for restart in range(max_restarts):
        rng = np.random.default_rng(seed + restart)
        remaining = np.full(num_classes, appearances_per_class, dtype=np.int64)#每个类别还剩多少次必须被安排。
        schedule: List[np.ndarray] = []
        #如果传了 `first_anchor` 就用它；否则随机无放回采样一组类别。然后把选中类别的 `remaining` 计数 `-1`，加入 schedule。

        if first:
            row = np.asarray(first, dtype=np.int64)
        else:
            row = rng.choice(num_classes, size=active_classes_per_anchor, replace=False)

        remaining[row] -= 1
        if np.any(remaining < 0):
            continue
        schedule.append(row)

        success = True
        for _ in range(1, num_anchors):
            eligible = np.flatnonzero(remaining > 0)
            if len(eligible) < active_classes_per_anchor:##如果候选池里可用类别数量，少于当前 anchor 需要的类别数 → 构造失败，跳出本轮。
                success = False
                break

            weights = remaining[eligible].astype(np.float64)#基础权重 = 该类别剩余可选次数（剩余越多，越容易被抽中，保证均衡）
            previous = set(map(int, schedule[-1].tolist()))
            for j, c in enumerate(eligible):
                if int(c) in previous:
                    weights[j] += float(overlap_bias)

            probabilities = weights / weights.sum()#归一化权重做**无放回加权采样**
            selected = rng.choice(
                eligible,
                size=active_classes_per_anchor,
                replace=False,
                p=probabilities,
            ).astype(np.int64)

            remaining[selected] -= 1
            schedule.append(selected)

        if success and np.all(remaining == 0):#全部 anchor 生成完毕，并且所有类别剩余名额全部归零（每个类别都刚好达到目标出现次数）→ 返回结果
            return [row.astype(int).tolist() for row in schedule]

    raise RuntimeError("在最大重启次数内没有找到满足平衡约束的 anchor schedule。")

# ============================================================
# 6. 将 train IDs 严格分配给隐藏 anchor pools
# ============================================================
def allocate_train_ids_to_anchors(
    labels: Sequence[int],# 全部样本的标签（所有数据集样本）
    train_ids: Sequence[int],# 待分配的训练样本索引，是labels里的子集
    anchors: Sequence[Sequence[int]],# 前面生成的anchor schedule：[[c0,c1],[c2,c3],...]
    seed: int = SEED,# 随机种子
) -> List[np.ndarray]:
    """把训练样本 ID，按类别分配到各个 anchor 的样本池
    把每个 train raw sample 严格分配给一个隐藏 anchor。
    对每个类别 c：
    1. 找出 c 出现在哪些 anchors；
    2. 对 c 的 train IDs 只 shuffle 一次；
    3. 用 np.array_split 把这些 IDs 尽量均匀分给 c 的各次 anchor 出现。
    因此：
    - 同一 raw sample 只属于一个 anchor pool；
    - 类别可以跨 anchor 重复出现；
    - 即使类别样本数不能整除出现次数，也不会丢样本。
    """

    labels_arr = _as_int_labels(labels)
    train_ids_arr = np.asarray(train_ids, dtype=np.int64)
    class_values = np.unique(labels_arr)
    anchors_norm = _validate_anchor_definitions(anchors, class_values)

    if len(train_ids_arr) != len(np.unique(train_ids_arr)):
        raise ValueError("train_ids 内存在重复 sample ID。")
    if np.any(train_ids_arr < 0) or np.any(train_ids_arr >= len(labels_arr)):
        raise ValueError("train_ids 存在越界 sample ID。")

    rng = np.random.default_rng(seed)#初始化 anchor 池
    pools: List[List[int]] = [[] for _ in anchors_norm]

    for c in class_values:#对于每一类
        c = int(c)
        ## 取出：属于类别c、且在train_ids里面的所有样本ID
        class_ids = train_ids_arr[labels_arr[train_ids_arr] == c].copy()
        rng.shuffle(class_ids)#对样本进行一次打乱
        ## 找到：类别c出现在哪些anchor里面（appearances）
        appearances = [i for i, row in enumerate(anchors_norm) if c in row]
        if not appearances:
            raise ValueError(f"类别 {c} 没有出现在任何 anchor 中。")
        # 将该类所有样本，切分成 len(appearances) 份
        chunks = np.array_split(class_ids, len(appearances))
        # 依次把每份样本，给到对应的anchor
        for anchor_idx, chunk in zip(appearances, chunks):
            pools[anchor_idx].extend(chunk.astype(int).tolist())

    out: List[np.ndarray] = []
    #每个 anchor 内部再打乱
    for i, ids in enumerate(pools):
        arr = np.asarray(ids, dtype=np.int64)
        rng.shuffle(arr)
        if len(arr) == 0:
            raise ValueError(f"anchor {i} 没有分配到任何训练样本。")
        out.append(arr)
        #全局完整性校验
    assigned = np.concatenate(out)
    if len(assigned) != len(train_ids_arr):
        raise RuntimeError("anchor pools 总样本数与 train_ids 不一致。")
    if len(np.unique(assigned)) != len(train_ids_arr):
        raise RuntimeError("anchor pools 中存在重复 raw sample。")
    if set(assigned.tolist()) != set(train_ids_arr.tolist()):
        raise RuntimeError("anchor pools 没有完整覆盖 train_ids。")

    return out


# ============================================================
# 7. 相邻 anchor 的平滑过渡
# ============================================================
def _make_smooth_source_sequence(total: int) -> np.ndarray:
    """生成长度 total 的 0/1 source 序列。
    0 表示从左 anchor 取样，1 表示从右 anchor 取样。
    要求 total 为偶数，左右各贡献 total/2 个样本。
    序列不是简单的 [0...0, 1...1]，而是根据线性增长的 lambda：
        lambda: 0 -> 1
    让右 anchor 的累计占比逐渐增加。
    """
    if total <= 0 or total % 2 != 0:
        raise ValueError("transition total 必须是正偶数。")

    n_right = total // 2
    lambdas = np.linspace(0.0, 1.0, total, dtype=np.float64)
    # 对偶数 total，sum(lambdas) 恰好等于 total/2。
    target_cumulative_right = np.cumsum(lambdas)

    seq = np.zeros(total, dtype=np.int8)
    right_used = 0
    left_used = 0
    n_left = total // 2

    for i in range(total):
        desired_right = int(np.rint(target_cumulative_right[i]))

        choose_right = desired_right > right_used
        if choose_right and right_used < n_right:
            seq[i] = 1
            right_used += 1
        elif left_used < n_left:
            seq[i] = 0
            left_used += 1
        else:
            seq[i] = 1
            right_used += 1

    if right_used != n_right or left_used != n_left:
        raise RuntimeError("smooth source sequence 未满足严格左右配额。")

    return seq


def _mix_transition_ids(
    left_ids: np.ndarray,
    right_ids: np.ndarray,
) -> Tuple[np.ndarray, np.ndarray]:
    """把两侧等量样本按照逐渐 left -> right 的方式交织。
    返回：
        mixed_ids
        source_flags: 0=left, 1=right
    """

    left_ids = np.asarray(left_ids, dtype=np.int64)
    right_ids = np.asarray(right_ids, dtype=np.int64)
    if len(left_ids) != len(right_ids):
        raise ValueError("平滑过渡要求左右贡献相同数量的样本。")
    if len(left_ids) == 0:
        return np.empty(0, dtype=np.int64), np.empty(0, dtype=np.int8)

    source = _make_smooth_source_sequence(2 * len(left_ids))
    mixed = np.empty(len(source), dtype=np.int64)

    li = 0
    ri = 0
    for i, flag in enumerate(source):
        if flag == 0:
            mixed[i] = left_ids[li]
            li += 1
        else:
            mixed[i] = right_ids[ri]
            ri += 1

    return mixed, source

def smooth_anchor_pools(
    anchor_pools: Sequence[np.ndarray],
    labels: Sequence[int],
    transition_fraction: float = DEFAULT_TRANSITION_FRACTION,
    transition_bins: int = DEFAULT_TRANSITION_BINS,
) -> Tuple[np.ndarray, Dict]:
    """把离散 anchor pools 重排为无重复、渐进变化的 Task-Free stream。
    transition_fraction 的定义
    -------------------------
    对边界 anchor_i -> anchor_{i+1}：
        transition_length = transition_fraction * min(len(pool_i), len(pool_{i+1}))
    transition_length 会被调整为偶数。
    其中一半样本来自当前 anchor 的尾部，另一半来自下一 anchor 的头部。
    例：两个 anchor 都有 4500 个样本，transition_fraction=0.2：
        transition_length = 900
        左 anchor 尾部贡献 450
        右 anchor 头部贡献 450
    这 900 个样本不会硬切，而是从“左侧主导”逐步变为“右侧主导”。
    """

    if not (0.0 <= transition_fraction <= 1.0):
        raise ValueError("transition_fraction 必须位于 [0, 1]。")
    if transition_bins <= 0:
        raise ValueError("transition_bins 必须为正数。")

    labels_arr = _as_int_labels(labels)
    pools = [np.asarray(p, dtype=np.int64) for p in anchor_pools]
    if not pools:
        raise ValueError("anchor_pools 不能为空。")

    if len(pools) == 1 or transition_fraction == 0:
        stream = np.concatenate(pools)
        return stream, {
            "transition_fraction": float(transition_fraction),
            "boundaries": [],
        }

    # 每个边界的总 transition 长度（强制为偶数）。
    transition_lengths: List[int] = []
    for left, right in zip(pools[:-1], pools[1:]):
        total = int(np.floor(min(len(left), len(right)) * transition_fraction))
        if total % 2 == 1:
            total -= 1
        total = max(0, total)
        transition_lengths.append(total)

    head_take = [0] * len(pools)
    tail_take = [0] * len(pools)
    for i, total in enumerate(transition_lengths):
        half = total // 2
        tail_take[i] = half
        head_take[i + 1] = half

    for i, pool in enumerate(pools):
        if head_take[i] + tail_take[i] > len(pool):
            raise ValueError(
                f"anchor {i} 的 transition 需求超过 pool 大小；"
                "请减小 transition_fraction。"
            )

    pieces: List[np.ndarray] = []
    boundary_meta: List[Dict] = []
    stream_offset = 0

    for i, pool in enumerate(pools):
        h = head_take[i]
        t = tail_take[i]
        core_end = len(pool) - t if t > 0 else len(pool)
        core = pool[h:core_end]

        pieces.append(core)
        stream_offset += len(core)

        if i < len(pools) - 1:
            total = transition_lengths[i]
            half = total // 2
            if total == 0:
                continue

            left_tail = pool[len(pool) - half :]
            right_pool = pools[i + 1]
            right_head = right_pool[:half]

            mixed, source = _mix_transition_ids(left_tail, right_head)
            pieces.append(mixed)

            # 统计 transition 内实际类别分布和右侧来源比例，供人工核查。
            bins: List[Dict] = []
            bin_indices = np.array_split(np.arange(len(mixed)), transition_bins)
            for b, positions in enumerate(bin_indices):
                if len(positions) == 0:
                    continue
                ids = mixed[positions]
                right_fraction = float(source[positions].mean())
                bins.append(
                    {
                        "bin": b,
                        "num_samples": int(len(ids)),
                        "right_anchor_source_fraction": right_fraction,
                        "class_counts": _class_count_dict(labels_arr, ids),
                    }
                )

            boundary_meta.append(
                {
                    "from_anchor": i,
                    "to_anchor": i + 1,
                    "stream_start": int(stream_offset),
                    "stream_end_exclusive": int(stream_offset + len(mixed)),
                    "transition_length": int(len(mixed)),
                    "left_samples": int(half),
                    "right_samples": int(half),
                    "bins": bins,
                }
            )
            stream_offset += len(mixed)

    stream = np.concatenate(pieces).astype(np.int64)
    return stream, {
        "transition_fraction": float(transition_fraction),
        "transition_bins": int(transition_bins),
        "boundaries": boundary_meta,
    }

# ============================================================
# 8. Stream 诊断统计
# ============================================================
def summarize_stream_windows(
    labels: Sequence[int],
    stream_ids: Sequence[int],
    window_size: int = DEFAULT_DIAGNOSTIC_WINDOW,
) -> List[Dict]:
    """按固定 sample-count window 输出类别直方图，仅用于分析/画图。
    注意：这里的 window boundary 不是 task boundary，也不应被 learner 用作控制信号。
    """

    labels_arr = _as_int_labels(labels)
    ids = np.asarray(stream_ids, dtype=np.int64)
    if window_size <= 0:
        raise ValueError("window_size 必须为正数。")

    result: List[Dict] = []
    for start in range(0, len(ids), window_size):
        end = min(len(ids), start + window_size)
        chunk = ids[start:end]
        result.append(
            {
                "start": int(start),
                "end_exclusive": int(end),
                "num_samples": int(len(chunk)),
                "class_counts": _class_count_dict(labels_arr, chunk),
            }
        )
    return result


# ============================================================
# 9. Task-Free protocol 对象
# **不可变数据类**，实例一旦创建，字段不能修改。
# ============================================================
@dataclass(frozen=True)
class TaskFreeProtocol:
    dataset: str#数据集名字，如`cifar100`
    seed: int#全局随机种子，保证划分可复现
    class_values: Tuple[int, ...]#全部类别编号元组，固定类别集合
    train_stream_ids: Tuple[int, ...]#训练流的样本 ID 序列（整个持续学习流的样本索引）
    validation_ids: Tuple[int, ...]#验证集样本 ID
    labels_sha256: str#标签数组的 sha256 哈希；用来校验标签有没有被改动
    analysis_only: Mapping#**仅用于事后分析的参数**，模型训练阶段看不到。比如 anchor 配置、分块参数，只在日志 / 离线分析时使用。
    protocol_version: str = "task_free_stream_v2"#协议版本号，这里固定`task_free_stream_v2`，方便后续区分新旧实验方案。

    def learner_view(self) -> Dict:
        """训练器允许读取的最小视图。
        明确不返回：
        - anchors
        - transition boundaries
        - hidden distribution IDs
        - task/stage IDs
        """

        return {
            "dataset": self.dataset,
            "seed": self.seed,
            "protocol_version": self.protocol_version,
            "class_values": list(self.class_values),
            "train_stream_ids": list(self.train_stream_ids),
            "validation_ids": list(self.validation_ids),
            "labels_sha256": self.labels_sha256,
        }

    def to_manifest(self) -> Dict:
        base = {
            **self.learner_view(),
            "stream_length": len(self.train_stream_ids),#训练流总样本数量
            "validation_length": len(self.validation_ids),#验证集样本数量
            "analysis_only": dict(self.analysis_only),#把分析用参数（anchor 配置等）放进来，manifest 里保存，但训练器看不到
        }
        base["train_stream_sha256"] = _sha256_int64(
            np.asarray(self.train_stream_ids, dtype=np.int64)
        )
        base["validation_sha256"] = _sha256_int64(
            np.asarray(self.validation_ids, dtype=np.int64)
        )

        # protocol_sha256 不参与自身 hash。
        #**唯一指纹**，只要实验协议、划分、参数任何一处改动，`protocol_sha256`就会改变。
        # 论文实验里用来保证所有对比实验划分完全一致，杜绝 “划分不一样导致结果不可比”。
        base["protocol_sha256"] = _sha256_bytes(_canonical_json_bytes(base))
        return base


# ============================================================
# 10. 构建完整 Task-Free protocol——把前面你看过的所有模块串在一起：
# ============================================================
def build_task_free_protocol(
    labels: Sequence[int],# 全部数据集样本的标签
    anchors: Optional[Sequence[Sequence[int]]] = None,# 手工指定anchor类别表
    *,
    anchor_mode: Optional[str] = None,# anchor模式：manual手工 / random_balanced自动生成
    num_classes: Optional[int] = None,# 类别总数校验用
    num_anchors: int = 10,# anchor总数量（random_balanced模式生效）
    active_classes_per_anchor: int = 4,# 每个anchor包含多少类别（random_balanced生效）
    dataset_name: str = "custom",
    val_ratio: float = DEFAULT_VAL_RATIO,# 验证集划分比例
    seed: int = SEED,
    transition_fraction: float = DEFAULT_TRANSITION_FRACTION,# 过渡段占比
    diagnostic_window: int = DEFAULT_DIAGNOSTIC_WINDOW,#一个窗口多少个样本512
    transition_bins: int = DEFAULT_TRANSITION_BINS,
) -> TaskFreeProtocol:
    """构建一个数据集无关的 Task-Free stream protocol。"""

    labels_arr = _as_int_labels(labels)
    class_values = np.unique(labels_arr)
    if num_classes is not None and num_classes != len(class_values):
        raise ValueError("num_classes 必须与 labels 中实际类别数一致")
    # 旧 Python 调用显式传 anchors 仍视为 manual；新默认不再固定 CIFAR10 anchors。
    anchor_mode = anchor_mode or ('manual' if anchors is not None else 'random_balanced')
    if anchor_mode == 'random_balanced':
        if anchors is not None:
            raise ValueError("random_balanced 不接受手工 anchors")
        # 调用你前面的函数：生成平衡anchor类别调度表
        schedule = build_balanced_anchor_schedule(len(class_values), num_anchors,
                                                 active_classes_per_anchor, seed)
        anchors = [[int(class_values[i]) for i in row] for row in schedule]
    elif anchor_mode != 'manual' or anchors is None:
        raise ValueError("manual 模式必须显式传入 anchors")
    anchors_norm = _validate_anchor_definitions(anchors, class_values)
    #anchors_norm：校验并标准化 anchor，检查类别id合法、无异常。
    #分层划分训练集 / 验证集（strified分层抽样）
    train_ids, validation_ids = stratified_train_validation_split(
        labels_arr,
        val_ratio=val_ratio,
        seed=seed,
    )
    # 调用前面的函数：**按类别把训练样本分配到每个 anchor 的样本池**。
    anchor_pools = allocate_train_ids_to_anchors(
        labels_arr,
        train_ids,
        anchors_norm,
        seed=seed + 1000,
    )
    # 平滑拼接anchor池，生成连续数据流 + 过渡元信息
    stream_ids, transition_meta = smooth_anchor_pools(
        anchor_pools,
        labels_arr,
        transition_fraction=transition_fraction,
        transition_bins=transition_bins,
    )

    # ----------------------------
    # 严格验证-全局校验
    # ----------------------------
    verify_task_free_protocol(
        labels=labels_arr,
        train_stream_ids=stream_ids,
        validation_ids=validation_ids,
        expected_all_ids=np.arange(len(labels_arr), dtype=np.int64),
    )
    #**所有框架内部、离线分析用的私有元信息**，会塞进`TaskFreeProtocol`
    analysis_only = {
        "anchor_mode": anchor_mode,
        "val_ratio": float(val_ratio),
        "diagnostic_window": int(diagnostic_window),
        "diagnostics_usage": "diagnostic_window and transition_bins are offline statistics only; never training controls",
        "warning": (
            "analysis_only metadata must never be exposed to the continual learner; "
            "it exists only for reproducibility and offline analysis."
        ),
        "anchor_definitions": anchors_norm,
        "anchor_pool_sizes": [int(len(x)) for x in anchor_pools],
        "anchor_pool_class_counts": [
            _class_count_dict(labels_arr, pool) for pool in anchor_pools
        ],
        "transition_definition": {
            "type": "adjacent_anchor_linear_source_mix",
            "formula": "p_t=(1-lambda_t)q_m+lambda_t q_(m+1), lambda_t:0->1",
            **transition_meta,
        },
        "diagnostic_windows": summarize_stream_windows(
            labels_arr,
            stream_ids,
            window_size=diagnostic_window,
        ),
        "train_class_counts": _class_count_dict(labels_arr, stream_ids),
        "validation_class_counts": _class_count_dict(labels_arr, validation_ids),
        "learner_visibility": {
            "task_id": False,
            "stage_id": False,
            "anchor_id": False,
            "boundary_flag": False,
            "labels": True,
            "sample_ids": True,
        },
    }

    return TaskFreeProtocol(
        dataset=str(dataset_name),#数据集的名字
        seed=int(seed),
        class_values=tuple(map(int, class_values.tolist())),
        train_stream_ids=tuple(map(int, stream_ids.tolist())),
        validation_ids=tuple(map(int, validation_ids.tolist())),
        labels_sha256=_sha256_int64(labels_arr),
        analysis_only=analysis_only,
    )


# ============================================================
# 11. 严格验证
# ============================================================
def verify_task_free_protocol(
    labels: Sequence[int],
    train_stream_ids: Sequence[int],
    validation_ids: Sequence[int],
    expected_all_ids: Optional[Sequence[int]] = None,
) -> Dict:
    labels_arr = _as_int_labels(labels)
    train_ids = np.asarray(train_stream_ids, dtype=np.int64)
    val_ids = np.asarray(validation_ids, dtype=np.int64)

    if np.any(train_ids < 0) or np.any(train_ids >= len(labels_arr)):
        raise AssertionError("train stream 存在越界 ID。")
    if np.any(val_ids < 0) or np.any(val_ids >= len(labels_arr)):
        raise AssertionError("validation 存在越界 ID。")

    train_unique = np.unique(train_ids)
    val_unique = np.unique(val_ids)

    if len(train_unique) != len(train_ids):
        raise AssertionError("train stream 内存在重复 raw sample。")
    if len(val_unique) != len(val_ids):
        raise AssertionError("validation 内存在重复 raw sample。")

    intersection = np.intersect1d(train_unique, val_unique)
    if len(intersection) != 0:
        raise AssertionError("train stream 与 validation 不独立。")

    if expected_all_ids is None:
        expected = np.arange(len(labels_arr), dtype=np.int64)
    else:
        expected = np.asarray(expected_all_ids, dtype=np.int64)

    combined = np.sort(np.concatenate([train_unique, val_unique]))
    if not np.array_equal(combined, np.sort(expected)):
        raise AssertionError("train + validation 没有严格覆盖预期的全部样本。")

    return {
        "status": "ok",
        "train_stream_length": int(len(train_ids)),
        "validation_length": int(len(val_ids)),
        "train_unique": True,
        "validation_unique": True,
        "train_validation_disjoint": True,
        "full_coverage": True,
        "train_class_counts": _class_count_dict(labels_arr, train_ids),
        "validation_class_counts": _class_count_dict(labels_arr, val_ids),
    }


# ============================================================
# 12. Manifest 保存 / 读取，导出成 JSON 文件保存
# ============================================================
def save_protocol(protocol: TaskFreeProtocol, path: str | Path) -> Path:
    out = Path(path)#把路径转为 Path 对象；自动创建目标文件夹，文件夹已存在也不报错。
    out.parent.mkdir(parents=True, exist_ok=True)
    manifest = protocol.to_manifest()
    with out.open('x', encoding='utf-8') as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2, allow_nan=False)
    return out


def load_protocol_manifest(path: str | Path, verify_hash: bool = True) -> Dict:
    #读取 JSON 文件，**带哈希校验**，确保文件没有被篡改、实验划分完全没变。
    manifest = json.loads(Path(path).read_text(encoding="utf-8"))

    if verify_hash:
        stored = manifest.get("protocol_sha256")
        if not stored:
            raise ValueError("manifest 缺少 protocol_sha256。")
        payload = dict(manifest)
        payload.pop("protocol_sha256", None)
        actual = _sha256_bytes(_canonical_json_bytes(payload))
        if actual != stored:
            raise ValueError("protocol_sha256 校验失败，manifest 可能被修改。")
        for key, digest in [('train_stream_ids', 'train_stream_sha256'),
                            ('validation_ids', 'validation_sha256')]:
            if _sha256_int64(np.asarray(manifest[key])) != manifest[digest]:
                raise ValueError(f"{digest} 校验失败")

    return manifest


def learner_view_from_manifest(manifest: Mapping) -> Dict:
    """从落盘 manifest 中提取 learner 可见字段。
    训练代码建议只调用这个函数，不直接读取 analysis_only。
    """
    allowed = {
        "dataset",  # 数据集名称
        "seed",  # 全局随机种子
        "protocol_version",  # 协议版本
        "class_values",  # 全部类别编号
        "train_stream_ids",  # 持续学习流样本ID序列（模型读样本用）
        "validation_ids",  # 验证集样本ID
        "labels_sha256",  # 标签哈希，校验标签未篡改
        "train_stream_sha256",  # 训练流ID哈希
        "validation_sha256",  # 验证集ID哈希
        "protocol_sha256",  # 整套协议哈希
        "dataset_index_sha256",  # 外部数据集样本路径和预处理的固定索引
    }

    return {k: manifest[k] for k in allowed if k in manifest}


# ============================================================
# 13. CIFAR-10 adapter（只是示例；核心逻辑并不依赖 CIFAR-10）
# ============================================================
def load_cifar10_labels(
    root: str,
    download: bool = False,
) -> np.ndarray:
    """只读取 CIFAR-10 train labels；真正图像仍由训练器按 ID 访问。"""
    from torchvision.datasets import CIFAR10
    dataset = CIFAR10(root=root, train=True, download=download)
    return np.asarray(dataset.targets, dtype=np.int64)

#加载 CIFAR10 标签，调用你前面看过的`build_task_free_protocol`，
# 默认使用`random_balanced`自动生成 anchor 调度表，直接返回完整`TaskFreeProtocol`对象。
#**示例封装**，实验主流程不依赖这个函数，真正入口是下面 CLI
def build_cifar10_default_protocol(
    data_root: str,
    *,
    val_ratio: float = DEFAULT_VAL_RATIO,
    seed: int = SEED,
    transition_fraction: float = DEFAULT_TRANSITION_FRACTION,
    diagnostic_window: int = DEFAULT_DIAGNOSTIC_WINDOW,
    transition_bins: int = DEFAULT_TRANSITION_BINS,
    download: bool = False,
) -> TaskFreeProtocol:
    labels = load_cifar10_labels(data_root, download=download)
    return build_task_free_protocol(
        labels=labels,
        anchor_mode="random_balanced",
        dataset_name="CIFAR-10",
        val_ratio=val_ratio,
        seed=seed,
        transition_fraction=transition_fraction,
        diagnostic_window=diagnostic_window,
        transition_bins=transition_bins,
    )

# ============================================================
# 14. CLI
# ============================================================
def _print_summary(protocol: TaskFreeProtocol) -> None:
    manifest = protocol.to_manifest()

    print("=" * 72)
    print("Task-Free Protocol Summary")
    print("=" * 72)
    print("Dataset:", manifest["dataset"])
    print("Seed:", manifest["seed"])
    print("Classes:", manifest["class_values"])
    print("Train stream length:", manifest["stream_length"])
    print("Validation length:", manifest["validation_length"])
    print("Protocol SHA256:", manifest["protocol_sha256"])
    print("Learner task/stage visibility: False")
    print("Train class counts:", manifest["analysis_only"]["train_class_counts"])
    print("Validation class counts:", manifest["analysis_only"]["validation_class_counts"])
##协议生成完成后，在控制台打印**摘要信息**，方便肉眼快速核对：
#数据集名、随机种子、类别列表、训练流总长度、验证集大小、协议哈希、训练 / 验证集各类样本数量。
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    ## 注册所有命令行参数
    parser.add_argument("--dataset", default="cifar10", choices=["cifar10", "cifar100", "custom"])##`cifar10`/`cifar100`/`custom`

    parser.add_argument("--dataset-name")
    parser.add_argument("--labels-npy")
    parser.add_argument("--anchor-mode", choices=['manual', 'random_balanced'], default='random_balanced')
    # random_balanced自动生成 anchor；
    # manual手工指定 anchor
    parser.add_argument("--anchors-json", help="manual 模式的二维整数 JSON 文件；CIFAR10 不传时用兼容 schedule")
    parser.add_argument("--num-anchors", type=int, default=10)#anchor 总数量（random_balanced 生效）
    parser.add_argument("--active-classes-per-anchor", type=int, default=4)
    # 每个 anchor 包含多少类别
    root = Path(__file__).resolve().parents[1]
    parser.add_argument("--data-root", default=str(root / "data"))
    # 默认读取项目下的 data；可通过 --data-root 指定其他位置。
    parser.add_argument("--output", default=str(root / "out/task_free/tf_v1/protocol.json"))
    # 输出 protocol.json 的保存路径
    parser.add_argument("--seed", type=int, default=SEED)
    parser.add_argument("--val-ratio", type=float, default=DEFAULT_VAL_RATIO)
    # 相邻anchor之间过渡样本占比
    parser.add_argument("--transition-fraction",type=float,default=DEFAULT_TRANSITION_FRACTION,)
    # -diagnostic-window:离线统计滑动窗口大小
    parser.add_argument("--diagnostic-window",type=int,default=DEFAULT_DIAGNOSTIC_WINDOW,)
    # `--transition-bins`：过渡段分箱数
    parser.add_argument("--transition-bins",type=int,default=DEFAULT_TRANSITION_BINS,)
    # download：加上这个标记，自动下载 CIFAR 数据集
    parser.add_argument("--download", action="store_true")
    args = parser.parse_args()
    set_random_seed(args.seed)#custom 自定义数据集分支：
    if args.dataset in {'cifar10', 'cifar100'}:##直接用 torchvision 加载数据集，读取 train 标签数组
        from torchvision.datasets import CIFAR10, CIFAR100
        cls = CIFAR10 if args.dataset == 'cifar10' else CIFAR100
        labels = np.asarray(cls(root=args.data_root, train=True, download=args.download).targets, dtype=np.int64)
        name = 'CIFAR-10' if args.dataset == 'cifar10' else 'CIFAR-100'
    else:#custom 自定义数据集分支
        if not args.labels_npy or not args.dataset_name:
            parser.error('custom requires --labels-npy and --dataset-name')
        labels = _as_int_labels(np.load(args.labels_npy, allow_pickle=False))
        name = args.dataset_name
    anchors = None
    if args.anchors_json:
        anchors = json.loads(Path(args.anchors_json).read_text(encoding='utf-8'))
    elif args.anchor_mode == 'manual' and args.dataset == 'cifar10':
        anchors = CIFAR10_DEFAULT_ANCHORS
    #调用核心函数`build_task_free_protocol`，生成完整 TaskFreeProtocol 对象
    protocol = build_task_free_protocol(labels, anchors, dataset_name=name,
        anchor_mode=args.anchor_mode, num_anchors=args.num_anchors,
        active_classes_per_anchor=args.active_classes_per_anchor, val_ratio=args.val_ratio,
        seed=args.seed, transition_fraction=args.transition_fraction,
        diagnostic_window=args.diagnostic_window, transition_bins=args.transition_bins)

    path = save_protocol(protocol, args.output)
    _print_summary(protocol)
    print("Saved:", path)


if __name__ == "__main__":
    main()
