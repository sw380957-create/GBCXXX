"""MNIST IDX/gzip loading without exporting 70,000 individual image files."""
import gzip
import hashlib
import struct
from pathlib import Path

import numpy as np
from PIL import Image


NAMES = {'train_images': ('train-images-idx3-ubyte', 'train-images.idx3-ubyte'),
         'train_labels': ('train-labels-idx1-ubyte', 'train-labels.idx1-ubyte'),
         'test_images': ('t10k-images-idx3-ubyte', 't10k-images.idx3-ubyte'),
         'test_labels': ('t10k-labels-idx1-ubyte', 't10k-labels.idx1-ubyte')}
PAIRS = [[0,1], [2,3], [4,5], [6,7], [8,9]]


def read_mnist(root, download=False):
    root = Path(root)
    if download:
        from torchvision.datasets import MNIST
        MNIST(root=str(root), train=True, download=True)
        MNIST(root=str(root), train=False, download=True)
    # --data-root may be the parent, MNIST/ itself, or its raw/ directory.
    folders = [root/'MNIST/raw', root/'MNIST', root/'raw', root]
    files = None
    for folder in folders:
        candidate = {}
        for key, variants in NAMES.items():
            for name in variants:
                for suffix in ('', '.gz'):
                    path = folder/(name+suffix)
                    if path.is_file():
                        candidate[key] = path
                        break
                if key in candidate:
                    break
        if len(candidate)==4:
            files = candidate
            break
    if files is None:
        raise FileNotFoundError('MNIST needs all four IDX files (plain or .gz) under '+str(root)+
                                '; use --download to explicitly download MNIST')
    arrays, hashes = {}, {}
    for key, path in files.items():
        if path.suffix=='.gz':
            with gzip.open(path,'rb') as stream:
                raw = stream.read()
        else:
            raw = path.read_bytes()
        ndim = 3 if key.endswith('images') else 1
        header_size = 4*(ndim+1)
        if len(raw)<header_size:
            raise ValueError('Truncated MNIST IDX header: '+str(path))
        header = struct.unpack('>'+('I'*(ndim+1)),raw[:header_size])
        if header[0]!=0x800+ndim or any(n<1 for n in header[1:]):
            raise ValueError('Invalid MNIST IDX header: '+str(path))
        if len(raw)-header_size!=int(np.prod(header[1:])):
            raise ValueError('MNIST IDX payload size mismatch: '+str(path))
        arrays[key] = np.frombuffer(raw, dtype=np.uint8, offset=header_size).reshape(header[1:]).copy()
        hashes[key] = hashlib.sha256(raw).hexdigest()
    for split in ('train', 'test'):
        x, y = arrays[split+'_images'], arrays[split+'_labels']
        if x.shape[1:]!=(28,28) or len(x)!=len(y) or set(y.tolist())!=set(range(10)):
            raise ValueError('MNIST requires matching 28x28 images and all labels 0..9')
    return arrays, hashes


def build_mnist_index(root, size, allow_subset=False, download=False):
    from .external_datasets import fingerprint
    arrays, hashes = read_mnist(root, download)
    if not allow_subset and (len(arrays['train_labels']),len(arrays['test_labels']))!=(60000,10000):
        raise ValueError('Full MNIST requires 60000 training and 10000 test images; use --allow-subset for debug')
    index = {'version':1, 'dataset':'Split-MNIST', 'adapter':'split-mnist',
             'classes':[str(i) for i in range(10)], 'image_size':size,
             'preprocessing':'IDX grayscale; PIL bilinear square resize; repeat into RGB; tensor /255; no horizontal flip',
             'group_order':[], 'allow_subset':bool(allow_subset),
             'source_sha256':hashes,
             'evaluation_policy':'MNIST official test split; five sequential digit pairs; no task identity for learner'}
    for split in ('train','test'):
        index[split] = [{'sample_id':i,'label':int(y)} for i,y in enumerate(arrays[split+'_labels'])]
    index['index_sha256'] = fingerprint(index)
    return index


class MNISTImages:
    def __init__(self, images, size, ids=None):
        self.images, self.size = images, size
        self.ids = np.arange(len(images)) if ids is None else np.asarray(ids,dtype=np.int64)
        self.shape = (len(self.ids),size,size,3)
        self.nbytes = int(np.prod(self.shape))

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, key):
        selected = self.ids[key]
        if np.ndim(selected):
            return MNISTImages(self.images,self.size,selected)
        gray = Image.fromarray(self.images[int(selected)])
        return np.array(gray.resize((self.size,self.size),Image.Resampling.BILINEAR).convert('RGB'),copy=True)

    def copy(self):
        return np.stack([self[i] for i in range(len(self))]) if len(self) else np.empty(self.shape,dtype=np.uint8)


def indexed_mnist(index, root, split):
    arrays, hashes = read_mnist(root)
    if hashes!=index['source_sha256']:
        raise ValueError('MNIST source data hash does not match prepared index')
    rows = index[split]
    ids = np.asarray([r['sample_id'] for r in rows],dtype=np.int64)
    labels = arrays[split+'_labels']
    if (len(ids)!=len(labels) or not np.array_equal(ids,np.arange(len(labels))) or
            [r['label'] for r in rows]!=labels.tolist()):
        raise ValueError('MNIST sample IDs/labels do not match prepared index')
    return MNISTImages(arrays[split+'_images'],index['image_size']),labels.tolist()
