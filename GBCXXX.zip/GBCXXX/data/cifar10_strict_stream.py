"""
cifar10_strict_stream.py
============================================================
目标
============================================================
把 CIFAR-10 的 50,000 个训练样本严格划分成 T 个数据流块：
    D1, D2, ..., DT
满足“样本级”严格划分：Di ∩ Dj = ∅,  i != j并且：D1 ∪ D2 ∪ ... ∪ DT = D_train
注意：这里要求的是“样本索引不重复”，而不是“类别不重复”。
不同数据块之间允许类别重叠，例如：
    D1 类别：0,1,2,3
    D2 类别：1,3,4,6
虽然类别1、3重复出现，但 D1 与 D2 使用的是这些类别中不同的图片，
因此两个数据块在样本层面仍然没有交集。
============================================================
当前主实验设置
============================================================
NUM_BLOCKS = 10
ACTIVE_CLASSES_PER_BLOCK = 4
SEED = 2026
CIFAR-10 每类 5000 个训练样本。
当 T=10、每块4个类别时：
    每个类别恰好出现在 4 个数据块中
    每次出现取 1250 个不同样本
    因此：4 × 1250 = 5000
每个数据块：
    4 × 1250 = 5000
最终：
    10 × 5000 = 50000
每一个训练样本恰好使用一次。
后续如果需要做流粒度敏感性实验，可以把 T 改回 20：
    每类出现8次
    每次取625个样本
    每块4×625=2500
"""

import random
from pathlib import Path
from typing import Dict, List, Sequence, Tuple

import numpy as np
import torch
from torch.utils.data import Dataset
from torchvision import datasets, transforms

# ============================================================
# 1. 默认参数
# ============================================================
SEED = 2026
# 当前主实验使用 10 个数据流块。
# CIFAR-10 训练集 50000 个样本，因此每块 5000 个样本。
NUM_BLOCKS = 10
# 每个数据块包含 4 个类别。
# T=10 时，每类在整个数据流中出现 4 次，
# 每次使用该类 1250 个互不重复的样本。
ACTIVE_CLASSES_PER_BLOCK = 4
NUM_CLASSES = 10 #数据集中总共类别有10个
# ============================================================
# 2. 固定随机种子
# ============================================================
def set_random_seed(seed: int = SEED) -> None:
    """固定随机种子，保证数据流划分可重复。"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

# ============================================================
# 3. 数据流块 Dataset
# ============================================================
class StreamDataset(Dataset):
    """
    一个数据流块 D_t。
    保存：
        images          当前数据块图像
        labels          当前数据块标签
        classes         当前块出现的类别
        sample_indices  这些样本在原始 CIFAR-10 train set 中的索引
    sample_indices 非常重要：
    它用于严格验证不同 D_t 之间是否存在重复图片。
    """
    def __init__(
        self,
        images: np.ndarray,      # 图像数据，格式为numpy数组
        labels: np.ndarray,      # 标签数据，格式为numpy数组
        sample_indices: np.ndarray,
    ) -> None:  # 样本在原始数据集中的索引，格式为numpy数组
                  # 初始化方法，无返回值
        self.images = images
        self.labels = labels.astype(np.int64)     # 存储当前数据块的图像数据
        self.sample_indices = sample_indices.astype(np.int64)  # 将标签转换为64位整数类型并存储
  # 将样本索引转换为64位整数类型并存储
        self.classes = np.unique(self.labels)
        self.num_samples = len(self.labels)  # 获取当前数据块中所有唯一的类别
    # 存储当前数据块中的样本数量
    def __len__(self) -> int:
        return self.num_samples     # 返回数据集的样本数量

    def __getitem__(self, index: int):
        # images 已经是 float32、CHW 格式  # 根据索引获取单个样本
        image = torch.from_numpy(self.images[index]).float()
        label = int(self.labels[index])  # 将指定索引的图像转换为PyTorch张量
  # 获取指定索引的标签并转换为整数
        return image, label
# ============================================================  # 返回图像和标签的元组
# 4. 加载 CIFAR-10
# ============================================================
def load_cifar10(
    root: str = str(Path(__file__).resolve().parents[1] / "data"),
) -> Tuple[np.ndarray, np.ndarray]:
    """
    加载 CIFAR-10 训练集。
    返回：
        images shape = (50000, 3, 32, 32)
        labels shape = (50000,)
    与之前预训练代码保持一致：这里只使用 ToTensor()，不额外改变归一化方式。
    """
    transform = transforms.ToTensor()
# 使用torchvision库中的CIFAR10数据集
# CIFAR10是一个包含10个类别的60000张32x32彩色图像的数据集，每类6000张
# 其中50000张为训练集，10000张为测试集
    dataset = datasets.CIFAR10(
        root=root,          # 指定数据集存储的根目录
        train=True,         # 表示加载训练集数据
        download=True,      # 如果数据集在指定根目录下不存在，则自动下载
        transform=transform, # 对数据进行预处理的转换操作
    )

    images = []
    labels = []
    for image, label in dataset:
        images.append(image.numpy())
        labels.append(label)
    images = np.stack(images).astype(np.float32)
    labels = np.asarray(labels, dtype=np.int64)
    print("CIFAR-10 train images:", images.shape)
    print("CIFAR-10 train labels:", labels.shape)
    return images, labels

# ===========================================================
# 5. 生成平衡的类别出现日程
# ============================================================
def build_balanced_class_schedule(
    num_blocks: int = NUM_BLOCKS,# 数据块数量
    active_classes_per_block: int = ACTIVE_CLASSES_PER_BLOCK,#每一个数据块类别的个数4
    num_classes: int = NUM_CLASSES,#总共类别数
    seed: int = SEED,#随机数种子
    first_block_classes: Sequence[int] = (0, 1, 2, 3),
    max_restarts: int = 10000,
) -> np.ndarray:
    """
    生成 shape=(num_blocks, active_classes_per_block) 的类别日程。
    目标：
    1. 每个数据块恰好包含 active_classes_per_block 4个不同类别；
    2. 每个类别在整个数据流中出现次数完全相同；
    3. 默认固定 D1 = [0,1,2,3]，与之前实验结构保持一致；
    4. 后续数据块类别混合变化，可出现：
       - 类别重叠
       - 类别暂时消失
       - 类别重新出现
    注意：“类别重复出现”不意味着“样本重复出现”。真正样本由后面的每类未使用队列保证全局不重复。
    """

    total_slots = num_blocks * active_classes_per_block#总样本数

    if total_slots % num_classes != 0:
        raise ValueError(
            "num_blocks * active_classes_per_block 必须能被类别数整除，"
            "否则无法保证每个类别出现次数完全相同。"
        )

    # 计算每个类别中样本点的个数，通过总样本点数除以类别数得到
    appearances_per_class = total_slots // num_classes#每类别里面样本点的个数
    # 将first_block_classes转换为元组类型，确保其不可变性
    first_block_classes = tuple(first_block_classes)
    # 检查first_block_classes的长度是否与active_classes_per_block相等

    if len(first_block_classes) != active_classes_per_block:
        # 如果不相等，抛出ValueError异常，提示用户参数不匹配
        raise ValueError(
            "first_block_classes 的长度必须等于 active_classes_per_block。"
        )

    if len(set(first_block_classes)) != active_classes_per_block:
        raise ValueError("D1 中不能出现重复类别。")

    # 使用多次重启保证最终剩余出现次数都正好归零。
    for restart in range(max_restarts):
        rng = np.random.default_rng(seed + restart)
        remaining = np.full(
            num_classes,
            appearances_per_class,
            dtype=np.int64,
        )
        # 固定第一块类别
        schedule = [
            np.asarray(first_block_classes, dtype=np.int64)
        ]
        remaining[list(first_block_classes)] -= 1
        if np.any(remaining < 0):
            raise ValueError("first_block_classes 与总出现次数不兼容。")
        success = True
        for _ in range(1, num_blocks):
            eligible = np.where(remaining > 0)[0]
            if len(eligible) < active_classes_per_block:
                success = False
                break
            # 按剩余次数加权抽样：
            # 剩余次数越多的类别，被选中的概率越高。
            weights = remaining[eligible].astype(np.float64)
            # 给上一块中出现的类别一个很轻微的权重，
            # 让相邻块有机会产生类别重叠，但不强制。
            previous_classes = set(schedule[-1].tolist())
            for j, c in enumerate(eligible):
                if int(c) in previous_classes:
                    weights[j] += 0.75
            probabilities = weights / np.sum(weights)
            selected = rng.choice(
                eligible,
                size=active_classes_per_block,
                replace=False,
                p=probabilities,
            )
            remaining[selected] -= 1
            schedule.append(selected.astype(np.int64))
        if success and np.all(remaining == 0):
            schedule = np.asarray(schedule, dtype=np.int64)

            # 再检查每一行类别不重复
            if all(
                len(np.unique(row)) == active_classes_per_block
                for row in schedule
            ):
                return schedule
    raise RuntimeError(
        "在最大重启次数内没有找到合法的类别日程。"
    )
# ============================================================
# 6. 严格无重复生成数据流
# ============================================================
def generate_strict_stream(
    images: np.ndarray,
    labels: np.ndarray,
    num_blocks: int = NUM_BLOCKS,
    active_classes_per_block: int = ACTIVE_CLASSES_PER_BLOCK,
    seed: int = SEED,
) -> List[StreamDataset]:
    """
    将整个 CIFAR-10 训练集严格划分成数据流。
    与旧版最关键的区别：旧版：每次都重新从完整 class_index[c] 中 np.random.choice(...)
        因此 D1 和 D2 之间可能抽到同一张图片。
    本版：每个类别只建立一次随机队列。后续每次从队列当前位置向后取样。
        已经取出的索引永远不会再次进入候选池。
    因此严格保证：
        Di ∩ Dj = ∅
        union(D1,...,DT) = whole train set
    """

    if len(images) != len(labels):
        raise ValueError("images 与 labels 数量不一致。")
    total_samples = len(labels)
    if total_samples % num_blocks != 0:
        raise ValueError(
            "总样本数必须能被 num_blocks 整除，"
            "才能保证每个流数据块大小完全一致。"
        )
    block_size = total_samples // num_blocks
    classes = np.unique(labels)
    if len(classes) != NUM_CLASSES:
        raise ValueError(
            f"当前代码按 CIFAR-10 设计，应有 {NUM_CLASSES} 个类别。"
        )
    # --------------------------------------------------------
    # 生成类别日程
    # --------------------------------------------------------
    # 构建平衡的课程表
    schedule = build_balanced_class_schedule(
        num_blocks=num_blocks,              # 课程块的总数量
        active_classes_per_block=active_classes_per_block,  # 每个课程块中活跃的课程数量
        num_classes=NUM_CLASSES,            # 课程的总数量
        seed=seed,                          # 随机种子，用于确保结果的可重现性
        first_block_classes=(0, 1, 2, 3),   # 第一个课程块中包含的课程索引
    )
    appearances_per_class = (
        num_blocks * active_classes_per_block
    ) // NUM_CLASSES
    # --------------------------------------------------------
    # 每个类别的样本数必须能均匀分配到它出现的各个数据块中 # CIFAR-10 中每类5000：
    # T=20 → 5000/8 = 625
    # T=10 → 5000/4 = 1250
    # --------------------------------------------------------
    class_counts = {
        int(c): int(np.sum(labels == c))
        for c in classes
    }
    unique_class_sizes = set(class_counts.values())
    if len(unique_class_sizes) != 1:
        raise ValueError(
            "当前平衡划分实现要求各类别样本数量相同。"
        )
    # 获取第一个类别的样本数量
    # 通过 next() 函数和 iter() 迭代器实现
    # unique_class_sizes 是一个包含各类别样本大小的可迭代对象
    # 这行代码假设所有类别的样本数量相同，因此只取第一个类别的样本数量作为代表
    samples_per_class = next(iter(unique_class_sizes))

    if samples_per_class % appearances_per_class != 0:
        raise ValueError(
            "每类样本数不能被该类别的数据块出现次数整除。"
        )

    quota_per_active_class = (
        samples_per_class // appearances_per_class
    )
    expected_block_size = (
        active_classes_per_block * quota_per_active_class
    )
    if expected_block_size != block_size:
        raise ValueError(
            f"当前参数无法得到严格等长数据块："
            f"期望 {block_size}，实际配额得到 {expected_block_size}。"
        )
    # -------------------------------------------------------
    # 为每个类别建立“全局只使用一次”的随机索引队列。
    # 注意：这里不再在每一批中重新对完整类别池调用 random.choice。
    # --------------------------------------------------------
    rng = np.random.default_rng(seed)
    class_queues: Dict[int, np.ndarray] = {}
    class_positions: Dict[int, int] = {}

    for c in classes:
        indices = np.where(labels == c)[0].copy()
        rng.shuffle(indices)
        class_queues[int(c)] = indices
        class_positions[int(c)] = 0

    stream: List[StreamDataset] = []
    # --------------------------------------------------------
    # 按类别日程逐块取样
    # --------------------------------------------------------
    for t in range(num_blocks):
        selected_classes = schedule[t]
        block_indices = []
        for c in selected_classes:
            c = int(c)
            start = class_positions[c]
            end = start + quota_per_active_class
            selected_indices = class_queues[c][start:end]

            if len(selected_indices) != quota_per_active_class:
                raise RuntimeError(
                    f"类别 {c} 的剩余样本不足。"
                )
            # 更新指针：
            # 下一次该类别出现时，只能从 end 之后继续取。
            class_positions[c] = end
            block_indices.extend(selected_indices.tolist())
        block_indices = np.asarray(
            block_indices,
            dtype=np.int64,
        )
        # 块内再随机打乱，使不同类别样本混合。
        rng.shuffle(block_indices)
        block_images = images[block_indices]
        block_labels = labels[block_indices]
        block = StreamDataset(
            images=block_images,
            labels=block_labels,
            sample_indices=block_indices,
        )
        stream.append(block)
        # 打印每个数据块的类别分布
        unique_labels, counts = np.unique(
            block_labels,
            return_counts=True,
        )

        distribution = {
            int(c): int(n)
            for c, n in zip(unique_labels, counts)
        }

        print(
            f"D{t + 1:02d} | "
            f"Samples={len(block)} | "
            f"Classes={unique_labels.tolist()} | "
            f"Distribution={distribution}"
        )

    return stream
# ============================================================
# 7. 严格验证：交集为空，并集为全集
# ============================================================
def verify_strict_partition(
    stream: Sequence[StreamDataset],
    total_samples: int,
) -> None:
    """
    严格验证数据流划分。检查：
    1. 所有块总样本数是否等于原始训练集；
    2. 拼接后 unique index 数量是否等于训练集；
    3. 是否每个原始索引恰好出现一次；
    4. 任意两个数据块是否有样本级交集。
    """
    all_indices = np.concatenate(
        [
            block.sample_indices
            for block in stream
        ]
    )

    unique_indices, occurrence_counts = np.unique(
        all_indices,
        return_counts=True,
    )

    total_in_stream = len(all_indices)
    unique_count = len(unique_indices)

    duplicated_count = int(
        np.sum(
            occurrence_counts > 1
        )
    )

    missing_count = total_samples - unique_count

    # 两两检查最大交集
    max_intersection = 0
    intersection_pair = None

    index_sets = [
        set(block.sample_indices.tolist())
        for block in stream
    ]

    for i in range(len(stream)):
        for j in range(i + 1, len(stream)):

            overlap = len(
                index_sets[i].intersection(
                    index_sets[j]
                )
            )

            if overlap > max_intersection:
                max_intersection = overlap
                intersection_pair = (
                    i + 1,
                    j + 1,
                )

    print("\n" + "=" * 72)
    print("Strict Stream Verification")
    print("=" * 72)

    print("原始训练集样本数:", total_samples)
    print("所有数据块样本数之和:", total_in_stream)
    print("不同原始样本索引数量:", unique_count)
    print("重复原始样本数量:", duplicated_count)
    print("遗漏原始样本数量:", missing_count)
    print("任意两块最大样本交集:", max_intersection)

    if intersection_pair is not None:
        print(
            "最大交集对应数据块:",
            intersection_pair,
        )

    is_valid = (
        total_in_stream == total_samples
        and unique_count == total_samples
        and duplicated_count == 0
        and missing_count == 0
        and max_intersection == 0
    )

    if is_valid:
        print(
            "\n验证通过："
            "所有数据块样本级两两不相交，并集等于整个训练集。"
        )
    else:
        raise RuntimeError(
            "严格数据流验证失败，请检查划分逻辑。"
        )
# ============================================================
# 8. 主程序测试
# ============================================================
if __name__ == "__main__":
    set_random_seed(SEED)
    images, labels = load_cifar10(
        root=str(Path(__file__).resolve().parents[1] / "data")
    )

    stream = generate_strict_stream(
        images=images,
        labels=labels,
        num_blocks=NUM_BLOCKS,
        active_classes_per_block=
            ACTIVE_CLASSES_PER_BLOCK,
        seed=SEED,
    )

    verify_strict_partition(
        stream=stream,
        total_samples=len(labels),
    )

    # 查看 D1
    D1 = stream[0]

    print("\n" + "=" * 72)
    print("D1 Summary")
    print("=" * 72)

    print("D1 samples:", len(D1))
    print("D1 classes:", D1.classes)

    unique_labels, counts = np.unique(
        D1.labels,
        return_counts=True,
    )

    print(
        "D1 distribution:",
        {
            int(c): int(n)
            for c, n in zip(
                unique_labels,
                counts,
            )
        },
    )
