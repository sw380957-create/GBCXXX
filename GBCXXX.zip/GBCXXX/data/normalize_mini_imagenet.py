"""Normalize the published Mini-ImageNet ZIP to images/<wnid>/<image>.

The published archive organizes images by few-shot *class* partitions. Those
partitions cannot serve as train/validation/test for a class-incremental run:
all 100 labels need their own training and final-test images. This command only
collects the original JPEGs by class. data.prepare_dataset subsequently makes
one seeded, image-level split within every class and records it in index.json.
It does not train a model or use final-test images for validation.
"""
import argparse
import csv
import io
import re
import shutil
from collections import Counter
from pathlib import Path, PurePosixPath
from zipfile import ZipFile


WNID = re.compile(r'^n\d{8}$')
IMAGE_SUFFIXES = {'.jpg', '.jpeg', '.png'}


def _csv_labels(archive):
    """Support archives with flat image folders and filename,label CSV files."""
    labels = {}
    for info in archive.infolist():
        if not info.filename.lower().endswith('.csv'):
            continue
        with archive.open(info) as raw:
            reader = csv.DictReader(io.TextIOWrapper(raw, encoding='utf-8-sig'))
            if not reader.fieldnames or not {'filename', 'label'} <= set(reader.fieldnames):
                continue
            for row in reader:
                label = row['label'].strip()
                name = PurePosixPath(row['filename'].strip()).name
                if not WNID.fullmatch(label):
                    raise ValueError(f'Invalid MiniImageNet CSV label: {label}')
                if name in labels and labels[name] != label:
                    raise ValueError(f'Conflicting MiniImageNet CSV labels for {name}')
                labels[name] = label
    return labels


def _label(info, csv_labels):
    path = PurePosixPath(info.filename)
    class_parts = [part for part in path.parts[:-1] if WNID.fullmatch(part)]
    if class_parts:
        return class_parts[-1]
    match = re.match(r'^(n\d{8})', path.name)
    return match.group(1) if match else csv_labels.get(path.name)


def normalize(archive_path, output, *, allow_subset=False):
    """Extract distinct images with deterministic names, rejecting incomplete data."""
    archive_path, output = Path(archive_path), Path(output)
    if output.exists():
        raise FileExistsError(f'Use a new MiniImageNet output directory: {output}')
    with ZipFile(archive_path) as archive:
        csv_labels = _csv_labels(archive)
        chosen = {}
        fingerprints = {}
        for info in archive.infolist():
            if info.is_dir() or PurePosixPath(info.filename).suffix.lower() not in IMAGE_SUFFIXES:
                continue
            label = _label(info, csv_labels)
            if label is None:
                raise ValueError(f'Cannot determine WNID for ZIP image {info.filename}')
            name = PurePosixPath(info.filename).name
            key = label, name
            signature = info.file_size, info.CRC
            earlier = chosen.get(key)
            if earlier is not None:
                if (earlier.file_size, earlier.CRC) != signature:
                    raise ValueError(f'Same class/image name has conflicting contents: {key}')
                continue
            prior = fingerprints.get(signature)
            if prior is not None:
                if prior[0] != label:
                    raise ValueError(f'Same image appears under different labels: {prior} and {key}')
                continue
            chosen[key] = info
            fingerprints[signature] = key
        counts = Counter(label for label, _ in chosen)
        if not counts:
            raise ValueError('No labeled MiniImageNet images found in archive')
        if not allow_subset and (len(counts) != 100 or any(n != 600 for n in counts.values())):
            raise ValueError('Expected 100 classes with 600 distinct images each; '
                             f'found {len(counts)} classes and counts {dict(counts)}')
        if any(n < 2 for n in counts.values()):
            raise ValueError('Each MiniImageNet class needs at least two images')
        for (label, name), info in sorted(chosen.items()):
            target = output/'images'/label/name
            target.parent.mkdir(parents=True, exist_ok=True)
            with archive.open(info) as source, target.open('xb') as destination:
                shutil.copyfileobj(source, destination)
    print(f'Normalized MiniImageNet: {len(counts)} classes, {len(chosen)} images in {output}',
          flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive', required=True, help='Published Mini-ImageNet.zip')
    parser.add_argument('--output', required=True, help='New normalized data directory')
    parser.add_argument('--allow-subset', action='store_true', help='Small data-flow tests only')
    args = parser.parse_args()
    normalize(args.archive, args.output, allow_subset=args.allow_subset)


if __name__ == '__main__':
    main()
