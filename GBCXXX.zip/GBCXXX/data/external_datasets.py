"""Portable dataset indexes. Downloading is opt-in and limited to MNIST."""
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image


DATASETS = {'tiny-imagenet': ('Tiny-ImageNet', 200, 64),
            'mini-imagenet': ('MiniImageNet', 100, 84),
            'cub200': ('CUB-200-2011', 200, 128),
            'imagenet100': ('ImageNet-100', 100, 224),
            'core50': ('CORe50', 50, 128),
            'domainnet': ('DomainNet', 345, 224),
            'domainnet126': ('DomainNet-126', 126, 224),
            'split-mnist': ('Split-MNIST', 10, 32)}
DOMAINS = ['clipart', 'infograph', 'painting', 'quickdraw', 'real', 'sketch']
EXTENSIONS = {'.jpg', '.jpeg', '.png', '.bmp', '.webp'}


def fingerprint(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def checked_path(root, relative):
    # Relative POSIX paths make indexes portable across Windows and Linux.
    relative = str(relative).replace('\\', '/')
    path = root / relative
    if Path(relative).is_absolute() or not path.resolve().is_relative_to(root.resolve()):
        raise ValueError(f'Image path escapes data root: {relative}')
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def picture_paths(folder):
    return sorted((p for p in folder.rglob('*') if p.is_file() and
                   p.suffix.lower() in EXTENSIONS), key=lambda p: p.as_posix())


def annotation_file(root, folder, name):
    candidates = [Path(folder)/name] if folder else [root/name, root/'txt'/name, root/'splits'/name]
    for path in candidates:
        if path.is_file():
            return path
    raise FileNotFoundError(f'Annotation file not found: {name}; use --annotations DIR')


def numbered_metadata(path):
    """Read a CUB ``id value`` metadata file and reject malformed/duplicate IDs."""
    values = {}
    for line in path.read_text(encoding='utf-8').splitlines():
        if not line.strip():
            continue
        parts = line.split(maxsplit=1)
        if len(parts) != 2:
            raise ValueError(f'Malformed CUB metadata in {path}: {line}')
        sample_id, value = int(parts[0]), parts[1]
        if sample_id in values:
            raise ValueError(f'Duplicate CUB image/class ID {sample_id} in {path}')
        values[sample_id] = value.strip()
    return values


def build_index(dataset, root, *, image_size=None, allow_subset=False, domains=None,
                annotations=None, class_list=None, val_labels=None, verify_images=False,
                download=False, split_seed=2026):
    root = Path(root).resolve()
    if dataset not in DATASETS:
        raise ValueError(f'Unknown dataset: {dataset}')
    if not root.is_dir() and not (dataset=='split-mnist' and download):
        raise FileNotFoundError(root)
    name, expected, default_size = DATASETS[dataset]
    size = default_size if image_size is None else image_size
    if type(size) is not int or size < 16:
        raise ValueError('image_size must be an integer >= 16')
    if download and dataset!='split-mnist':
        raise ValueError('--download is currently supported only for split-mnist')
    if dataset=='split-mnist':
        from .split_mnist import build_mnist_index
        return build_mnist_index(root,size,allow_subset,download)
    records = {'train': [], 'test': []}
    names = []
    groups = []
    selection = None

    def add(split, path, label, group=''):
        path = Path(path)
        relative = path.relative_to(root).as_posix()
        checked_path(root, relative)
        records[split].append({'path': relative, 'label': int(label), 'group': group})

    if dataset == 'mini-imagenet':
        # The usual few-shot train/val/test partitions hold out entire classes.
        # That is unsuitable for class-incremental evaluation of all 100 classes.
        # Instead, split the 600 images of EACH class into 500 train-pool images
        # and 100 fixed test images. make_protocol() subsequently reserves an
        # independent 10% validation holdout from each class's train pool.
        images = root/'images'
        if not images.is_dir():
            raise FileNotFoundError(f'MiniImageNet requires {images}/<wnid>/<image>; '
                                    'run data.normalize_mini_imagenet first')
        names = sorted(p.name for p in images.iterdir() if p.is_dir())
        rng = np.random.default_rng(split_seed)
        for c, name_c in enumerate(names):
            paths = picture_paths(images/name_c)
            if not allow_subset and len(paths) != 600:
                raise ValueError(f'MiniImageNet class {name_c} requires 600 distinct images, found {len(paths)}')
            if len(paths) < 2:
                raise ValueError(f'MiniImageNet class {name_c} needs at least two images')
            n_test = 100 if not allow_subset else max(1, min(len(paths)-1, round(len(paths)/6)))
            permutation = rng.permutation(len(paths))
            for i in permutation[:n_test]:
                add('test', paths[int(i)], c)
            for i in permutation[n_test:]:
                add('train', paths[int(i)], c)
        evaluation = ('custom class-incremental MiniImageNet: per-class fixed 500/100 train/test '
                      'split; independent validation reserved from train by protocol')
    elif dataset == 'cub200':
        # Preserve the dataset's official image-level train/test partition.
        # The continual validation split comes only from the official training
        # side; official test images never enter training, balls, or memory.
        classes = numbered_metadata(root/'classes.txt')
        image_names = numbered_metadata(root/'images.txt')
        image_labels = numbered_metadata(root/'image_class_labels.txt')
        train_flags = numbered_metadata(root/'train_test_split.txt')
        if set(image_names) != set(image_labels) or set(image_names) != set(train_flags):
            raise ValueError('CUB images, labels and train/test split use different image IDs')
        if sorted(classes) != list(range(1, len(classes)+1)):
            raise ValueError('CUB class IDs must be consecutive and start at 1')
        names = [classes[i] for i in sorted(classes)]
        for image_id in sorted(image_names):
            label = int(image_labels[image_id])
            flag = int(train_flags[image_id])
            if label not in classes or flag not in (0, 1):
                raise ValueError(f'Invalid CUB label or split for image {image_id}')
            add('train' if flag == 1 else 'test', root/'images'/image_names[image_id], label-1)
        if not allow_subset and len(image_names) != 11788:
            raise ValueError(f'Full CUB-200-2011 requires 11,788 images, found {len(image_names)}')
        evaluation = ('official CUB train_test_split.txt test images; independent validation '
                      'reserved from official training images by protocol')
    elif dataset in ('tiny-imagenet', 'imagenet100'):
        if dataset == 'tiny-imagenet':
            names = (root/'wnids.txt').read_text(encoding='utf-8').split()
        elif class_list:
            names = Path(class_list).read_text(encoding='utf-8').split()
        else:
            names = sorted(p.name for p in (root/'train').iterdir() if p.is_dir())
        if len(names) != len(set(names)):
            raise ValueError('Duplicate class identifiers')
        mapping = {c: i for i, c in enumerate(names)}
        for c in names:
            paths = picture_paths(root/'train'/c)
            if not paths:
                raise ValueError(f'Missing training images for class {c}')
            for path in paths:
                add('train', path, mapping[c])
        if dataset == 'tiny-imagenet' or val_labels:
            path = Path(val_labels) if val_labels else root/'val/val_annotations.txt'
            for line in path.read_text(encoding='utf-8').splitlines():
                if not line.strip():
                    continue
                filename, c, *_ = line.split()
                if c not in mapping:
                    if dataset == 'imagenet100':
                        continue  # Full ImageNet annotation may contain unselected classes.
                    raise ValueError(f'Unknown validation class label: {c}')
                base = root/'val/images' if (root/'val/images').is_dir() else root/'val'
                add('test', base/filename, mapping[c])
        else:
            if any(p.is_file() and p.suffix.lower() in EXTENSIONS for p in (root/'val').iterdir()):
                raise ValueError('Flat ImageNet validation requires --val-labels FILE (filename wnid)')
            for c in names:
                for path in picture_paths(root/'val'/c):
                    add('test', path, mapping[c])
        evaluation = 'official validation used as final evaluation; holdout comes from training'
    elif dataset == 'core50':
        # RGB C_* frames only; never include D_* depth images.
        sessions = sorted((p for p in root.iterdir() if p.is_dir() and
                           p.name.startswith('s') and p.name[1:].isdigit()),
                          key=lambda p: int(p.name[1:]))
        if not allow_subset and {s.name for s in sessions} != {f's{i}' for i in range(1,12)}:
            raise ValueError('Full CORe50 requires sessions s1 through s11')
        object_ids = sorted({int(p.name[1:]) for s in sessions for p in s.iterdir()
                             if p.is_dir() and p.name.startswith('o') and p.name[1:].isdigit()})
        if not object_ids or any(c < 1 or c > 50 for c in object_ids):
            raise ValueError('CORe50 root must contain s1/o1/C_*.png through s11/o50/...')
        names = [f'o{c}' for c in object_ids]
        mapping = {c: i for i, c in enumerate(object_ids)}
        for session in sessions:
            split = 'test' if int(session.name[1:]) in (3, 7, 10) else 'train'
            if split == 'train':
                groups.append(session.name)
            for c in object_ids:
                for path in picture_paths(session/f'o{c}'):
                    if path.name.startswith('C_'):
                        add(split, path, mapping[c], session.name)
        evaluation = 'official held-out sessions s3/s7/s10; 50-object recognition'
    else:
        if dataset == 'domainnet126':
            selection = json.loads((Path(__file__).parent/'metadata/domainnet126_classes.json').read_text(encoding='utf-8'))
            selected_names = selection['classes']
            if len(selected_names)!=126 or len(set(selected_names))!=126:
                raise ValueError('Invalid fixed DomainNet-126 class metadata')
            defaults = selection['default_domains']
        else:
            selected_names = None
            defaults = DOMAINS
        domains = defaults if domains is None else list(domains)
        if not domains or len(domains) != len(set(domains)) or set(domains)-set(DOMAINS):
            raise ValueError('Invalid or duplicate DomainNet domains')
        if dataset == 'domainnet126' and set(domains)!=set(defaults) and not allow_subset:
            raise ValueError('DomainNet-126 requires the four domains real/clipart/painting/sketch')
        groups = domains
        label_to_name, name_to_label = {}, {}
        for domain in domains:
            for split in ('train', 'test'):
                file = annotation_file(root, annotations, f'{domain}_{split}.txt')
                for line in file.read_text(encoding='utf-8').splitlines():
                    if not line.strip():
                        continue
                    relative, label_text = line.rsplit(maxsplit=1)
                    label = int(label_text)
                    parts = Path(relative.replace('\\','/')).parts
                    if len(parts) < 3 or parts[0] != domain or not 0 <= label < 345:
                        raise ValueError(f'Invalid DomainNet class/path: {line}')
                    c = parts[1]
                    if selected_names is not None and c not in selected_names:
                        continue
                    if label_to_name.get(label, c) != c or name_to_label.get(c, label) != label:
                        raise ValueError(f'Inconsistent DomainNet class mapping: {line}')
                    label_to_name[label], name_to_label[c] = c, label
                    add(split, root/relative.replace('\\','/'), label, domain)
        original = sorted(label_to_name)
        names = ([c for c in selected_names if c in name_to_label] if selected_names is not None
                 else [label_to_name[c] for c in original])
        name_mapping = {c:i for i,c in enumerate(names)}
        mapping = {c:name_mapping[label_to_name[c]] for c in original}
        for split in records:
            for row in records[split]:
                row['label'] = mapping[row['label']]
        evaluation = 'official per-domain test lists; supervised domain stream'
        if dataset == 'domainnet126':
            evaluation = 'AdaContrast/MME 126 classes; filtered official cleaned train/test lists; custom supervised four-domain stream'
            if not allow_subset:
                for split, rows in records.items():
                    for domain in domains:
                        if {r['label'] for r in rows if r['group']==domain}!=set(range(126)):
                            raise ValueError(f'{domain} {split} must cover all 126 selected classes')

    if not allow_subset and len(names) != expected:
        raise ValueError(f'{name} requires {expected} classes, found {len(names)}; '
                         'use --allow-subset only for explicit subset/debug experiments')
    seen = set()
    for split, rows in records.items():
        rows.sort(key=lambda r: r['path'])
        if not rows:
            raise ValueError(f'Empty {split} split')
        if set(r['label'] for r in rows) != set(range(len(names))):
            raise ValueError(f'{split} does not cover the selected classes')
        for row in rows:
            # Also catch aliases through symlinks, to prevent train/test leakage.
            path = checked_path(root, row['path'])
            key = str(path.resolve())
            if key in seen:
                raise ValueError(f'Duplicate image across/index splits: {row["path"]}')
            seen.add(key)
            if verify_images:
                with Image.open(path) as im:
                    im.verify()
    index = {'version': 1, 'dataset': name, 'adapter': dataset, 'classes': names,
             'image_size': size, 'preprocessing': 'RGB; PIL bilinear square resize; uint8; tensor /255',
             'group_order': groups, 'allow_subset': bool(allow_subset),
             'evaluation_policy': evaluation, **records}
    if dataset == 'mini-imagenet':
        index['image_split_seed'] = int(split_seed)
    if selection is not None:
        index['class_selection'] = selection
    index['index_sha256'] = fingerprint(index)
    return index


def save_index(index, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        json.dump(index, f, ensure_ascii=False, indent=2, allow_nan=False)


def load_index(path):
    index = json.loads(Path(path).read_text(encoding='utf-8'))
    payload = {k: v for k, v in index.items() if k != 'index_sha256'}
    if fingerprint(payload) != index.get('index_sha256'):
        raise ValueError('Dataset index hash mismatch')
    if index.get('version') != 1 or index.get('adapter') not in DATASETS:
        raise ValueError('Unsupported dataset index')
    return index


class ImageFiles:
    """NumPy-like lazy image view. Only copy() materializes a training window."""
    def __init__(self, root, records, size, ids=None):
        self.root, self.records, self.size = Path(root), records, size
        self.ids = np.arange(len(records)) if ids is None else np.asarray(ids, dtype=np.int64)
        self.shape = (len(self.ids), size, size, 3)

    @property
    def nbytes(self):
        # uint8 decoded payload: element count x 1 byte, no materialization required
        return int(np.prod(self.shape))

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, key):
        selected = self.ids[key]
        if np.ndim(selected):
            return ImageFiles(self.root, self.records, self.size, selected)
        path = checked_path(self.root, self.records[int(selected)]['path'])
        with Image.open(path) as im:
            return np.array(im.convert('RGB').resize((self.size, self.size),
                            Image.Resampling.BILINEAR), dtype=np.uint8, copy=True)

    def copy(self):
        if not len(self):
            return np.empty(self.shape, dtype=np.uint8)
        return np.stack([self[i] for i in range(len(self))])


class IndexedSource:
    def __init__(self, index, root, split):
        if index['adapter']=='split-mnist':
            from .split_mnist import indexed_mnist
            self.data, self.targets = indexed_mnist(index,root,split)
            self.classes = index['classes']
            return
        for row in index[split]:
            checked_path(Path(root), row['path'])
        self.targets = [r['label'] for r in index[split]]
        self.data = ImageFiles(root, index[split], index['image_size'])
        self.classes = index['classes']
