"""Prepare local image indexes, fixed streams and runnable configs on a server."""
import argparse
import json
from pathlib import Path

import numpy as np

from .external_datasets import DATASETS, build_index, save_index, fingerprint
from .task_free_stream import (build_task_free_protocol, TaskFreeProtocol,
    stratified_train_validation_split, verify_task_free_protocol,
    _sha256_int64)


PROTOCOL_DIRECTORIES = {'tiny-imagenet': 'tiny_imagenet', 'imagenet100': 'imagenet100',
                        'mini-imagenet': 'mini_imagenet', 'cub200': 'cub200',
                        'core50': 'core50', 'domainnet126': 'domainnet126', 'domainnet': 'domainnet',
                        'split-mnist':'split_mnist'}


def default_output(dataset):
    return Path(__file__).resolve().parents[1]/'protocols'/PROTOCOL_DIRECTORIES[dataset]


def make_protocol(index, *, seed=2026, val_ratio=.1, num_anchors=20,
                  active_classes=None, transition_fraction=.2, validation_session='s11'):
    labels = np.asarray([r['label'] for r in index['train']], dtype=np.int64)
    dataset = index['adapter']
    if dataset=='split-mnist':
        from .split_mnist import PAIRS
        p = build_task_free_protocol(labels,PAIRS,dataset_name=index['dataset'],seed=seed,
                                    val_ratio=val_ratio,transition_fraction=0).to_manifest()
        p['analysis_only']['experiment_scenario'] = 'class-incremental digit pairs; no task identity; fixed 10-way head'
        p.pop('protocol_sha256')
    elif dataset in ('tiny-imagenet', 'imagenet100', 'mini-imagenet', 'cub200'):
        active = active_classes if active_classes is not None else max(1, len(index['classes'])//5)
        p = build_task_free_protocol(labels, dataset_name=index['dataset'], seed=seed,
            val_ratio=val_ratio, anchor_mode='random_balanced', num_anchors=num_anchors,
            active_classes_per_anchor=active, transition_fraction=transition_fraction).to_manifest()
    else:
        rng = np.random.default_rng(seed)
        pools, validation, group_names = [], [], []
        for group in index['group_order']:
            ids = np.asarray([i for i, r in enumerate(index['train']) if r['group']==group],dtype=np.int64)
            if dataset == 'core50' and group == validation_session:
                validation.extend(ids.tolist())
                continue
            if not len(ids):
                raise ValueError(f'Empty stream group: {group}')
            if dataset in ('domainnet', 'domainnet126'):
                local_train, local_val = stratified_train_validation_split(labels[ids], val_ratio, seed)
                validation.extend(ids[local_val].tolist())
                ids = ids[local_train]
            rng.shuffle(ids)
            pools.append(ids)
            group_names.append(group)
        if not pools or not validation:
            raise ValueError('Need training and validation samples; CORe50 requires validation session '+validation_session)
        if dataset == 'core50' and set(labels[validation]) != set(labels):
            raise ValueError('CORe50 validation session must contain all selected objects')
        # Preserve natural domain/session order rather than inventing category anchors.
        stream = np.concatenate(pools)
        verify_task_free_protocol(labels, stream, validation)
        p = TaskFreeProtocol(index['dataset'], seed, tuple(np.unique(labels).tolist()),
            tuple(stream.tolist()), tuple(validation), _sha256_int64(labels),
            {'stream_policy': 'custom_session_order' if dataset=='core50' else 'supervised_domain_order',
             'group_order': group_names, 'group_sizes': [len(x) for x in pools],
             'validation_policy': 'entire session '+validation_session if dataset=='core50' else 'stratified within each domain',
             'val_ratio': val_ratio if dataset in ('domainnet','domainnet126') else None,
             'transition_fraction': 0,
             'warning': 'Custom stream; group IDs and boundaries are never exposed to learner. Not official CORe50 NIC/NC/NI or unsupervised domain adaptation.'}).to_manifest()
    # Bind sample IDs to portable relative paths and deterministic preprocessing.
    if index.get('class_selection'):
        p['analysis_only']['class_selection'] = index['class_selection']
        p['analysis_only']['evaluation_policy'] = index['evaluation_policy']
    p['dataset_index_sha256'] = index['index_sha256']
    p.pop('protocol_sha256',None)
    p['protocol_sha256'] = fingerprint(p)
    return p


def prepare(args):
    output = Path(args.output or default_output(args.dataset)).resolve()
    if output.exists():
        raise FileExistsError(f'Use a new prepared directory: {output}')
    index = build_index(args.dataset, args.data_root, image_size=args.image_size,
        allow_subset=args.allow_subset, domains=args.domains, annotations=args.annotations,
        class_list=args.class_list, val_labels=args.val_labels, verify_images=args.verify_images,
        download=getattr(args,'download',False), split_seed=args.seed)
    protocol = make_protocol(index, seed=args.seed, val_ratio=args.val_ratio,
        num_anchors=args.num_anchors, active_classes=args.active_classes,
        transition_fraction=args.transition_fraction, validation_session=args.validation_session)
    from continual.task_free_config import TaskFreeConfig
    config = TaskFreeConfig.load(Path(__file__).resolve().parents[1]/'continual/configs/task_free_v1.json')
    config.seed = args.seed
    if args.dataset=='split-mnist':
        config.horizontal_flip = False
    # Conservative starter batches for larger inputs, not tuned hyperparameters.
    if index['image_size'] >= 128:
        config.window_size = 128
        config.batch_size = 16
        config.feature_batch_size = 16
        config.warmup_windows = 4
        config.gb_full_update_interval_windows = 4
    config.validate()
    output.mkdir(parents=True, exist_ok=False)
    save_index(index, output/'index.json')
    for name, value in [('protocol.json', protocol), ('config.json', config.to_dict()),
                        ('preparation.json', {'dataset': index['dataset'],
                         'train_pool_samples': len(index['train']), 'test_samples': len(index['test']),
                         'stream_samples': len(protocol['train_stream_ids']),
                         'validation_samples': len(protocol['validation_ids']),
                         'class_count': len(index['classes']), 'image_size': index['image_size'],
                         'allow_subset': index['allow_subset'], 'images_decoded_and_verified': args.verify_images,
                         'protocol_sha256': protocol['protocol_sha256'],
                         'index_sha256': index['index_sha256'],
                         'evaluation_policy': index['evaluation_policy']})]:
        with (output/name).open('x', encoding='utf-8') as f:
            json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
    print(f'Prepared {index["dataset"]}: {output}', flush=True)
    print('Train with: python run_dataset.py --protocol-dir "'+str(output)+'" --data-root "'+str(Path(args.data_root).resolve())+'"', flush=True)
    return output


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--dataset', choices=list(DATASETS), required=True)
    p.add_argument('--data-root', required=True)
    p.add_argument('--output', help='New directory; defaults to project protocols/<dataset>/')
    p.add_argument('--image-size', type=int)
    p.add_argument('--seed', type=int, default=2026)
    p.add_argument('--val-ratio', type=float, default=.1)
    p.add_argument('--num-anchors', type=int, default=20)
    p.add_argument('--active-classes', type=int)
    p.add_argument('--transition-fraction', type=float, default=.2)
    p.add_argument('--domains', nargs='+', help='DomainNet arrival order; domainnet126 defaults to real clipart painting sketch')
    p.add_argument('--annotations', help='DomainNet directory containing *_train/test.txt')
    p.add_argument('--class-list', help='ImageNet-100 selected WNIDs, one per line')
    p.add_argument('--val-labels', help='Flat ImageNet val mapping: filename WNID, one per line')
    p.add_argument('--validation-session', default='s11', help='CORe50 entire training session reserved for validation')
    p.add_argument('--verify-images', action='store_true', help='Decode/verify every indexed image before training')
    p.add_argument('--allow-subset', action='store_true', help='Explicit subset/debug use; recorded in index')
    p.add_argument('--download', action='store_true', help='Explicitly download MNIST if needed; split-mnist only')
    prepare(p.parse_args())


if __name__ == '__main__':
    main()
